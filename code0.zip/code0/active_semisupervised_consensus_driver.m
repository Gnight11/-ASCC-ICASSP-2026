function out = active_semisupervised_consensus_driver(Data, params)
%==========================================================================
% FUNCTION:
%   out = active_semisupervised_consensus_driver(Data, params)
% DESCRIPTION:
%   Active semi-supervised consensus clustering driver:
%   1) Unsupervised consensus (one or multiple rounds) to get A, G, Y
%   2) Pair selection (representativeness + uncertainty, MMR redundancy)
%   3) Strong-constraint augmentation: build \tilde{A}
%   4) Semi-supervised update: recompute G and update Y under ML/CL rules
%   5) Repeat steps 2-4 for several active rounds or until convergence.
%
% INPUTS:
%   Data   : n x d features
%   params : struct with fields (key ones shown; others pass-through)
%       .unsupRounds   : initial unsupervised rounds [1]
%       .activeRounds  : number of active SSL rounds [3]
%       .pairBudget    : pairs per round [20]
%       .lambda3       : redundancy weight in MMR [0.5]
%       .r,K,KiMode,T,k,c,maxRounds : used by unsupervised_consensus_driver
%
% OUTPUT:
%   out : struct with histories of {A, G, Y, pairs_ml, pairs_cl}
%==========================================================================

    if nargin < 2, params = struct(); end
    unsupRounds  = getfielddef(params, 'unsupRounds', 1);
    activeRounds = getfielddef(params, 'activeRounds', 3);
    pairBudget   = getfielddef(params, 'pairBudget', 20);
    lambda3mmr   = getfielddef(params, 'lambda3', 0.5);

    % 0) Initial unsupervised consensus
    if unsupRounds > 0
        p0 = params; p0.maxRounds = unsupRounds;
        res0 = unsupervised_consensus_driver(Data, p0);
        
        % 调试：检查无监督阶段输出
        fprintf('=== 无监督阶段输出调试 ===\n');
        fprintf('res0.final.G 大小: %s\n', mat2str(size(res0.final.G)));
        fprintf('res0.final.A 大小: %s\n', mat2str(size(res0.final.A)));
        fprintf('res0.final.Y 大小: %s\n', mat2str(size(res0.final.Y)));
        fprintf('res0.final.Xe 大小: %s\n', mat2str(size(res0.final.Xe)));
        
        Xe = res0.final.Xe; A = res0.final.A; G = res0.final.G; Y = res0.final.Y;
    else
        % 跳过无监督阶段，使用默认初始化
        fprintf('=== 跳过无监督阶段，使用默认初始化 ===\n');
        
        % 应用与无监督阶段相同的数据随机化
        if exist('global_rand_idx', 'var') && ~isempty(global_rand_idx)
            fprintf('  · 应用全局随机化索引\n');
            Data_rand = Data(global_rand_idx, :);
        else
            fprintf('  · 未找到全局随机化索引，使用原始数据\n');
            Data_rand = Data;
        end
        
        % 构建基本的相似度矩阵和谱嵌入（改用constructW，KNN=5，HeatKernel动态t）
        optW = struct();
        optW.NeighborMode = 'KNN';
        optW.k = getfielddef(params,'k',5);
        optW.WeightMode = 'HeatKernel';
        W0 = constructW(Data_rand, optW);
        A = full(W0);
        [G] = fast_spectral_clustering(A, getfielddef(params,'c',4));
        % 简单的k-means初始化 - 修复输入格式
        [Y, ~] = kmeanspp(G', getfielddef(params,'c',4));  % 转置G以匹配期望格式
        Y = Y(:);  % 确保Y是列向量
        Xe = Data_rand;  % 使用随机化后的数据作为增强表示
    end
    
    % 调试：检查变量赋值后的状态
    fprintf('=== 变量赋值后状态 ===\n');
    fprintf('Xe 大小: %s\n', mat2str(size(Xe)));
    fprintf('A 大小: %s\n', mat2str(size(A)));
    fprintf('G 大小: %s\n', mat2str(size(G)));
    fprintf('Y 大小: %s\n', mat2str(size(Y)));

    history = struct('A', {A}, 'G', {G}, 'Y', {Y}, 'pairs_ml', {[]}, 'pairs_cl', {[]}, 'obj', {}, 'metrics', {});
    history(1).obj = compute_objectives(A, G, Y);
    if isfield(params,'gt') && ~isempty(params.gt)
        history(1).metrics = metrics_eval(params.gt, Y);
    else
        history(1).metrics = struct('ACC',NaN,'NMI',NaN,'ARI',NaN);
    end

    % Monotonic acceptance control - 修复目标函数计算
    acceptEps    = getfielddef(params,'acceptEps',   1e-4);  % minimal improvement
    patience     = getfielddef(params,'patience',    5);     % early stop after p non-improving rounds
    noImproveCnt = 0;
    bestRay = history(1).obj.rayleigh;  % 滚动基准
    bestJ   = 0;  % 第一轮目标为0

    % 累计（外部提供的）强约束集合：用于统计无监督违例与半监督强制执行
    CML = getfielddef(params, 'constraints_ml', []);
    CCL = getfielddef(params, 'constraints_cl', []);
    useSelected = getfielddef(params, 'useSelectedAsConstraints', false); % 是否将本轮选对并入累计约束

    for t = 1:activeRounds
        tRound = tic; fprintf('【半监督】第 %d/%d 轮 开始...\n', t, activeRounds);
        % 1) Build S/A from Xe if needed (ensure A exists)
        if isempty(A)
            optW = struct();
            optW.NeighborMode = 'KNN';
            optW.k = getfielddef(params,'k',5);
            optW.WeightMode = 'HeatKernel';
            W0 = constructW(Xe, optW);
            A = full(W0);
        end

        % 2) Pair selection: representative + uncertain + MMR redundancy
        % 2.0 获取候选样本对（外部提供或自动生成）
        candidatePairs = [];
        if isfield(params, 'candidatePairs') && ~isempty(params.candidatePairs)
            % 使用外部提供的候选对
            candidatePairs = params.candidatePairs;
            fprintf('  · 使用外部提供的候选样本对 (%d个)\n', size(candidatePairs,1));
        else
            % 自动生成候选对：基于当前嵌入G的相似性
            fprintf('  · 自动生成候选样本对...\n');
            n = size(G,1);
            % 使用k-NN图构建候选对
            k_nn = min(20, n-1);  % 限制k-NN大小
            
            % 修复：直接使用欧氏距离计算k-NN，避免knn_vec函数问题
            % 确保输入数据是实数数组
            G = real(G);
            G(isnan(G) | isinf(G)) = 0;
            D = pdist2(G, G, 'euclidean');
            [~, nn_idx] = sort(D, 2, 'ascend');
            nn_idx = nn_idx(:, 2:k_nn+1);  % 跳过自己，取k个最近邻
            
            % 从k-NN中随机选择候选对
            n_candidates = min(100, n*k_nn/2);  % 限制候选对数量
            candidatePairs = [];
            for i = 1:n
                if size(candidatePairs,1) >= n_candidates, break; end
                for j = 1:k_nn
                    if size(candidatePairs,1) >= n_candidates, break; end
                    neighbor = nn_idx(i, j);
                    if i < neighbor  % 避免重复
                        candidatePairs = [candidatePairs; i, neighbor];
                    end
                end
            end
            fprintf('  · 自动生成候选样本对完成 (%d个)\n', size(candidatePairs,1));
        end

        % 最终调试：在调用MEX之前再次验证
        fprintf('  · 【最终验证】调用MEX前的candidatePairs:\n');
        fprintf('    - 大小: %s\n', mat2str(size(candidatePairs)));
        fprintf('    - 前5行内容:\n');
        if size(candidatePairs,1) >= 5
            for i = 1:5
                fprintf('      [%d, %d]\n', candidatePairs(i,1), candidatePairs(i,2));
            end
        else
            for i = 1:size(candidatePairs,1)
                fprintf('      [%d, %d]\n', candidatePairs(i,1), candidatePairs(i,2));
            end
        end
        fprintf('    - 范围: [%d, %d]\n', min(candidatePairs(:)), max(candidatePairs(:)));
        fprintf('    - 数据类型: %s\n', class(candidatePairs));
        fprintf('    - 是否包含NaN: %s\n', mat2str(any(isnan(candidatePairs(:)))));
        fprintf('    - 是否包含Inf: %s\n', mat2str(any(isinf(candidatePairs(:)))));

        % 2.1 代表性（MEX，默认）：用A近似A*
        % 用扩散后的 A* 作为代表性矩阵（提升鲁棒性）
        t1 = tic;
        Tstar = getfielddef(params,'Tstar', getfielddef(params,'T',5));
        Astar = computePTS_II(max(A,A'), Tstar);
        
        % 获取基聚类器结果用于熵不确定性计算
        BPs = [];
        if isfield(params, 'BPs') && ~isempty(params.BPs)
            BPs = params.BPs;
        elseif isfield(params, 'initial') && isfield(params.initial, 'BPsHist') && ~isempty(params.initial.BPsHist)
            % 使用初始无监督阶段的基聚类器结果
            BPs = params.initial.BPsHist{end};
        end
        
        % 仅选择 pairBudget 个样本对（支持多种合并模式）
        combineMode = getfielddef(params, 'combineMode', 'var_weight');
        [pairs, ~] = select_pairs_mmr_candidates(G, Astar, candidatePairs, lambda3mmr, [], BPs, pairBudget, combineMode);
        fprintf('  · 样本对选择完成，用时 %.2fs（候选=%d）\n', toc(t1), size(candidatePairs,1));

        % Here仅返回候选对，不自动打 must/cannot；默认用当前 Y 判定：同簇→ML，不同→CL
        pairs_ml = []; pairs_cl = [];
        for k = 1:size(pairs,1)
            i = pairs(k,1); j = pairs(k,2);
            if Y(i) == Y(j)
                pairs_ml(end+1,:) = [i j]; %#ok<AGROW>
            else
                pairs_cl(end+1,:) = [i j]; %#ok<AGROW>
            end
        end

        % 3) 强约束增强（记录无监督与半监督的违反数）
        % 先使用"累计外部约束集合 CML/CCL"统计无监督违例（这反映无监督下对外部知识的违背）
        if ~isempty(CML) || ~isempty(CCL)
            [violMust0, violCannot0] = check_constraint_violations_local(Y, CML, CCL);
            fprintf('  · 无监督标签对外部约束的违例：must-link=%d, cannot-link=%d\n', violMust0, violCannot0);
        end

        % 本轮用于半监督的约束：外部累计 + （可选）本轮选对（用当前Y自动打ML/CL或由外部标注）
        if useSelected
            CML_use = [CML; pairs_ml]; %#ok<AGROW>
            CCL_use = [CCL; pairs_cl]; %#ok<AGROW>
        else
            CML_use = CML; CCL_use = CCL;
        end

        t2 = tic; [A_tilde] = build_constraint_augmented_affinity(A, CML_use, CCL_use, getfielddef(params,'lambda1',1), getfielddef(params,'lambda2',1), 1e-6);
        fprintf('  · 约束增强完成，用时 %.2fs\n', toc(t2));

        % 4) Semi-supervised update
        % 4.1 Compute new embedding by spectral on A_tilde
        cFixed = getfielddef(params,'c', getfielddef(params,'K', max(Y)));
        t3 = tic; [G_ssc] = fast_spectral_clustering(A_tilde, cFixed);
        % 4.2 Update Y by three-case rules
        Y_new = semisupervised_update_labels(A_tilde, G_ssc, Y, CML_use, CCL_use);
        fprintf('  · 半监督标签更新完成，用时 %.2fs\n', toc(t3));
        if ~isempty(pairs_ml) || ~isempty(pairs_cl)
            [violMust1, violCannot1] = check_constraint_violations_local(Y_new, pairs_ml, pairs_cl);
            fprintf('  · 半监督更新后违例：must-link=%d, cannot-link=%d\n', violMust1, violCannot1);
        end

        % 4.3 (可选) 约束修复：在半监督标签基础上，用K-means风格的局部修复满足强约束
        if getfielddef(params, 'enableRepair', true) && ( ~getfielddef(params,'repairOnlyFirst',true) || t==1 )
            % 用嵌入 G_ssc 作为特征，当前标签 Y_new 计算簇中心 C
            cNow = max(Y_new);
            C0 = zeros(cNow, size(G_ssc,2));
            for rr = 1:cNow
                idxr = (Y_new==rr);
                if any(idxr)
                    C0(rr,:) = mean(G_ssc(idxr,:),1);
                else
                    C0(rr,:) = G_ssc(randi(size(G_ssc,1)),:);
                end
            end
            [Y_new, ~] = repair_constraints_kmeans(G_ssc, Y_new, C0, CML_use, CCL_use, 10);
            if ~isempty(CML_use) || ~isempty(CCL_use)
                [violMust2, violCannot2] = check_constraint_violations_local(Y_new, CML_use, CCL_use);
                fprintf('  · 约束修复后违例：must-link=%d, cannot-link=%d\n', violMust2, violCannot2);
            end
        end

        % 5) Acceptance: compute objective and accept only if improved and zero-violation
        candObj = compute_objectives(A_tilde, G_ssc, Y_new);
        
        % 修复目标函数：使用纯Rayleigh优化，与无监督保持一致
        Jcand = candObj.rayleigh;
        
        % 硬约束检查：确保外部约束都被满足
        if getfielddef(params, 'enableHardConstraints', false)
            % 只检查外部约束（不包括本轮选择的约束）
            [violMust_external, violCannot_external] = check_constraint_violations_local(Y_new, CML_use, CCL_use);
            
            % 只有在零违例的情况下才接受结果
            improved = (Jcand > bestRay + acceptEps) && (violMust_external == 0) && (violCannot_external == 0);
            
            if violMust_external > 0 || violCannot_external > 0
                fprintf('  · 硬约束违例：must-link=%d, cannot-link=%d，拒绝结果\n', violMust_external, violCannot_external);
            end
        else
            % 软约束：允许少量违例
            improved = (Jcand > bestRay + acceptEps) && ( (exist('violMust2','var')&&exist('violCannot2','var')&&violMust2==0&&violCannot2==0) || (~exist('violMust2','var')&&~exist('violCannot2','var')) );
        end

        if improved
            A = A_tilde; G = G_ssc; Y = Y_new;
            bestRay = Jcand; noImproveCnt = 0;  % 更新最优Rayleigh值
            % 累加选对到强约束集合（仅当被接受时）
            if useSelected
                CML = [CML; pairs_ml]; %#ok<AGROW>
                CCL = [CCL; pairs_cl]; %#ok<AGROW>
            end
            history(t).A = A; history(t).G = G; history(t).Y = Y; %#ok<AGROW>
            history(t).pairs_ml = pairs_ml; history(t).pairs_cl = pairs_cl; %#ok<AGROW>
            history(t).obj = candObj; %#ok<AGROW>
            if isfield(params,'gt') && ~isempty(params.gt)
                history(t).metrics = metrics_eval(params.gt, Y);
                fprintf('  · 评估：ACC=%.4f NMI=%.4f ARI=%.4f\n', history(t).metrics.ACC, history(t).metrics.NMI, history(t).metrics.ARI);
            else
                history(t).metrics = struct('ACC',NaN,'NMI',NaN,'ARI',NaN);
            end
            fprintf('  · 接受本轮结果（Rayleigh提升：%.6f -> %.6f）。\n', bestRay-acceptEps, bestRay);
        else
            noImproveCnt = noImproveCnt + 1;
            history(t).A = A; history(t).G = G; history(t).Y = Y; %#ok<AGROW>
            history(t).pairs_ml = []; history(t).pairs_cl = []; %#ok<AGROW>
            history(t).obj = compute_objectives(A, G, Y); %#ok<AGROW>
            if isfield(params,'gt') && ~isempty(params.gt)
                history(t).metrics = metrics_eval(params.gt, Y);
            else
                history(t).metrics = struct('ACC',NaN,'NMI',NaN,'ARI',NaN);
            end
            fprintf('  · 拒绝本轮结果（Rayleigh未提升：%.6f <= %.6f），保持上一轮。\n', Jcand, bestRay + acceptEps);
        end

        fprintf('【半监督】第 %d 轮 完成，总用时 %.2fs\n', t, toc(tRound));

        if noImproveCnt >= patience
            fprintf('  · 连续 %d 轮未提升，提前停止。\n', patience);
            break;
        end
    end

    out = struct();
    if unsupRounds > 0
        out.initial = res0;
    else
        % 当跳过无监督阶段时，创建空的initial结构
        out.initial = struct('final', struct('Xe', Xe, 'A', A, 'G', G, 'Y', Y, 'rounds', 0));
    end
    out.history = history;
    out.final = struct('A', A, 'G', G, 'Y', Y);

end

function v = getfielddef(s, name, def)
    if isfield(s, name)
        v = s.(name);
    else
        v = def;
    end
end

function [numViolMust, numViolCannot] = check_constraint_violations_local(labels, mustPairs, cannotPairs)
    numViolMust = 0; numViolCannot = 0;
    for t = 1:size(mustPairs,1)
        if labels(mustPairs(t,1)) ~= labels(mustPairs(t,2))
            numViolMust = numViolMust + 1;
        end
    end
    for t = 1:size(cannotPairs,1)
        if labels(cannotPairs(t,1)) == labels(cannotPairs(t,2))
            numViolCannot = numViolCannot + 1;
        end
    end
end
