%% 增强多层优化收敛测试 - 提升聚类效果
% 在原有基础上增加多层优化策略

clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 🚀 增强多层优化收敛测试 ===\n');
fprintf('优化策略: 预处理 + 多层共识 + 约束强化 + 后优化\n\n');

%% 数据加载和预处理增强
fprintf('📁 加载和预处理数据...\n');
data_file = fullfile('..', 'data', 'II_Ia_Ib_data.mat');
[data, gt] = load_timeseries_mat(data_file);

n_samples = length(gt);
n_classes = length(unique(gt));
fprintf('数据信息: %d样本, %d特征, %d类别\n', n_samples, size(data,2), n_classes);

% 🔧 增强预处理
fprintf('🔧 增强数据预处理...\n');
% 1. 标准化
data_norm = zscore(data);
% 2. 异常值处理
data_norm(abs(data_norm) > 3) = sign(data_norm(abs(data_norm) > 3)) * 3;
% 3. 特征选择 - 保留最有区分度的特征
feature_var = var(data_norm);
[~, top_features] = sort(feature_var, 'descend');
n_selected = min(1000, round(size(data,2) * 0.8)); % 保留80%最有区分度的特征
data_enhanced = data_norm(:, top_features(1:n_selected));

fprintf('特征优化: %d → %d 维\n', size(data,2), size(data_enhanced,2));

%% 增强参数设置
fprintf('\n⚙️ 设置增强优化参数...\n');

% 基础高性能参数
base_params = struct();
base_params.k = 20;                    % 🚀 更多近邻
base_params.T = 50;                    % 🚀 更深扩散
base_params.snnWeight = 0.3;           % 🚀 更强SNN权重
base_params.gamma = 4.0;               % 🚀 更高gamma
base_params.r = 150;                   % 🚀 更多基聚类器
base_params.c = 4;
base_params.maxRounds = 20;

% 多层优化参数
enhance_params = struct();
enhance_params.n_layers = 3;           % 三层优化
enhance_params.ensemble_size = 5;      % 集成大小
enhance_params.refinement_rounds = 10; % 细化轮数
enhance_params.constraint_boost = 2.0; % 约束增强因子

%% 第一层：增强无监督聚类
fprintf('\n🎯 第一层优化: 多尺度无监督聚类...\n');
tic;

% 多尺度参数
scales = [0.5, 1.0, 1.5];  % 不同的gamma尺度
ensemble_results = [];

for scale = scales
    scale_params = base_params;
    scale_params.gamma = base_params.gamma * scale;
    scale_params.maxRounds = 15;
    
    fprintf('  运行尺度 %.1f...\n', scale);
    try
        res = unsupervised_consensus_driver(data_enhanced, scale_params);
        if ~isempty(res) && isfield(res, 'final')
            ensemble_results = [ensemble_results, res.final.Y(:)];
        end
    catch ME
        fprintf('  ⚠️ 尺度 %.1f 失败: %s\n', scale, ME.message);
    end
end

% 集成多尺度结果
if ~isempty(ensemble_results)
    % 使用投票方式集成
    Y_unsup_enhanced = ensemble_cluster_voting(ensemble_results, n_classes);
else
    % 降级到单一结果
    fprintf('  降级到单一无监督聚类...\n');
    res_unsup = unsupervised_consensus_driver(data_enhanced, base_params);
    Y_unsup_enhanced = res_unsup.final.Y(:);
end

M_unsup_enhanced = metrics_eval(gt, Y_unsup_enhanced);
time_unsup = toc;

fprintf('✅ 增强无监督: ACC=%.4f, NMI=%.4f, ARI=%.4f (%.1fs)\n', ...
    M_unsup_enhanced.ACC, M_unsup_enhanced.NMI, M_unsup_enhanced.ARI, time_unsup);

%% 第二层：约束增强半监督聚类
fprintf('\n🔒 第二层优化: 约束增强半监督聚类...\n');
tic;

% 智能标签选择
labeled_indices = smart_label_selection(data_enhanced, gt, 0.1);
fprintf('智能标签选择: %d个样本\n', length(labeled_indices));

% 增强约束生成
constraints = enhanced_constraint_generation(labeled_indices, gt, enhance_params);
fprintf('增强约束: %d个ML, %d个CL\n', size(constraints.ml,1), size(constraints.cl,1));

% 运行约束增强聚类
params_sup = base_params;
params_sup.constraints_ml = constraints.ml;
params_sup.constraints_cl = constraints.cl;
params_sup.enableHardConstraints = true;
params_sup.enableRepair = true;
params_sup.activeRounds = 15;
params_sup.lambda1 = 0.5 * enhance_params.constraint_boost;  % 增强约束权重
params_sup.lambda2 = 0.5 * enhance_params.constraint_boost;

% 使用增强无监督结果初始化
if exist('res_unsup', 'var') && ~isempty(res_unsup)
    try
        optW = struct(); 
        optW.NeighborMode = 'KNN';
        optW.k = base_params.k;
        optW.WeightMode = 'HeatKernel';
        params_sup.initial_A = full(constructW(data_enhanced, optW));
        params_sup.initial_Y = Y_unsup_enhanced;
        if isfield(res_unsup, 'BPsHist') && ~isempty(res_unsup.BPsHist)
            params_sup.BPs = res_unsup.BPsHist{end};
        end
    catch
        fprintf('⚠️ 初始化失败，使用默认设置\n');
    end
end

res_sup = active_semisupervised_consensus_driver(data_enhanced, params_sup);
Y_sup_raw = res_sup.final.Y(:);

time_sup = toc;

%% 第三层：后优化细化
fprintf('\n✨ 第三层优化: 智能后优化细化...\n');
tic;

% 约束修复增强
Y_sup_repaired = smart_constraint_repair(Y_sup_raw, constraints, data_enhanced, n_classes);

% 局部优化细化
Y_sup_refined = local_cluster_refinement(Y_sup_repaired, data_enhanced, constraints, enhance_params.refinement_rounds);

% 全局一致性检查
Y_sup_final = global_consistency_check(Y_sup_refined, constraints);

M_sup_final = metrics_eval(gt, Y_sup_final);
time_refine = toc;

% 最终违规检查
[viol_ml, viol_cl] = check_constraint_violations_local(Y_sup_final, constraints.ml, constraints.cl);

fprintf('✅ 最终优化: ACC=%.4f, NMI=%.4f, ARI=%.4f (%.1fs)\n', ...
    M_sup_final.ACC, M_sup_final.NMI, M_sup_final.ARI, time_refine);
fprintf('🚨 最终违规: ML=%d, CL=%d\n', viol_ml, viol_cl);

%% 结果总结
total_time = time_unsup + time_sup + time_refine;

fprintf('\n=== 🎉 增强多层优化结果总结 ===\n');
fprintf('%-18s %-8s %-8s %-8s %-8s %-10s\n', '方法', 'ACC', 'NMI', 'ARI', '时间(s)', '违规');
fprintf('----------------------------------------------------------------\n');
fprintf('%-18s %-8.4f %-8.4f %-8.4f %-8.1f %-10s\n', '增强无监督', ...
    M_unsup_enhanced.ACC, M_unsup_enhanced.NMI, M_unsup_enhanced.ARI, time_unsup, 'N/A');
fprintf('%-18s %-8.4f %-8.4f %-8.4f %-8.1f %-10s\n', '最终优化半监督', ...
    M_sup_final.ACC, M_sup_final.NMI, M_sup_final.ARI, time_sup+time_refine, sprintf('ML:%d CL:%d', viol_ml, viol_cl));

% 改善幅度
improvement = M_sup_final.ACC - M_unsup_enhanced.ACC;
improvement_pct = (improvement / M_unsup_enhanced.ACC) * 100;

fprintf('\n📈 性能改善分析:\n');
fprintf('   ACC提升: %.4f → %.4f (+%.4f, +%.1f%%)\n', ...
    M_unsup_enhanced.ACC, M_sup_final.ACC, improvement, improvement_pct);

if M_unsup_enhanced.ACC < M_sup_final.ACC
    fprintf('   ✅ 层级关系满足\n');
else
    fprintf('   ❌ 层级关系不满足\n');
end

if viol_ml == 0 && viol_cl == 0
    fprintf('   ✅ 零违规要求满足\n');
else
    fprintf('   ❌ 仍有约束违规\n');
end

fprintf('\n⏰ 总用时: %.1f分钟\n', total_time/60);

% 保存结果
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
result_dir = sprintf('enhanced_results_%s', timestamp);
mkdir(result_dir);

save(fullfile(result_dir, 'enhanced_results.mat'), 'M_unsup_enhanced', 'M_sup_final', ...
     'Y_unsup_enhanced', 'Y_sup_final', 'constraints', 'base_params', 'enhance_params');

fprintf('\n💾 结果已保存到: %s\n', result_dir);
fprintf('🎉 增强多层优化测试完成！\n');

%% 辅助函数定义

function Y_ensemble = ensemble_cluster_voting(ensemble_results, n_classes)
    % 集成多个聚类结果的投票
    n_samples = size(ensemble_results, 1);
    n_methods = size(ensemble_results, 2);
    
    % 创建共现矩阵
    cooccur = zeros(n_samples, n_samples);
    for i = 1:n_methods
        labels = ensemble_results(:, i);
        for j = 1:n_samples
            cooccur(j, :) = cooccur(j, :) + (labels == labels(j));
        end
    end
    cooccur = cooccur / n_methods;
    
    % 基于共现矩阵的谱聚类
    try
        D = diag(sum(cooccur, 2));
        L = D - cooccur;
        [V, ~] = eigs(L, n_classes, 'smallestabs');
        Y_ensemble = kmeans(V, n_classes, 'MaxIter', 100, 'Replicates', 10);
    catch
        % 降级到简单投票
        Y_ensemble = ensemble_results(:, 1);
    end
end

function labeled_indices = smart_label_selection(data, gt, ratio)
    % 智能标签选择 - 选择最有代表性的样本
    n_classes = length(unique(gt));
    labeled_indices = [];
    
    for c = 1:n_classes
        class_indices = find(gt == c);
        class_data = data(class_indices, :);
        
        % 计算类内距离，选择中心和边界样本
        if length(class_indices) > 1
            center = mean(class_data, 1);
            distances = sqrt(sum((class_data - center).^2, 2));
            [~, order] = sort(distances);
            
            n_select = max(1, round(length(class_indices) * ratio));
            
            % 选择中心样本和一些边界样本
            n_center = max(1, round(n_select * 0.6));
            n_boundary = n_select - n_center;
            
            selected = [order(1:n_center); order(end-n_boundary+1:end)];
            selected = selected(1:min(n_select, length(selected)));
            
            labeled_indices = [labeled_indices; class_indices(selected)];
        else
            labeled_indices = [labeled_indices; class_indices];
        end
    end
end

function constraints = enhanced_constraint_generation(labeled_indices, gt, enhance_params)
    % 增强约束生成
    constraints = struct();
    constraints.ml = [];
    constraints.cl = [];
    
    n_classes = length(unique(gt));
    
    % 智能ML约束 - 基于距离的约束生成
    for c = 1:n_classes
        class_labeled = labeled_indices(gt(labeled_indices) == c);
        if length(class_labeled) >= 2
            % 生成更多ML约束
            n_ml = min(10, nchoosek(length(class_labeled), 2));
            pairs = nchoosek(class_labeled, 2);
            if size(pairs, 1) > n_ml
                pairs = pairs(randperm(size(pairs, 1), n_ml), :);
            end
            constraints.ml = [constraints.ml; pairs];
        end
    end
    
    % 智能CL约束 - 避免过近的不同类样本
    for c1 = 1:n_classes
        for c2 = c1+1:n_classes
            class1_labeled = labeled_indices(gt(labeled_indices) == c1);
            class2_labeled = labeled_indices(gt(labeled_indices) == c2);
            
            if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                % 生成适量CL约束
                n_cl = min(8, length(class1_labeled) * length(class2_labeled));
                [C1, C2] = meshgrid(class1_labeled, class2_labeled);
                pairs = [C1(:), C2(:)];
                if size(pairs, 1) > n_cl
                    pairs = pairs(randperm(size(pairs, 1), n_cl), :);
                end
                constraints.cl = [constraints.cl; pairs];
            end
        end
    end
    
    fprintf('生成约束: %d ML, %d CL\n', size(constraints.ml,1), size(constraints.cl,1));
end

function Y_repaired = smart_constraint_repair(Y, constraints, data, n_classes)
    % 智能约束修复
    Y_repaired = Y;
    max_iterations = 10;
    
    for iter = 1:max_iterations
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_repaired, constraints.ml, constraints.cl);
        
        if viol_ml == 0 && viol_cl == 0
            break;
        end
        
        % 修复ML违规
        if ~isempty(constraints.ml)
            for i = 1:size(constraints.ml, 1)
                idx1 = constraints.ml(i, 1);
                idx2 = constraints.ml(i, 2);
                if Y_repaired(idx1) ~= Y_repaired(idx2)
                    % 将较小的聚类合并到较大的聚类
                    cluster1 = Y_repaired(idx1);
                    cluster2 = Y_repaired(idx2);
                    count1 = sum(Y_repaired == cluster1);
                    count2 = sum(Y_repaired == cluster2);
                    
                    if count1 >= count2
                        Y_repaired(Y_repaired == cluster2) = cluster1;
                    else
                        Y_repaired(Y_repaired == cluster1) = cluster2;
                    end
                end
            end
        end
        
        % 修复CL违规 - 重新分配违规样本
        if ~isempty(constraints.cl)
            for i = 1:size(constraints.cl, 1)
                idx1 = constraints.cl(i, 1);
                idx2 = constraints.cl(i, 2);
                if Y_repaired(idx1) == Y_repaired(idx2)
                    % 重新分配其中一个样本
                    available_clusters = setdiff(1:n_classes, Y_repaired(idx1));
                    if ~isempty(available_clusters)
                        Y_repaired(idx2) = available_clusters(1);
                    end
                end
            end
        end
    end
end

function Y_refined = local_cluster_refinement(Y, data, constraints, rounds)
    % 局部聚类细化
    Y_refined = Y;
    n_classes = length(unique(Y));
    
    for round = 1:rounds
        % 计算每个聚类的中心
        centers = zeros(n_classes, size(data, 2));
        for c = 1:n_classes
            cluster_data = data(Y_refined == c, :);
            if ~isempty(cluster_data)
                centers(c, :) = mean(cluster_data, 1);
            end
        end
        
        % 重新分配边界样本
        for i = 1:length(Y_refined)
            current_cluster = Y_refined(i);
            distances = sqrt(sum((data(i, :) - centers).^2, 2));
            [~, best_cluster] = min(distances);
            
            % 检查约束
            can_move = true;
            if ~isempty(constraints.ml)
                ml_partners = [constraints.ml(constraints.ml(:,1) == i, 2); ...
                               constraints.ml(constraints.ml(:,2) == i, 1)];
                for partner = ml_partners'
                    if Y_refined(partner) ~= best_cluster
                        can_move = false;
                        break;
                    end
                end
            end
            
            if can_move && ~isempty(constraints.cl)
                cl_partners = [constraints.cl(constraints.cl(:,1) == i, 2); ...
                               constraints.cl(constraints.cl(:,2) == i, 1)];
                for partner = cl_partners'
                    if Y_refined(partner) == best_cluster
                        can_move = false;
                        break;
                    end
                end
            end
            
            if can_move
                Y_refined(i) = best_cluster;
            end
        end
    end
end

function Y_final = global_consistency_check(Y, constraints)
    % 全局一致性检查和最终修复
    Y_final = Y;
    
    % 确保所有约束都满足
    [viol_ml, viol_cl] = check_constraint_violations_local(Y_final, constraints.ml, constraints.cl);
    
    if viol_ml > 0 || viol_cl > 0
        fprintf('进行最终约束修复...\n');
        
        % 强制修复所有违规
        if ~isempty(constraints.ml)
            for i = 1:size(constraints.ml, 1)
                idx1 = constraints.ml(i, 1);
                idx2 = constraints.ml(i, 2);
                if Y_final(idx1) ~= Y_final(idx2)
                    Y_final(idx2) = Y_final(idx1);
                end
            end
        end
        
        if ~isempty(constraints.cl)
            for i = 1:size(constraints.cl, 1)
                idx1 = constraints.cl(i, 1);
                idx2 = constraints.cl(i, 2);
                if Y_final(idx1) == Y_final(idx2)
                    % 找一个不冲突的聚类
                    other_clusters = unique(Y_final);
                    other_clusters = other_clusters(other_clusters ~= Y_final(idx1));
                    if ~isempty(other_clusters)
                        Y_final(idx2) = other_clusters(1);
                    end
                end
            end
        end
    end
    
    % 最终检查
    [final_ml, final_cl] = check_constraint_violations_local(Y_final, constraints.ml, constraints.cl);
    fprintf('最终违规检查: ML=%d, CL=%d\n', final_ml, final_cl);
end




