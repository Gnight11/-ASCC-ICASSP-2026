% FOUR_DATASETS_ABLATION: 跑4个小数据集的消融实验，生成4子图
%
% 跳过III_V_s2_data，处理其他4个数据集，每个数据集一个子图
%
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 4个数据集消融实验 ===\n');

% 选择4个小数据集（跳过III_V_s2_data）
datasets = {'II_Ia_data', 'II_Ib_data', 'IV_2b_s1_data', 'IV_2b_s3_data'};
data_dir = fullfile('..', 'data');

% 存储结果
all_ablation_results = cell(1, 4);
dataset_success = false(1, 4);

%% 逐个数据集处理
for i = 1:length(datasets)
    dataset_name = datasets{i};
    dataset_path = fullfile(data_dir, [dataset_name '.mat']);
    
    fprintf('\n=== 数据集 %d/4: %s ===\n', i, dataset_name);
    
    try
        % 加载数据
        [data, gt] = load_timeseries_mat(dataset_path);
        n_samples = length(gt);
        n_classes = length(unique(gt));
        n_features = size(data, 2);
        
        fprintf('数据信息: %d样本, %d类别, %d维特征\n', n_samples, n_classes, n_features);
        
        % 降维到合理大小
        max_dims = min(50, n_samples-1, n_features);
        if n_features > max_dims
            fprintf('PCA降维: %d -> %d 维\n', n_features, max_dims);
            [~, score] = pca(data);
            data = score(:, 1:max_dims);
        end
        
        % 标准化
        data = zscore(data);
        
        % 设置种子
        rng(42 + i);
        
        %% 简化消融实验
        ablation_acc = zeros(1, 5);
        
        % 1. Baseline K-means++
        fprintf('  1. Baseline K-means++\n');
        Y1 = kmeanspp(data, n_classes, 'Replicates', 3);
        M1 = metrics_eval(gt, Y1);
        ablation_acc(1) = M1.ACC;
        
        % 2. +Graph Diffusion (简化版)
        fprintf('  2. +Graph Diffusion\n');
        k = min(8, n_samples-1);
        
        % 构建简单kNN图
        W = zeros(n_samples, n_samples);
        for j = 1:n_samples
            dists = sum((data - data(j,:)).^2, 2);
            [~, idx] = sort(dists);
            neighbors = idx(2:k+1);
            sigma = median(dists(neighbors));
            W(j, neighbors) = exp(-dists(neighbors) / (2 * sigma^2));
        end
        W = (W + W') / 2;
        
        % 简单谱聚类
        D = diag(sum(W, 2) + eps);
        L = eye(n_samples) - D^(-0.5) * W * D^(-0.5);
        [V, ~] = eigs(L, n_classes, 'smallestabs');
        Y2 = kmeans(real(V), n_classes, 'Replicates', 3);
        M2 = metrics_eval(gt, Y2);
        ablation_acc(2) = M2.ACC;
        
        % 3. +Consensus Clustering
        fprintf('  3. +Consensus Clustering\n');
        consensus_matrix = zeros(n_samples, n_samples);
        num_runs = 8;
        
        for run = 1:num_runs
            Y_temp = kmeans(data, n_classes, 'Replicates', 1);
            for j1 = 1:n_samples
                for j2 = j1+1:n_samples
                    if Y_temp(j1) == Y_temp(j2)
                        consensus_matrix(j1, j2) = consensus_matrix(j1, j2) + 1;
                        consensus_matrix(j2, j1) = consensus_matrix(j2, j1) + 1;
                    end
                end
            end
        end
        consensus_matrix = consensus_matrix / num_runs;
        
        % 谱聚类
        D_cons = diag(sum(consensus_matrix, 2) + eps);
        L_cons = eye(n_samples) - D_cons^(-0.5) * consensus_matrix * D_cons^(-0.5);
        [V_cons, ~] = eigs(L_cons, n_classes, 'smallestabs');
        Y3 = kmeans(real(V_cons), n_classes, 'Replicates', 3);
        M3 = metrics_eval(gt, Y3);
        ablation_acc(3) = M3.ACC;
        
        % 4. +Active Learning (模拟)
        fprintf('  4. +Active Learning\n');
        % 选择10%样本作为标签
        label_ratio = 0.1;
        labeled_idx = [];
        
        for c = 1:n_classes
            class_idx = find(gt == c);
            n_class_labeled = max(1, round(length(class_idx) * label_ratio));
            if length(class_idx) >= n_class_labeled
                class_labeled = randsample(class_idx, n_class_labeled);
                labeled_idx = [labeled_idx; class_labeled];
            end
        end
        
        % 半监督：调整相似矩阵
        W_semi = consensus_matrix;
        for j1 = 1:length(labeled_idx)
            for j2 = j1+1:length(labeled_idx)
                idx1 = labeled_idx(j1);
                idx2 = labeled_idx(j2);
                if gt(idx1) == gt(idx2)  % 同类
                    W_semi(idx1, idx2) = min(1, W_semi(idx1, idx2) + 0.3);
                    W_semi(idx2, idx1) = W_semi(idx1, idx2);
                else  % 异类
                    W_semi(idx1, idx2) = max(0, W_semi(idx1, idx2) - 0.2);
                    W_semi(idx2, idx1) = W_semi(idx1, idx2);
                end
            end
        end
        
        D_semi = diag(sum(W_semi, 2) + eps);
        L_semi = eye(n_samples) - D_semi^(-0.5) * W_semi * D_semi^(-0.5);
        [V_semi, ~] = eigs(L_semi, n_classes, 'smallestabs');
        Y4 = kmeans(real(V_semi), n_classes, 'Replicates', 3);
        M4 = metrics_eval(gt, Y4);
        ablation_acc(4) = M4.ACC;
        
        % 5. +Hard Constraints
        fprintf('  5. +Hard Constraints\n');
        % 构建约束
        constraints_ml = [];
        constraints_cl = [];
        
        % ML约束
        for c = 1:n_classes
            class_labeled = labeled_idx(gt(labeled_idx) == c);
            if length(class_labeled) > 1
                for j1 = 1:min(5, length(class_labeled))  % 限制数量
                    for j2 = j1+1:min(5, length(class_labeled))
                        constraints_ml = [constraints_ml; class_labeled(j1), class_labeled(j2)];
                    end
                end
            end
        end
        
        % CL约束
        for c1 = 1:n_classes
            for c2 = c1+1:n_classes
                class1_labeled = labeled_idx(gt(labeled_idx) == c1);
                class2_labeled = labeled_idx(gt(labeled_idx) == c2);
                if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                    for j1 = 1:min(2, length(class1_labeled))
                        for j2 = 1:min(2, length(class2_labeled))
                            constraints_cl = [constraints_cl; class1_labeled(j1), class2_labeled(j2)];
                        end
                    end
                end
            end
        end
        
        % 硬约束修复
        Y5 = Y4;  % 从主动学习结果开始
        
        for repair_iter = 1:3
            violations = 0;
            
            % 修复ML违规
            for j = 1:size(constraints_ml, 1)
                idx1 = constraints_ml(j, 1);
                idx2 = constraints_ml(j, 2);
                if Y5(idx1) ~= Y5(idx2)
                    Y5(idx2) = Y5(idx1);
                    violations = violations + 1;
                end
            end
            
            % 修复CL违规
            for j = 1:size(constraints_cl, 1)
                idx1 = constraints_cl(j, 1);
                idx2 = constraints_cl(j, 2);
                if Y5(idx1) == Y5(idx2)
                    available_labels = setdiff(1:n_classes, Y5(idx1));
                    if ~isempty(available_labels)
                        Y5(idx2) = available_labels(1);
                        violations = violations + 1;
                    end
                end
            end
            
            if violations == 0
                break;
            end
        end
        
        M5 = metrics_eval(gt, Y5);
        ablation_acc(5) = M5.ACC;
        
        % 存储结果
        all_ablation_results{i} = ablation_acc;
        dataset_success(i) = true;
        
        fprintf('  结果: %.3f -> %.3f -> %.3f -> %.3f -> %.3f\n', ablation_acc);
        fprintf('  总改进: +%.1f%%\n', (ablation_acc(5) - ablation_acc(1)) / ablation_acc(1) * 100);
        
    catch ME
        fprintf('  数据集 %s 失败: %s\n', dataset_name, ME.message);
        all_ablation_results{i} = [NaN, NaN, NaN, NaN, NaN];
        dataset_success(i) = false;
    end
end

%% 生成4子图
fprintf('\n=== 生成4子图消融实验图 ===\n');

if sum(dataset_success) > 0
    figure('Position', [100, 100, 1200, 800]);
    
    % 颜色设置
    colors = [
        0.85, 0.32, 0.32;  % 红色
        0.93, 0.69, 0.13;  % 橙色
        0.47, 0.67, 0.19;  % 绿色
        0.30, 0.75, 0.93;  % 蓝色
        0.49, 0.18, 0.56   % 紫色
    ];
    
    labels = {'Baseline', '+GraphD', '+Consensus', '+Active', '+HardC'};
    
    % 绘制4个子图
    for i = 1:4
        subplot(2, 2, i);
        
        if dataset_success(i)
            accuracies = all_ablation_results{i} * 100;
            baseline = accuracies(1);
            improvements = (accuracies - baseline) / baseline * 100;
            
            bars = bar(accuracies, 'FaceColor', 'flat', 'LineWidth', 1.2);
            bars.CData = colors;
            
            % 添加数值标签
            for j = 1:length(accuracies)
                if j == 1
                    text(j, accuracies(j) + 1, sprintf('%.1f%%', accuracies(j)), ...
                        'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 10);
                else
                    text(j, accuracies(j) + 1, sprintf('+%.1f%%', improvements(j)), ...
                        'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 9, ...
                        'Color', [0, 0.6, 0]);
                end
            end
            
            set(gca, 'XTickLabel', labels);
            xtickangle(45);
            ylabel('Accuracy (%)', 'FontSize', 11);
            title(strrep(datasets{i}, '_', '\_'), 'FontSize', 12, 'FontWeight', 'bold');
            grid on;
            grid minor;
            ylim([min(accuracies) - 3, max(accuracies) + 5]);
            set(gca, 'FontSize', 10);
            
        else
            text(0.5, 0.5, 'Failed', 'HorizontalAlignment', 'center', ...
                'FontSize', 16, 'Color', 'red');
            title(strrep(datasets{i}, '_', '\_'), 'FontSize', 12);
            set(gca, 'XTick', [], 'YTick', []);
        end
    end
    
    % 总标题
    sgtitle('ASCC Ablation Study: 4 EEG Datasets', 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存图片
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    fig_name = sprintf('four_datasets_ablation_%s', timestamp);
    
    print(gcf, [fig_name '.png'], '-dpng', '-r300');
    print(gcf, [fig_name '.eps'], '-depsc2', '-r300');
    
    fprintf('4数据集消融实验图已保存: %s.png 和 %s.eps\n', fig_name, fig_name);
    
    % 计算平均结果
    successful_results = [];
    for i = 1:4
        if dataset_success(i)
            successful_results = [successful_results; all_ablation_results{i}];
        end
    end
    
    if ~isempty(successful_results)
        avg_results = mean(successful_results, 1);
        avg_improvements = (avg_results - avg_results(1)) / avg_results(1) * 100;
        
        fprintf('\n=== 平均结果 ===\n');
        fprintf('Baseline: %.3f\n', avg_results(1));
        fprintf('+Graph Diffusion: %.3f (+%.1f%%)\n', avg_results(2), avg_improvements(2));
        fprintf('+Consensus: %.3f (+%.1f%%)\n', avg_results(3), avg_improvements(3) - avg_improvements(2));
        fprintf('+Active Learning: %.3f (+%.1f%%)\n', avg_results(4), avg_improvements(4) - avg_improvements(3));
        fprintf('+Hard Constraints: %.3f (+%.1f%%)\n', avg_results(5), avg_improvements(5) - avg_improvements(4));
        fprintf('总改进: +%.1f%%\n', avg_improvements(5));
    end
    
    % 保存数据
    save([fig_name '_data.mat'], 'all_ablation_results', 'dataset_success', 'datasets');
    
else
    fprintf('所有数据集都失败了\n');
end

fprintf('\n=== 4数据集消融实验完成 ===\n');
