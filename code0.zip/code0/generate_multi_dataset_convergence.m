function generate_multi_dataset_convergence()
% GENERATE_MULTI_DATASET_CONVERGENCE: 生成多数据集收敛对比图
% 
% 运行5个数据集，提取收敛数据，绘制在一张图上

fprintf('=== 多数据集收敛对比分析 ===\n');

% 添加路径
addpath(genpath(fileparts(mfilename('fullpath'))));

% 创建结果目录
result_dir = 'multi_dataset_convergence';
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 获取数据集文件
data_dir = fullfile('..', 'data');
mat_files = dir(fullfile(data_dir, '*.mat'));
fprintf('发现 %d 个数据集文件\n', length(mat_files));

% 限制为5个数据集
max_datasets = min(5, length(mat_files));
dataset_results = cell(max_datasets, 1);
dataset_names = cell(max_datasets, 1);

% 收敛参数设置（优化为展示收敛过程）
base_params = struct();
base_params.k = 15;
base_params.T = 20;
base_params.r = 20;
base_params.maxRounds = 10;        % 足够的轮数展示收敛
base_params.earlyStop = false;     % 禁用早停
base_params.acceptEps = 1e-6;      % 严格收敛标准
base_params.snnWeight = 0.6;
base_params.alpha = 0.7;
base_params.beta = 0.5;
base_params.gamma = 2.0;

fprintf('\n开始处理数据集...\n');

%% 处理每个数据集
for i = 1:max_datasets
    dataset_file = mat_files(i).name;
    dataset_path = fullfile(data_dir, dataset_file);
    dataset_name = strrep(dataset_file, '.mat', '');
    dataset_names{i} = dataset_name;
    
    fprintf('\n=== 数据集 %d/%d: %s ===\n', i, max_datasets, dataset_name);
    
    try
        % 加载数据集
        [data, gt] = load_timeseries_mat(dataset_path);
        n_samples = length(gt);
        n_classes = length(unique(gt));
        
        fprintf('数据信息: %d个样本, %d个类别\n', n_samples, n_classes);
        
        % 设置当前数据集参数
        current_params = base_params;
        current_params.c = n_classes;
        current_params.k = min(current_params.k, round(n_samples/20));
        
        % 设置随机种子确保可重现
        rng(42 + i);
        
        %% 无监督聚类
        fprintf('运行无监督聚类...\n');
        tic;
        res_unsup = unsupervised_consensus_driver(data, current_params);
        time_unsup = toc;
        fprintf('无监督完成，用时 %.2fs\n', time_unsup);
        
        %% 半监督聚类
        fprintf('运行半监督聚类...\n');
        tic;
        
        % 生成10%约束
        params_sup = current_params;
        params_sup.maxRounds = 8;  % 半监督轮数稍少
        
        % 快速约束生成
        n_constraints = round(n_samples * 0.02);  % 2%的样本对作为约束
        constraints_ml = [];
        constraints_cl = [];
        
        % 生成ML约束（同类样本对）
        for c = 1:n_classes
            class_indices = find(gt == c);
            if length(class_indices) >= 2
                n_pairs = min(round(n_constraints / (2 * n_classes)), nchoosek(length(class_indices), 2));
                for p = 1:n_pairs
                    idx = randsample(class_indices, 2);
                    constraints_ml = [constraints_ml; idx'];
                end
            end
        end
        
        % 生成CL约束（不同类样本对）
        for p = 1:size(constraints_ml, 1)
            % 为每个ML约束生成一个对应的CL约束
            idx1 = constraints_ml(p, 1);
            different_class = find(gt ~= gt(idx1));
            if ~isempty(different_class)
                idx2 = different_class(randi(length(different_class)));
                constraints_cl = [constraints_cl; [idx1, idx2]];
            end
        end
        
        params_sup.constraints_ml = constraints_ml;
        params_sup.constraints_cl = constraints_cl;
        params_sup.ml_weight = 30.0;
        params_sup.cl_weight = 30.0;
        
        fprintf('约束: ML=%d, CL=%d\n', size(constraints_ml, 1), size(constraints_cl, 1));
        
        res_sup = active_semisupervised_consensus_driver(data, params_sup);
        time_sup = toc;
        fprintf('半监督完成，用时 %.2fs\n', time_sup);
        
        % 保存结果
        dataset_results{i} = struct();
        dataset_results{i}.res_unsup = res_unsup;
        dataset_results{i}.res_sup = res_sup;
        dataset_results{i}.n_samples = n_samples;
        dataset_results{i}.n_classes = n_classes;
        
        fprintf('✓ 数据集 %s 处理完成\n', dataset_name);
        
    catch ME
        fprintf('✗ 数据集 %s 处理失败: %s\n', dataset_name, ME.message);
        dataset_results{i} = [];
    end
end

%% 提取所有收敛数据并绘图
fprintf('\n=== 提取收敛数据并绘图 ===\n');

% 创建图形
fig = figure('Position', [100, 100, 1400, 800], 'Visible', 'off');
set(fig, 'Color', 'white');

% 定义颜色方案
colors = [
    0.2, 0.4, 0.8;    % 蓝色
    0.8, 0.2, 0.2;    % 红色
    0.2, 0.7, 0.2;    % 绿色
    0.8, 0.5, 0.2;    % 橙色
    0.6, 0.2, 0.8;    % 紫色
];

line_styles = {'-', '--', '-.', ':', '-'};
markers = {'o', 's', '^', 'd', 'v'};

%% 子图1: 无监督收敛对比
subplot(2, 2, [1, 2]);
hold on;

legend_entries_unsup = {};
for i = 1:max_datasets
    if ~isempty(dataset_results{i})
        res = dataset_results{i};
        
        % 提取无监督收敛数据
        if isfield(res.res_unsup, 'ObjHist') && ~isempty(res.res_unsup.ObjHist)
            rayleigh_data = arrayfun(@(o) real(o.rayleigh), res.res_unsup.ObjHist);
            iterations = 1:length(rayleigh_data);
            
            plot(iterations, rayleigh_data, 'Color', colors(i, :), ...
                 'LineWidth', 2.5, 'LineStyle', line_styles{i}, ...
                 'Marker', markers{i}, 'MarkerSize', 6, 'MarkerFaceColor', colors(i, :));
            
            legend_entries_unsup{end+1} = sprintf('%s (n=%d)', dataset_names{i}, res.n_samples);
            
            fprintf('无监督 %s: %d轮, %.6f -> %.6f\n', dataset_names{i}, ...
                length(rayleigh_data), rayleigh_data(1), rayleigh_data(end));
        end
    end
end

xlabel('Consensus Clustering Iterations', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Rayleigh Quotient', 'FontSize', 12, 'FontWeight', 'bold');
title('Unsupervised ASCC Convergence Comparison', 'FontSize', 14, 'FontWeight', 'bold');
legend(legend_entries_unsup, 'Location', 'best', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 10);

%% 子图2: 半监督收敛对比
subplot(2, 2, 3);
hold on;

legend_entries_sup = {};
for i = 1:max_datasets
    if ~isempty(dataset_results{i})
        res = dataset_results{i};
        
        % 提取半监督收敛数据
        if isfield(res.res_sup, 'history') && ~isempty(res.res_sup.history)
            rayleigh_data = [];
            for j = 1:length(res.res_sup.history)
                if isfield(res.res_sup.history(j), 'obj') && isfield(res.res_sup.history(j).obj, 'rayleigh')
                    rayleigh_data = [rayleigh_data, real(res.res_sup.history(j).obj.rayleigh)];
                end
            end
            
            if ~isempty(rayleigh_data)
                iterations = 1:length(rayleigh_data);
                
                plot(iterations, rayleigh_data, 'Color', colors(i, :), ...
                     'LineWidth', 2.5, 'LineStyle', line_styles{i}, ...
                     'Marker', markers{i}, 'MarkerSize', 6, 'MarkerFaceColor', colors(i, :));
                
                legend_entries_sup{end+1} = sprintf('%s', dataset_names{i});
                
                fprintf('半监督 %s: %d轮, %.6f -> %.6f\n', dataset_names{i}, ...
                    length(rayleigh_data), rayleigh_data(1), rayleigh_data(end));
            end
        end
    end
end

xlabel('Iterations', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Rayleigh Quotient', 'FontSize', 12, 'FontWeight', 'bold');
title('Semi-supervised ASCC Convergence', 'FontSize', 14, 'FontWeight', 'bold');
legend(legend_entries_sup, 'Location', 'best', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 10);

%% 子图3: 收敛速度对比
subplot(2, 2, 4);

convergence_rounds_unsup = [];
convergence_rounds_sup = [];
dataset_labels = {};

for i = 1:max_datasets
    if ~isempty(dataset_results{i})
        res = dataset_results{i};
        
        % 无监督收敛轮数
        if isfield(res.res_unsup, 'ObjHist') && ~isempty(res.res_unsup.ObjHist)
            convergence_rounds_unsup = [convergence_rounds_unsup, length(res.res_unsup.ObjHist)];
        else
            convergence_rounds_unsup = [convergence_rounds_unsup, 0];
        end
        
        % 半监督收敛轮数
        if isfield(res.res_sup, 'history') && ~isempty(res.res_sup.history)
            convergence_rounds_sup = [convergence_rounds_sup, length(res.res_sup.history)];
        else
            convergence_rounds_sup = [convergence_rounds_sup, 0];
        end
        
        dataset_labels{end+1} = dataset_names{i};
    end
end

if ~isempty(convergence_rounds_unsup)
    x_pos = 1:length(dataset_labels);
    width = 0.35;
    
    bar(x_pos - width/2, convergence_rounds_unsup, width, 'FaceColor', [0.2, 0.4, 0.8], 'DisplayName', 'Unsupervised');
    hold on;
    bar(x_pos + width/2, convergence_rounds_sup, width, 'FaceColor', [0.8, 0.2, 0.2], 'DisplayName', 'Semi-supervised');
    
    set(gca, 'XTick', x_pos, 'XTickLabel', dataset_labels, 'XTickLabelRotation', 45);
    ylabel('Convergence Rounds', 'FontSize', 12, 'FontWeight', 'bold');
    title('Convergence Speed Comparison', 'FontSize', 14, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 10);
    grid on;
    set(gca, 'FontSize', 10);
end

% 总标题
sgtitle('Multi-Dataset ASCC Convergence Analysis', 'FontSize', 16, 'FontWeight', 'bold');

%% 保存图形
fig_file_png = fullfile(result_dir, 'multi_dataset_convergence.png');
saveas(fig, fig_file_png, 'png');

fig_file_hires = fullfile(result_dir, 'multi_dataset_convergence_hires.png');
print(fig, fig_file_hires, '-dpng', '-r300');

fig_file_eps = fullfile(result_dir, 'multi_dataset_convergence.eps');
print(fig, fig_file_eps, '-depsc', '-r300');

close(fig);

fprintf('\n✓ 多数据集收敛对比图已保存:\n');
fprintf('  - PNG: %s\n', fig_file_png);
fprintf('  - 高分辨率PNG: %s\n', fig_file_hires);
fprintf('  - EPS: %s\n', fig_file_eps);

%% 保存数据
results_file = fullfile(result_dir, 'convergence_data.mat');
save(results_file, 'dataset_results', 'dataset_names', '-v7.3');
fprintf('  - 数据文件: %s\n', results_file);

fprintf('\n=== 多数据集收敛分析完成 ===\n');

end
