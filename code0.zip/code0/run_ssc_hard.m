function run_ssc_hard()
% SSC-Hard: SSC-Soft + hard constraint repair to enforce zero violations

    clear; clc;

    this_file = mfilename('fullpath');
    [this_dir,~,~] = fileparts(this_file);
    base_dir = fullfile(this_dir, '..');
    data_path  = fullfile(base_dir, 'data','II_Ia_Ib_data.mat');

    addpath(this_dir);

    rng(44,'twister');
    Knn = 5;

    S = load(data_path);
    [fea, gt] = local_extract_fea_gt(S);
    gt = double(gt(:)); [~,~,gt] = unique(gt,'stable');

    % PCA 95% then z-score
    fea = pca_reduce(fea, 0.95);
    mu = mean(fea,1); sd = std(fea,[],1)+1e-8; fea = (fea-mu)./sd;

    k = numel(unique(gt));
    A = build_knn_affinity_local(fea, Knn);

    settings = {'unsup','semi10','semi20'}; ratios=[0,0.10,0.20];
    results = struct();

    cached_idx10 = [];
    for si=1:numel(settings)
        ratio = ratios(si);
        [pairs_ml, pairs_cl, idxL] = sample_pairs_nested(gt, ratio, 44, cached_idx10);
        if isempty(cached_idx10) && ratio>0, cached_idx10 = idxL; end

        [A_tilde, ~, ~] = build_constraint_augmented_affinity(A, pairs_ml, pairs_cl, 20.0, 1.0, 1e-6);
        [DU, ~] = fast_spectral_clustering(A_tilde, k);
        labels0 = seeded_kmeans(DU', k, idxL, gt);

        % Hard repair on embedding DU
        constraints = struct('ml', pairs_ml, 'cl', pairs_cl);
        labels = repair_labels_with_constraints(labels0, constraints, DU, k);

        M = metrics_eval(gt, labels);
        % Count violations
        viol_ml = sum(labels(pairs_ml(:,1)) ~= labels(pairs_ml(:,2)));
        viol_cl = sum(labels(pairs_cl(:,1)) == labels(pairs_cl(:,2)));
        results.(settings{si}) = struct('ACC',M.ACC,'NMI',M.NMI,'ARI',M.ARI,'ViolML',viol_ml,'ViolCL',viol_cl);
    end

    outdir = fullfile(this_dir,'baseline_results'); if ~exist(outdir,'dir'), mkdir(outdir); end
    save(fullfile(outdir,'SSC_Hard_II_Ia_Ib_results.mat'),'results');
    fprintf('SSC-Hard results:\n'); disp(results);
end

function Xr = pca_reduce(X, keepVar)
    X = double(X); X = X - mean(X,1);
    [U,S,~] = svd(X,'econ'); s = diag(S); cs=cumsum(s.^2)/sum(s.^2); d=find(cs>=keepVar,1);
    if isempty(d), d=size(U,2); end
    Xr = U(:,1:d)*S(1:d,1:d);
end

function labels = seeded_kmeans(Y, k, idxL, gt)
    n = size(Y,2);
    if isempty(idxL)
        [labels,~] = kmeanspp(Y, k); return;
    end
    labs = gt(idxL); classes = unique(labs)';
    C0 = zeros(size(Y,1), k);
    for c = classes
        C0(:,c) = mean(Y(:, labs==c), 2);
    end
    missing = setdiff(1:k, classes);
    if ~isempty(missing)
        rp = randperm(n, numel(missing));
        for t=1:numel(missing), C0(:,missing(t)) = Y(:,rp(t)); end
    end
    [labels,~] = kmeans_custom_init(Y, C0);
end

function [L,C] = kmeans_custom_init(X, C0)
    k = size(C0,2); n = size(X,2); C = C0; max_iter=100;
    for iter=1:max_iter
        dists = zeros(k,n);
        for i=1:k, dif=X-C(:,i); dists(i,:)=sum(dif.^2,1); end
        [~, L] = min(dists, [], 1);
        C_old=C; for i=1:k, idx=(L==i); if any(idx), C(:,i)=mean(X(:,idx),2); end; end
        if all(vecnorm(C-C_old)<1e-8), break; end
    end
end

function A = build_knn_affinity_local(fea, Knn)
    N = size(fea,1);
    D = squareform(pdist(fea,'euclidean'));
    [val, idx] = sort(D,2,'ascend');
    sigma_i = mean(val(:,2:Knn+1),2) + eps;
    W = zeros(N);
    for i=1:N
        nn = idx(i,2:Knn+1);
        for j = nn
            sij = exp(-(D(i,j)^2)/(2*(sigma_i(i)*sigma_i(j))));
            W(i,j) = max(W(i,j), sij);
        end
    end
    A = min(W, W');
end

function [pairs_ml, pairs_cl, idxL] = sample_pairs_nested(gt, ratio, seed, idx10)
    gt=gt(:); N=numel(gt); rng(seed,'twister');
    L=round(ratio*N);
    if L<=1, pairs_ml=zeros(0,2); pairs_cl=zeros(0,2); idxL=[]; return; end
    if ~isempty(idx10) && L>numel(idx10)
        rest = setdiff(1:N, idx10);
        add = randperm(numel(rest), L-numel(idx10));
        idxL = [idx10(:); rest(add)'];
    else
        idxL = randperm(N, L)';
    end
    max_pairs = min(4*L, L*(L-1)/2);
    P = nchoosek(idxL,2);
    if size(P,1)>max_pairs, P=P(randperm(size(P,1),max_pairs),:); end
    same = gt(P(:,1))==gt(P(:,2)); pairs_ml=P(same,:); pairs_cl=P(~same,:);
    m=size(pairs_ml,1); c=size(pairs_cl,1); q=min(m,c);
    if q>0
        pairs_ml=pairs_ml(randperm(m,q),:); pairs_cl=pairs_cl(randperm(c,q),:);
    end
end

function [fea, gt] = local_extract_fea_gt(S)
    fea = []; gt = [];
    if isfield(S,'data') && isnumeric(S.data) && ndims(S.data)==2 && size(S.data,2)>=2
        X=S.data; firstCol=X(:,1); looksLabel=isvector(firstCol)&&all(isfinite(firstCol))&&numel(unique(firstCol))<size(X,1);
        if looksLabel, gt=firstCol; fea=X(:,2:end); end
    end
    if isempty(fea)
        candFea={'fea','X','features'}; candGt={'gt','label','labels','y','Y','gnd'};
        for i=1:numel(candFea), f=candFea{i}; if isfield(S,f)&&isnumeric(S.(f))&&ndims(S.(f))==2&&size(S.(f),2)>=2, fea=S.(f); break; end; end
        for j=1:numel(candGt), g=candGt{j}; if isfield(S,g)&&isnumeric(S.(g))&&isvector(S.(g)), gt=S.(g); break; end; end
    end
    if isempty(fea) || isempty(gt)
        fns=fieldnames(S); mats={}; vecs={};
        for t=1:numel(fns)
            v=S.(fns{t}); if isnumeric(v)&&isreal(v)
                if isvector(v), vecs{end+1}=fns{t}; elseif ndims(v)==2&&size(v,1)>=10&&size(v,2)>=2, mats{end+1}=fns{t}; end
            end
        end
        bestName=''; bestScore=-inf;
        for t=1:numel(mats), vn=mats{t}; v=S.(vn); sc=size(v,1)*size(v,2); if sc>bestScore, bestScore=sc; bestName=vn; end; end
        if ~isempty(bestName)
            fea=S.(bestName); N=size(fea,1); gtName='';
            for t=1:numel(vecs), vn=vecs{t}; v=S.(vn); if numel(v)==N, gt=v; gtName=vn; break; end; end
            if isempty(gt)
                firstCol=fea(:,1); if isvector(firstCol)&&all(isfinite(firstCol))&&numel(unique(firstCol))<N, gt=firstCol; fea=fea(:,2:end); end
            end
            if isempty(gt), error('Unrecognized data fields: found feature %s but no label vector', bestName); else
                fprintf('Auto-detected features from %s; labels=%s\n', bestName, gtName);
            end
        end
    end
    fea=double(fea); fea(~isfinite(fea))=0; gt=double(gt);
end
