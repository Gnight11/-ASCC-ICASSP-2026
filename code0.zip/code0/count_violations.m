function [viol_ml, viol_cl] = count_violations(labels, pairs_ml, pairs_cl)
%COUNT_VIOLATIONS Count must-link and cannot-link violations

    viol_ml = 0; viol_cl = 0;
    if ~isempty(pairs_ml)
        for t = 1:size(pairs_ml,1)
            i = pairs_ml(t,1); j = pairs_ml(t,2);
            if labels(i) ~= labels(j)
                viol_ml = viol_ml + 1;
            end
        end
    end
    if ~isempty(pairs_cl)
        for t = 1:size(pairs_cl,1)
            i = pairs_cl(t,1); j = pairs_cl(t,2);
            if labels(i) == labels(j)
                viol_cl = viol_cl + 1;
            end
        end
    end
end

















