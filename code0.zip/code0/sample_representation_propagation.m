function [X_e] = sample_representation_propagation(X_b, Z)
%==========================================================================
% FUNCTION: [X_e] = sample_representation_propagation(X_b, Z)
% DESCRIPTION: This function implements the sample representation propagation
%              step in BKCC framework: X^(e) = X^(b) * Z
%
% INPUTS:   X_b = the binary cluster assignment matrix (n × nc)
%                 where n is the number of samples and nc is the total 
%                 number of clusters across all base clusterings
%           Z   = the enhanced cluster similarity matrix from random walk
%                 diffusion (nc × nc)
%
% OUTPUT:   X_e = the enhanced sample representation matrix (n × nc)
%                 where each row x_i^(e) is the soft representation of 
%                 sample x_i in the multi-scale cluster space
%
%==========================================================================
% This implements Formula BKCC-4: X^(e) = X^(b) * Z
% from the BKCC framework paper
%==========================================================================

% Input validation
if nargin ~= 2
    error('sample_representation_propagation: Requires exactly 2 input arguments.');
end

if ~isnumeric(X_b) || ~isnumeric(Z)
    error('sample_representation_propagation: Both inputs must be numeric matrices.');
end

[n, nc_b] = size(X_b);
[nc_z, ~] = size(Z);

if nc_b ~= nc_z
    error('sample_representation_propagation: Matrix dimensions must match. X_b is %d×%d, Z is %d×%d', n, nc_b, nc_z, nc_z);
end

% Perform the matrix multiplication: X^(e) = X^(b) * Z
X_e = X_b * Z;

end
