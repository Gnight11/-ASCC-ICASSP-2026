function stats = constraint_stats(n, pairs_ml, pairs_cl)
% Compute numbers and比例 of constraints relative to all unordered pairs
    Npairs = n*(n-1)/2;
    num_ml = size(pairs_ml,1);
    num_cl = size(pairs_cl,1);
    stats = struct();
    stats.num_ml = num_ml;
    stats.num_cl = num_cl;
    stats.ratio_ml = num_ml / Npairs;
    stats.ratio_cl = num_cl / Npairs;
    stats.Npairs = Npairs;
end


