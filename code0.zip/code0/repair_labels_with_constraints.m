function Y_new = repair_labels_with_constraints(Y_init, constraints, X, n_classes, max_iter)
% Strict hard-constraint repair (zero-violation guarantee with safe cap)
% Inputs:
%   Y_init      : initial labels (Nx1, 1..K)
%   constraints : struct with fields .ml (Mx2), .cl (Qx2)
%   X           : feature/embedding matrix used to compute centroids (Nxd)
%   n_classes   : K
%   max_iter    : optional, default 50
% Output:
%   Y_new       : repaired labels with no ML/CL violations (if feasible)

    if nargin < 5 || isempty(max_iter), max_iter = 200; end

    Y = Y_init(:);
    N = numel(Y);
    K = n_classes;
    ml = []; cl = [];
    if isfield(constraints,'ml') && ~isempty(constraints.ml), ml = constraints.ml; end
    if isfield(constraints,'cl') && ~isempty(constraints.cl), cl = constraints.cl; end

    % 1) Merge ML connected components via Union-Find
    parent = 1:N; rankUF = zeros(1,N);
    function r = findp(a)
        while parent(a) ~= a
            parent(a) = parent(parent(a));
            a = parent(a);
        end
        r = a;
    end
    function unite(a,b)
        ra = findp(a); rb = findp(b);
        if ra == rb, return; end
        if rankUF(ra) < rankUF(rb)
            parent(ra) = rb;
        elseif rankUF(ra) > rankUF(rb)
            parent(rb) = ra;
        else
            parent(rb) = ra; rankUF(ra) = rankUF(ra) + 1;
        end
    end
    if ~isempty(ml)
        for i=1:size(ml,1)
            a = ml(i,1); b = ml(i,2);
            if a>=1 && a<=N && b>=1 && b<=N
                unite(a,b);
            end
        end
    end

    comp_id = arrayfun(@(i) findp(i), 1:N)';
    comps = unique(comp_id)';

    % 2) Assign each ML-component as a unit to best cluster by centroid gain
    C = compute_centroids(X, Y, K);
    for c = comps
        idx = find(comp_id == c);
        % majority vote of current labels as a hint
        labs = Y(idx);
        vote = mode(labs);
        % choose cluster by minimum mean distance to centroid
        d = sum((C - mean(X(idx,:),1)).^2, 2);
        [~, best] = min(d);
        if ~isfinite(best) || best<1 || best>K
            best = vote;
        end
        Y(idx) = best;
        % update centroid
        C = compute_centroids(X, Y, K);
    end

    % 3) Iteratively fix CL conflicts: if same cluster, move the cheaper one
    function [viol_ml, viol_cl] = count_viol()
        viol_ml = 0; if ~isempty(ml), viol_ml = sum(Y(ml(:,1)) ~= Y(ml(:,2))); end
        viol_cl = 0; if ~isempty(cl), viol_cl = sum(Y(cl(:,1)) == Y(cl(:,2))); end
    end

    iter = 0; 
    while iter < max_iter
        iter = iter + 1;
        changed = false;
        C = compute_centroids(X, Y, K);
        if ~isempty(cl)
            for i=1:size(cl,1)
                a = cl(i,1); b = cl(i,2);
                if Y(a) == Y(b)
                    cur = Y(a);
                    % feasible clusters for a: not containing its ML-group members' clusters conflicts with CL
                    % Move singletons; ML groups already unified, so moving one index implies moving its group
                    ga = comp_id(a); gb = comp_id(b);
                    Ia = find(comp_id==ga); Ib = find(comp_id==gb);
                    % cost to move group Ia to other clusters
                    da = sum((C - mean(X(Ia,:),1)).^2,2); da(cur) = inf;
                    db = sum((C - mean(X(Ib,:),1)).^2,2); db(cur) = inf;
                    [mina, la] = min(da); [minb, lb] = min(db);
                    if mina <= minb
                        Y(Ia) = la;
                    else
                        Y(Ib) = lb;
                    end
                    changed = true;
                end
            end
        end
        if ~changed
            break;
        end
    end

    % 4) Final pass: enforce zero violations deterministically
    %    Move offending groups greedily to nearest feasible cluster until none remain or hard cap
    cap = 50*K; step = 0;
    [vml, vcl] = count_viol();
    while (vml>0 || vcl>0) && step < cap
        step = step + 1;
        C = compute_centroids(X, Y, K);
        % Fix ML first
        if vml>0 && ~isempty(ml)
            bad = find(Y(ml(:,1)) ~= Y(ml(:,2)), 1, 'first');
            a = ml(bad,1); b = ml(bad,2);
            ga = comp_id(a); gb = comp_id(b);
            Ia = find(comp_id==ga); Ib = find(comp_id==gb);
            % merge by assigning both groups to better of their two current clusters (lower mean distance)
            dA = sum((C - mean(X(Ia,:),1)).^2,2); [~, la] = min(dA);
            dB = sum((C - mean(X(Ib,:),1)).^2,2); [~, lb] = min(dB);
            % choose cluster that yields lower combined cost
            cost_la = sum(sum((X([Ia;Ib],:) - C(la,:)).^2,2));
            cost_lb = sum(sum((X([Ia;Ib],:) - C(lb,:)).^2,2));
            if cost_la <= cost_lb
                Y([Ia;Ib]) = la;
            else
                Y([Ia;Ib]) = lb;
            end
        else
            % Fix a CL violation
            bad = find(Y(cl(:,1)) == Y(cl(:,2)), 1, 'first');
            a = cl(bad,1); b = cl(bad,2);
            cur = Y(a);
            ga = comp_id(a); gb = comp_id(b);
            Ia = find(comp_id==ga); Ib = find(comp_id==gb);
            C = compute_centroids(X, Y, K);
            da = sum((C - mean(X(Ia,:),1)).^2,2); da(cur) = inf; [mina, la] = min(da);
            db = sum((C - mean(X(Ib,:),1)).^2,2); db(cur) = inf; [minb, lb] = min(db);
            if mina <= minb
                Y(Ia) = la;
            else
                Y(Ib) = lb;
            end
        end
        [vml, vcl] = count_viol();
    end

    Y_new = Y;
end

function C = compute_centroids(X, Y, K)
    D = size(X,2); C = zeros(K,D);
    for k=1:K
        idx = find(Y==k);
        if isempty(idx)
            C(k,:) = mean(X,1);
        else
            C(k,:) = mean(X(idx,:),1);
        end
    end
end



