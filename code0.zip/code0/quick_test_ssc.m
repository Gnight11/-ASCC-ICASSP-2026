function quick_test_ssc()
%QUICK_TEST_SSC Run a single-shot SSC-Soft and SSC-Hard to validate pipeline

    clear; clc;
    this_file = mfilename('fullpath'); [this_dir,~,~] = fileparts(this_file);
    addpath(this_dir);

    lambda1 = 20; lambda2 = 1; knn = 5;

    fprintf('Quick test SSC-Soft...\n');
    R1 = run_ssc_soft_with_params(lambda1, lambda2, knn);
    disp_struct_metrics('SSC_Soft', R1);

    fprintf('Quick test SSC-Hard...\n');
    R2 = run_ssc_hard_with_params(lambda1, lambda2, knn);
    disp_struct_metrics('SSC_Hard', R2);
end

function disp_struct_metrics(name, R)
    settings = {'unsup','semi10','semi10_hard','semi20','semi20_hard'};
    fprintf('[%s]\n', name);
    for s=1:numel(settings)
        st = settings{s};
        if isfield(R, st)
            res = R.(st);
            acc = getfield_safe(res,'ACC'); nmi=getfield_safe(res,'NMI'); ari=getfield_safe(res,'ARI');
            vml = getfield_safe(res,'ViolML'); vcl = getfield_safe(res,'ViolCL');
            if ~isnan(vml) && ~isnan(vcl)
                fprintf('  %-12s ACC=%.4f NMI=%.4f ARI=%.4f ViolML=%d ViolCL=%d\n', st, acc, nmi, ari, int32(vml), int32(vcl));
            else
                fprintf('  %-12s ACC=%.4f NMI=%.4f ARI=%.4f\n', st, acc, nmi, ari);
            end
        end
    end
end

function v = getfield_safe(s, f)
    if isstruct(s) && isfield(s,f) && ~isempty(s.(f)) && isnumeric(s.(f))
        v = s.(f);
    else
        v = NaN;
    end
end

















