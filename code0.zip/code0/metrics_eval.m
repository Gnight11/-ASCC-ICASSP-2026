function M = metrics_eval(gt, pred)
% Compute clustering metrics: ACC, NMI, ARI (gt optional)
    M = struct('ACC', NaN, 'NMI', NaN, 'ARI', NaN);
    if nargin < 2 || isempty(gt) || isempty(pred)
        fprintf('metrics_eval: 输入为空\n');
        return;
    end
    gt = gt(:); pred = pred(:);
    if numel(gt) ~= numel(pred)
        fprintf('metrics_eval: 维度不匹配 gt=%d, pred=%d\n', numel(gt), numel(pred));
        return; 
    end

    % 调试信息
    fprintf('metrics_eval调试: gt范围[%d,%d], pred范围[%d,%d]\n', min(gt), max(gt), min(pred), max(pred));
    fprintf('metrics_eval调试: gt唯一值=%s, pred唯一值=%s\n', mat2str(unique(gt)), mat2str(unique(pred)));

    % ACC via Hungarian on confusion matrix (with fallbacks)
    K = max(max(gt),max(pred));
    fprintf('metrics_eval调试: 混淆矩阵维度K=%d\n', K);
    CM = zeros(K,K);
    for i=1:numel(gt)
        CM(gt(i), pred(i)) = CM(gt(i), pred(i)) + 1;
    end
    fprintf('metrics_eval调试: 混淆矩阵大小=%s\n', mat2str(size(CM)));
    % Hungarian / assignment
    cost = max(CM(:)) - CM;
    assign = zeros(1,K);
    if exist('munkres','file') == 2
        [assign, ~] = munkres(cost);
    elseif exist('matchpairs','file') == 2
        pairs = matchpairs(cost, 1e12);
        for p=1:size(pairs,1)
            assign(pairs(p,1)) = pairs(p,2);
        end
    else
        % Greedy fallback: iteratively pick global max remaining
        CMcopy = CM;
        rows = 1:K; cols = 1:K;
        for t=1:K
            [~, idx] = max(CMcopy(:));
            [r,c] = ind2sub([K K], idx);
            assign(r) = c;
            CMcopy(r,:) = -inf; CMcopy(:,c) = -inf;
        end
    end
    acc = 0;
    for k=1:K
        if assign(k) > 0
            acc = acc + CM(k, assign(k));
        end
    end
    M.ACC = acc / numel(gt);

    % NMI
    nk = sum(CM,2); nl = sum(CM,1)'; N = sum(nk);
    P = CM / N; pk = nk / N; pl = nl / N;
    I = 0;
    for i=1:K
        for j=1:K
            if P(i,j)>0
                I = I + P(i,j)*log(P(i,j)/(pk(i)*pl(j)) + eps);
            end
        end
    end
    Hk = -sum(pk.*log(pk+eps)); Hl = -sum(pl.*log(pl+eps));
    M.NMI = I / max(Hk, Hl);

    % ARI
    a = sum(nchoosek_vec(nk,2)); b = sum(nchoosek_vec(nl,2));
    c = sum(nchoosek_vec(CM(:),2));
    t = nchoosek(numel(gt),2);
    M.ARI = (c - a*b/t) / (0.5*(a+b) - a*b/t + eps);
end

function s = nchoosek_vec(v, r)
    v = v(:);
    s = sum(v.*(v-1)/2);
end


