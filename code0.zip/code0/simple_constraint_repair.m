function [labels_fixed] = simple_constraint_repair(labels, mustPairs, cannotPairs)
%SIMPLE_CONSTRAINT_REPAIR 简单约束修复：强制满足约束，不优化性能
%
% Inputs:
%   labels      : n x 1 初始标签
%   mustPairs   : m1 x 2 must-link样本对
%   cannotPairs : m2 x 2 cannot-link样本对
%
% Outputs:
%   labels_fixed : n x 1 修复后的标签

labels_fixed = labels;

% 修复must-link违例：将样本移动到同一簇
for t = 1:size(mustPairs,1)
    i = mustPairs(t,1); j = mustPairs(t,2);
    if i <= length(labels_fixed) && j <= length(labels_fixed)
        if labels_fixed(i) ~= labels_fixed(j)
            % 简单策略：将j移动到i的簇
            labels_fixed(j) = labels_fixed(i);
        end
    end
end

% 修复cannot-link违例：将样本移动到不同簇
for t = 1:size(cannotPairs,1)
    i = cannotPairs(t,1); j = cannotPairs(t,2);
    if i <= length(labels_fixed) && j <= length(labels_fixed)
        if labels_fixed(i) == labels_fixed(j)
            % 简单策略：将j移动到不同的簇
            available_clusters = setdiff(1:max(labels_fixed), labels_fixed(i));
            if ~isempty(available_clusters)
                labels_fixed(j) = available_clusters(1);
            else
                % 如果没有可用簇，创建新簇
                labels_fixed(j) = max(labels_fixed) + 1;
            end
        end
    end
end

end




