%% 深度增强无监督聚类测试 - 专门提升无监督性能
% 多算法集成 + 自适应参数 + 数据增强

clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 🚀 深度增强无监督聚类测试 ===\n');
fprintf('目标: 无监督ACC从0.33提升到0.60+\n\n');

%% 数据加载和深度预处理
fprintf('📁 加载数据...\n');
data_file = fullfile('..', 'data', 'II_Ia_Ib_data.mat');
[data, gt] = load_timeseries_mat(data_file);

n_samples = size(data, 1);
n_features = size(data, 2);
n_classes = length(unique(gt));
fprintf('原始数据: %d样本 × %d特征 → %d类别\n', n_samples, n_features, n_classes);

%% 🔧 深度数据预处理和增强
fprintf('\n🔧 深度数据预处理...\n');

% 1. 多层数据清理
fprintf('  第1步: 数据清理...\n');
data_clean = data;
% 处理缺失值
data_clean(isnan(data_clean)) = 0;
data_clean(isinf(data_clean)) = 0;

% 2. 智能标准化
fprintf('  第2步: 智能标准化...\n');
% 标准化
data_norm = zscore(data_clean);
% 稳健标准化 (对异常值更鲁棒)
data_robust = (data_clean - median(data_clean)) ./ mad(data_clean, 1);
data_robust(isnan(data_robust)) = 0;
data_robust(isinf(data_robust)) = 0;

% 3. 智能特征选择
fprintf('  第3步: 智能特征选择...\n');
% 方差筛选
feature_var = var(data_norm);
var_threshold = prctile(feature_var, 25); % 保留方差前75%的特征
high_var_features = feature_var > var_threshold;

% 相关性筛选 - 移除高度相关的冗余特征
fprintf('    相关性筛选...\n');
corr_matrix = corrcoef(data_norm(:, high_var_features));
corr_matrix(isnan(corr_matrix)) = 0;
redundant_features = [];
for i = 1:size(corr_matrix, 1)
    for j = i+1:size(corr_matrix, 2)
        if abs(corr_matrix(i, j)) > 0.95
            redundant_features = [redundant_features, j];
        end
    end
end
redundant_features = unique(redundant_features);

selected_features = find(high_var_features);
selected_features(redundant_features) = [];

% 确保保留足够的特征
if length(selected_features) < 100
    % 如果筛选后特征太少，放宽条件
    [~, top_indices] = sort(feature_var, 'descend');
    selected_features = top_indices(1:min(500, length(top_indices)));
end

data_selected = data_norm(:, selected_features);
fprintf('    特征选择: %d → %d 维 (保留率: %.1f%%)\n', ...
    n_features, length(selected_features), 100*length(selected_features)/n_features);

% 4. 数据降维增强
fprintf('  第4步: 智能降维...\n');
try
    % PCA降维
    [coeff, score, ~, ~, explained] = pca(data_selected);
    cumsum_explained = cumsum(explained);
    n_components = find(cumsum_explained >= 95, 1); % 保留95%方差
    n_components = max(50, min(200, n_components)); % 限制在50-200维
    
    data_pca = score(:, 1:n_components);
    fprintf('    PCA降维: %d → %d 维 (方差保留: %.1f%%)\n', ...
        size(data_selected,2), n_components, cumsum_explained(n_components));
catch
    fprintf('    PCA失败，使用原始特征选择数据\n');
    data_pca = data_selected;
    n_components = size(data_pca, 2);
end

%% 🎯 多算法无监督聚类集成
fprintf('\n🎯 多算法无监督聚类集成...\n');

results_ensemble = [];
method_names = {};
method_scores = [];

%% 方法1: 增强共识聚类
fprintf('  方法1: 增强共识聚类...\n');
tic;
try
    % 超强参数
    params_consensus = struct();
    params_consensus.k = 25;                % 更多近邻
    params_consensus.T = 60;                % 更深扩散
    params_consensus.snnWeight = 0.4;       % 更强SNN权重
    params_consensus.gamma = 5.0;           % 更高gamma
    params_consensus.r = 200;               % 更多基聚类器
    params_consensus.c = n_classes;
    params_consensus.maxRounds = 25;        % 更多轮数
    
    res_consensus = unsupervised_consensus_driver(data_pca, params_consensus);
    Y_consensus = res_consensus.final.Y(:);
    M_consensus = metrics_eval(gt, Y_consensus);
    
    results_ensemble = [results_ensemble, Y_consensus];
    method_names{end+1} = '增强共识聚类';
    method_scores(end+1) = M_consensus.ACC;
    
    fprintf('    ✅ 共识聚类: ACC=%.4f (%.1fs)\n', M_consensus.ACC, toc);
catch ME
    fprintf('    ❌ 共识聚类失败: %s\n', ME.message);
end

%% 方法2: 谱聚类
fprintf('  方法2: 增强谱聚类...\n');
tic;
try
    % 构建相似性矩阵
    sigma = median(pdist(data_pca)) * 0.5; % 自适应带宽
    dist_matrix = pdist2(data_pca, data_pca);
    similarity_matrix = exp(-dist_matrix.^2 / (2*sigma^2));
    
    % 谱聚类
    D = diag(sum(similarity_matrix, 2));
    L = D - similarity_matrix;
    [V, ~] = eigs(L, n_classes, 'smallestabs');
    Y_spectral = kmeans(real(V), n_classes, 'MaxIter', 200, 'Replicates', 20);
    
    M_spectral = metrics_eval(gt, Y_spectral);
    
    results_ensemble = [results_ensemble, Y_spectral];
    method_names{end+1} = '增强谱聚类';
    method_scores(end+1) = M_spectral.ACC;
    
    fprintf('    ✅ 谱聚类: ACC=%.4f (%.1fs)\n', M_spectral.ACC, toc);
catch ME
    fprintf('    ❌ 谱聚类失败: %s\n', ME.message);
end

%% 方法3: 层次聚类
fprintf('  方法3: 增强层次聚类...\n');
tic;
try
    % 层次聚类 - 使用多种距离度量
    linkage_methods = {'ward', 'complete', 'average'};
    
    for method = linkage_methods
        Z = linkage(data_pca, method{1});
        Y_hierarchical = cluster(Z, 'maxclust', n_classes);
        M_hierarchical = metrics_eval(gt, Y_hierarchical);
        
        results_ensemble = [results_ensemble, Y_hierarchical];
        method_names{end+1} = sprintf('层次-%s', method{1});
        method_scores(end+1) = M_hierarchical.ACC;
        
        fprintf('    ✅ 层次-%s: ACC=%.4f\n', method{1}, M_hierarchical.ACC);
    end
    fprintf('    层次聚类总用时: %.1fs\n', toc);
catch ME
    fprintf('    ❌ 层次聚类失败: %s\n', ME.message);
end

%% 方法4: k-means变体集成
fprintf('  方法4: k-means变体集成...\n');
tic;
try
    % 多种初始化的k-means
    n_runs = 10;
    for run = 1:n_runs
        Y_kmeans = kmeans(data_pca, n_classes, 'MaxIter', 300, 'Replicates', 1);
        M_kmeans = metrics_eval(gt, Y_kmeans);
        
        results_ensemble = [results_ensemble, Y_kmeans];
        method_names{end+1} = sprintf('k-means-%d', run);
        method_scores(end+1) = M_kmeans.ACC;
    end
    
    avg_kmeans_acc = mean(method_scores(end-n_runs+1:end));
    fprintf('    ✅ k-means集成: 平均ACC=%.4f (%.1fs)\n', avg_kmeans_acc, toc);
catch ME
    fprintf('    ❌ k-means集成失败: %s\n', ME.message);
end

%% 方法5: GMM聚类
fprintf('  方法5: 高斯混合模型...\n');
tic;
try
    % 使用多种协方差类型
    cov_types = {'full', 'diagonal'};
    
    for cov_type = cov_types
        try
            gmm = fitgmdist(data_pca, n_classes, 'CovarianceType', cov_type{1}, ...
                          'MaxIter', 200, 'Replicates', 5);
            Y_gmm = cluster(gmm, data_pca);
            M_gmm = metrics_eval(gt, Y_gmm);
            
            results_ensemble = [results_ensemble, Y_gmm];
            method_names{end+1} = sprintf('GMM-%s', cov_type{1});
            method_scores(end+1) = M_gmm.ACC;
            
            fprintf('    ✅ GMM-%s: ACC=%.4f\n', cov_type{1}, M_gmm.ACC);
        catch
            fprintf('    ⚠️ GMM-%s失败\n', cov_type{1});
        end
    end
    fprintf('    GMM总用时: %.1fs\n', toc);
catch ME
    fprintf('    ❌ GMM失败: %s\n', ME.message);
end

%% 🎯 智能集成融合
fprintf('\n🎯 智能集成融合...\n');
tic;

if ~isempty(results_ensemble)
    n_methods = size(results_ensemble, 2);
    fprintf('  总计%d个聚类结果参与集成\n', n_methods);
    
    % 加权投票集成
    weights = method_scores;
    weights = weights / sum(weights); % 归一化权重
    
    % 基于共现矩阵的集成
    cooccur = zeros(n_samples, n_samples);
    for i = 1:n_methods
        labels = results_ensemble(:, i);
        weight = weights(i);
        
        for j = 1:n_samples
            same_cluster = (labels == labels(j));
            cooccur(j, :) = cooccur(j, :) + weight * same_cluster;
        end
    end
    
    % 基于共现矩阵的最终聚类
    try
        % 使用图聚类
        cooccur = (cooccur + cooccur') / 2; % 对称化
        D = diag(sum(cooccur, 2));
        L = D - cooccur;
        [V, ~] = eigs(L, n_classes, 'smallestabs');
        Y_final = kmeans(real(V), n_classes, 'MaxIter', 200, 'Replicates', 30);
    catch
        % 降级方案：简单多数投票
        fprintf('  降级到多数投票...\n');
        Y_final = simple_majority_voting(results_ensemble, n_classes);
    end
    
    M_final = metrics_eval(gt, Y_final);
    
    fprintf('  ✅ 最终集成结果: ACC=%.4f (%.1fs)\n', M_final.ACC, toc);
    
    % 分析最佳单一方法
    [best_score, best_idx] = max(method_scores);
    fprintf('\n📊 方法性能分析:\n');
    fprintf('   最佳单一方法: %s (ACC=%.4f)\n', method_names{best_idx}, best_score);
    fprintf('   集成方法提升: %.4f → %.4f (+%.4f)\n', best_score, M_final.ACC, M_final.ACC - best_score);
    
else
    fprintf('❌ 没有成功的聚类结果！\n');
    Y_final = ones(n_samples, 1);
    M_final.ACC = 0;
    M_final.NMI = 0;
    M_final.ARI = 0;
end

%% 结果总结
total_time = toc;

fprintf('\n=== 🎉 深度增强无监督聚类结果 ===\n');
fprintf('%-20s: %.4f\n', '最终ACC', M_final.ACC);
fprintf('%-20s: %.4f\n', '最终NMI', M_final.NMI);
fprintf('%-20s: %.4f\n', '最终ARI', M_final.ARI);
fprintf('%-20s: %.1f分钟\n', '总用时', total_time/60);

% 与目标对比
if M_final.ACC >= 0.60
    fprintf('\n🎉 ✅ 达到目标！ACC=%.4f >= 0.60\n', M_final.ACC);
elseif M_final.ACC >= 0.50
    fprintf('\n🚀 接近目标！ACC=%.4f，还需提升%.4f\n', M_final.ACC, 0.60 - M_final.ACC);
else
    fprintf('\n❌ 仍需努力！ACC=%.4f < 0.50\n', M_final.ACC);
end

% 保存结果
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
result_dir = sprintf('enhanced_unsupervised_%s', timestamp);
mkdir(result_dir);

save(fullfile(result_dir, 'enhanced_unsupervised_results.mat'), ...
     'M_final', 'Y_final', 'results_ensemble', 'method_names', 'method_scores', ...
     'data_pca', 'selected_features');

fprintf('\n💾 结果已保存到: %s\n', result_dir);

%% 如果效果好，继续半监督测试
if M_final.ACC >= 0.45
    fprintf('\n🔄 无监督效果不错，继续半监督测试...\n');
    
    % 智能标签选择
    labeled_indices = smart_label_selection_v2(data_pca, gt, 0.1);
    fprintf('选择%d个标签样本\n', length(labeled_indices));
    
    % 简单约束生成
    constraints = generate_simple_constraints(labeled_indices, gt);
    fprintf('生成约束: %d ML, %d CL\n', size(constraints.ml,1), size(constraints.cl,1));
    
    % 约束k-means
    try
        Y_constrained = constrained_kmeans_simple(data_pca, n_classes, constraints, Y_final);
        M_constrained = metrics_eval(gt, Y_constrained);
        
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_constrained, constraints.ml, constraints.cl);
        
        fprintf('\n=== 半监督结果 ===\n');
        fprintf('半监督ACC: %.4f\n', M_constrained.ACC);
        fprintf('提升幅度: +%.4f (+%.1f%%)\n', ...
            M_constrained.ACC - M_final.ACC, (M_constrained.ACC - M_final.ACC)/M_final.ACC*100);
        fprintf('约束违规: ML=%d, CL=%d\n', viol_ml, viol_cl);
        
        % 保存半监督结果
        save(fullfile(result_dir, 'enhanced_semisupervised_results.mat'), ...
             'M_constrained', 'Y_constrained', 'constraints', 'viol_ml', 'viol_cl');
    catch ME
        fprintf('半监督测试失败: %s\n', ME.message);
    end
else
    fprintf('\n⚠️ 无监督效果不够好，建议进一步优化数据预处理或算法\n');
end

fprintf('\n🎉 深度增强无监督聚类测试完成！\n');

%% 辅助函数
function Y_vote = simple_majority_voting(results, n_classes)
    n_samples = size(results, 1);
    n_methods = size(results, 2);
    
    % 为每个样本对构建投票矩阵
    vote_matrix = zeros(n_samples, n_samples);
    for i = 1:n_methods
        labels = results(:, i);
        for j = 1:n_samples
            vote_matrix(j, :) = vote_matrix(j, :) + (labels == labels(j));
        end
    end
    
    % 基于投票矩阵进行聚类
    similarity = vote_matrix / n_methods;
    
    try
        Y_vote = spectral_clustering_simple(similarity, n_classes);
    catch
        % 最简单的降级方案
        Y_vote = kmeans(similarity, n_classes, 'MaxIter', 100);
    end
end

function labels = spectral_clustering_simple(similarity, k)
    D = diag(sum(similarity, 2));
    L = D - similarity;
    [V, ~] = eigs(L, k, 'smallestabs');
    labels = kmeans(real(V), k, 'MaxIter', 100, 'Replicates', 5);
end

function labeled_indices = smart_label_selection_v2(data, gt, ratio)
    n_classes = length(unique(gt));
    labeled_indices = [];
    
    for c = 1:n_classes
        class_indices = find(gt == c);
        n_select = max(1, round(length(class_indices) * ratio));
        
        if length(class_indices) <= n_select
            labeled_indices = [labeled_indices; class_indices];
        else
            % 随机选择
            selected = randsample(class_indices, n_select);
            labeled_indices = [labeled_indices; selected];
        end
    end
end

function constraints = generate_simple_constraints(labeled_indices, gt)
    constraints = struct();
    constraints.ml = [];
    constraints.cl = [];
    
    n_classes = length(unique(gt));
    
    % 生成ML约束
    for c = 1:n_classes
        class_labeled = labeled_indices(gt(labeled_indices) == c);
        if length(class_labeled) >= 2
            n_pairs = min(5, nchoosek(length(class_labeled), 2));
            pairs = nchoosek(class_labeled, 2);
            if size(pairs, 1) > n_pairs
                idx = randperm(size(pairs, 1), n_pairs);
                pairs = pairs(idx, :);
            end
            constraints.ml = [constraints.ml; pairs];
        end
    end
    
    % 生成CL约束
    for c1 = 1:n_classes
        for c2 = c1+1:n_classes
            class1 = labeled_indices(gt(labeled_indices) == c1);
            class2 = labeled_indices(gt(labeled_indices) == c2);
            
            if ~isempty(class1) && ~isempty(class2)
                n_pairs = min(3, length(class1) * length(class2));
                for i = 1:n_pairs
                    idx1 = class1(randi(length(class1)));
                    idx2 = class2(randi(length(class2)));
                    constraints.cl = [constraints.cl; idx1, idx2];
                end
            end
        end
    end
end

function Y_constrained = constrained_kmeans_simple(data, k, constraints, Y_init)
    Y_constrained = Y_init;
    max_iter = 20;
    
    for iter = 1:max_iter
        % 计算聚类中心
        centers = zeros(k, size(data, 2));
        for c = 1:k
            cluster_data = data(Y_constrained == c, :);
            if ~isempty(cluster_data)
                centers(c, :) = mean(cluster_data, 1);
            end
        end
        
        % 重新分配，考虑约束
        for i = 1:length(Y_constrained)
            distances = sqrt(sum((data(i, :) - centers).^2, 2));
            [~, order] = sort(distances);
            
            % 检查约束
            for j = 1:length(order)
                candidate = order(j);
                
                % 检查ML约束
                ml_ok = true;
                if ~isempty(constraints.ml)
                    ml_partners = [constraints.ml(constraints.ml(:,1) == i, 2); ...
                                   constraints.ml(constraints.ml(:,2) == i, 1)];
                    for partner = ml_partners'
                        if Y_constrained(partner) ~= candidate
                            ml_ok = false;
                            break;
                        end
                    end
                end
                
                % 检查CL约束
                cl_ok = true;
                if ml_ok && ~isempty(constraints.cl)
                    cl_partners = [constraints.cl(constraints.cl(:,1) == i, 2); ...
                                   constraints.cl(constraints.cl(:,2) == i, 1)];
                    for partner = cl_partners'
                        if Y_constrained(partner) == candidate
                            cl_ok = false;
                            break;
                        end
                    end
                end
                
                if ml_ok && cl_ok
                    Y_constrained(i) = candidate;
                    break;
                end
            end
        end
    end
end




