% BATCH_TEST_CONVERGENCE_DEMO: 专门用于展示收敛曲线的测试版本
% 
% 调整参数以获得更好的收敛过程可视化
%
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

% 创建结果目录
result_dir = sprintf('convergence_demo_%s', datestr(now, 'yyyymmdd_HHMMSS'));
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 创建日志文件
log_file = fullfile(result_dir, 'convergence_demo_log.txt');
diary(log_file);
diaryGuard = onCleanup(@() diary('off'));
diary on;

fprintf('=== 收敛曲线演示测试开始 ===\n');
fprintf('测试时间: %s\n', datestr(now));
fprintf('结果保存目录: %s\n', result_dir);

% 获取数据集文件
data_dir = fullfile('..', 'data');
mat_files = dir(fullfile(data_dir, '*.mat'));
fprintf('发现 %d 个数据集文件\n\n', length(mat_files));

% 收敛演示参数（设计为显示渐进收敛过程）
convergence_params = struct();
convergence_params.k = 20;                   % 适中的近邻数
convergence_params.T = 30;                   % 适中的扩散步数
convergence_params.snnWeight = 0.6;          % 较低的SNN权重，允许更多迭代
convergence_params.gamma = 2.0;              % 较低的gamma值
convergence_params.r = 40;                   % 适中的基聚类器数量
convergence_params.maxRounds = 15;           % 增加轮数以展示收敛过程
convergence_params.earlyStop = false;        % 禁用早停，强制运行更多轮
convergence_params.acceptEps = 1e-6;         % 更严格的收敛标准
convergence_params.alpha = 0.7;              % 适中的扩散系数
convergence_params.beta = 0.5;               % 平衡参数

% 选择一个代表性数据集进行演示
demo_dataset_idx = 1; % 使用第一个数据集
if demo_dataset_idx <= length(mat_files)
    dataset_file = mat_files(demo_dataset_idx).name;
    dataset_path = fullfile(data_dir, dataset_file);
    dataset_name = strrep(dataset_file, '.mat', '');
    
    fprintf('=== 收敛演示数据集: %s ===\n', dataset_name);
    
    try
        % 加载数据集
        [data, gt] = load_timeseries_mat(dataset_path);
        
        % 数据基本信息
        n_samples = length(gt);
        n_classes = length(unique(gt));
        n_features = size(data, 2);
        fprintf('数据信息: %d个样本, %d个类别, %d维特征\n', n_samples, n_classes, n_features);
        
        % 设置当前数据集的参数
        current_params = convergence_params;
        current_params.c = n_classes;
        
        % 设置随机种子以确保可重现性
        rng('default');
        rng(42);
        
        %% 1. 渐进收敛的无监督聚类
        fprintf('\n--- 渐进收敛无监督聚类 ---\n');
        tic;
        params_unsup = current_params;
        params_unsup.maxRounds = 12;           % 足够的轮数
        params_unsup.earlyStop = false;        % 禁用早停
        params_unsup.acceptEps = 1e-7;         % 非常严格的收敛标准
        params_unsup.r = 25;                   % 减少基聚类器数量增加变化
        params_unsup.k = min(18, round(n_samples/15)); % 适中的近邻数
        params_unsup.T = 25;                   % 适中的扩散步数
        params_unsup.snnWeight = 0.5;          % 较低的SNN权重
        params_unsup.alpha = 0.6;              % 较低的扩散系数
        params_unsup.beta = 0.4;               % 较低的平衡参数
        params_unsup.gamma = 1.5;              % 较低的gamma值
        
        fprintf('参数设置: maxRounds=%d, acceptEps=%.1e, r=%d, k=%d\n', ...
            params_unsup.maxRounds, params_unsup.acceptEps, params_unsup.r, params_unsup.k);
        
        res_unsup = unsupervised_consensus_driver(data, params_unsup);
        Y_unsup = res_unsup.final.Y(:);
        M_unsup = metrics_eval(gt, Y_unsup);
        time_unsup = toc;
        
        fprintf('无监督结果: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
            M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
        
        %% 2. 渐进收敛的半监督聚类
        fprintf('\n--- 渐进收敛半监督聚类 ---\n');
        tic;
        
        % 渐进收敛参数配置
        params_sup = current_params;
        params_sup.maxRounds = 10;             % 足够的轮数
        params_sup.earlyStop = false;          % 禁用早停
        params_sup.acceptEps = 1e-7;           % 严格的收敛标准
        params_sup.r = 30;                     % 适中的基聚类器数量
        params_sup.k = min(20, round(n_samples/12)); % 适中的近邻数
        params_sup.T = 20;                     % 适中的扩散步数
        params_sup.snnWeight = 0.6;            % 适中SNN权重
        params_sup.lambda = 0.5;               % 较低的约束权重，允许渐进改进
        params_sup.alpha = 0.7;                % 适中扩散系数
        params_sup.beta = 0.5;                 % 平衡参数
        params_sup.gamma = 0.3;                % 较低的正则化参数
        
        % 生成10%约束
        label_ratio = 0.10;
        n_labeled = round(n_samples * label_ratio);
        labeled_indices = [];
        
        % 确保每个类别都有标签
        for c = 1:n_classes
            class_indices = find(gt == c);
            n_class_labeled = max(2, round(length(class_indices) * label_ratio));
            class_labeled = randsample(class_indices, min(n_class_labeled, length(class_indices)));
            labeled_indices = [labeled_indices; class_labeled];
        end
        
        % 创建约束
        constraints = struct();
        constraints.ml = [];
        constraints.cl = [];
        
        % 基于标签样本的10%约束生成
        labeled_pairs = length(labeled_indices) * (length(labeled_indices) - 1) / 2;
        constraint_ratio = 0.10;
        total_constraints = round(labeled_pairs * constraint_ratio);
        num_ml = round(total_constraints / 2);
        num_cl = total_constraints - num_ml;
        
        fprintf('约束生成: 标签样本=%d, 总约束=%d (ML=%d, CL=%d)\n', ...
            length(labeled_indices), total_constraints, num_ml, num_cl);
        
        % 生成ML约束
        labeled_gt = gt(labeled_indices);
        unique_classes = unique(labeled_gt);
        
        % 预分配
        constraints.ml = zeros(num_ml, 2);
        constraints.cl = zeros(num_cl, 2);
        
        % 生成ML约束
        ml_count = 0;
        for attempt = 1:num_ml*3
            if ml_count >= num_ml, break; end
            
            % 随机选择同类的两个样本
            class_idx = unique_classes(randi(length(unique_classes)));
            class_samples = labeled_indices(labeled_gt == class_idx);
            
            if length(class_samples) >= 2
                idx = randperm(length(class_samples), 2);
                p1 = class_samples(idx(1));
                p2 = class_samples(idx(2));
                
                % 检查重复
                if ~any(all(constraints.ml(1:ml_count, :) == [min(p1,p2), max(p1,p2)], 2))
                    ml_count = ml_count + 1;
                    constraints.ml(ml_count, :) = [p1, p2];
                end
            end
        end
        
        % 生成CL约束
        cl_count = 0;
        for attempt = 1:num_cl*3
            if cl_count >= num_cl, break; end
            
            % 随机选择不同类的两个样本
            if length(unique_classes) >= 2
                class_indices = randperm(length(unique_classes), 2);
                class1_samples = labeled_indices(labeled_gt == unique_classes(class_indices(1)));
                class2_samples = labeled_indices(labeled_gt == unique_classes(class_indices(2)));
                
                if ~isempty(class1_samples) && ~isempty(class2_samples)
                    p1 = class1_samples(randi(length(class1_samples)));
                    p2 = class2_samples(randi(length(class2_samples)));
                    
                    % 检查重复
                    if ~any(all(constraints.cl(1:cl_count, :) == [min(p1,p2), max(p1,p2)], 2))
                        cl_count = cl_count + 1;
                        constraints.cl(cl_count, :) = [p1, p2];
                    end
                end
            end
        end
        
        % 裁剪到实际大小
        constraints.ml = constraints.ml(1:ml_count, :);
        constraints.cl = constraints.cl(1:cl_count, :);
        
        % 设置约束参数
        params_sup.constraints_ml = constraints.ml;
        params_sup.constraints_cl = constraints.cl;
        params_sup.ml_weight = 50.0;            % 适中的约束权重
        params_sup.cl_weight = 50.0;
        params_sup.max_repair_iterations = 15;  % 适中的修复迭代
        params_sup.force_repair = true;
        params_sup.repair_strength = 0.8;       % 适中的修复强度
        params_sup.lambda1 = 1.0;               % 适中的ML约束
        params_sup.lambda2 = 1.0;               % 适中的CL约束
        
        fprintf('最终约束: ML=%d个, CL=%d个\n', size(constraints.ml, 1), size(constraints.cl, 1));
        
        % 运行半监督聚类
        res_sup = active_semisupervised_consensus_driver(data, params_sup);
        Y_sup = res_sup.final.Y(:);
        M_sup = metrics_eval(gt, Y_sup);
        time_sup = toc;
        
        fprintf('半监督结果: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
            M_sup.ACC, M_sup.NMI, M_sup.ARI, time_sup);
        
        % 检查约束违规
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup, constraints.ml, constraints.cl);
        fprintf('约束违规: ML=%d, CL=%d\n', viol_ml, viol_cl);
        
        %% 3. 生成收敛曲线
        fprintf('\n--- 生成收敛曲线 ---\n');
        
        % 调试收敛数据
        debug_convergence_data(res_unsup, res_sup, dataset_name);
        
        % 生成收敛图
        try
            plot_convergence_robust(res_unsup, res_sup, dataset_name, result_dir);
            fprintf('✓ 收敛曲线已生成\n');
        catch conv_err
            fprintf('✗ 收敛曲线生成失败: %s\n', conv_err.message);
            
            % 备用方案
            try
                plot_convergence_analysis(res_unsup, res_sup, dataset_name, result_dir);
                fprintf('✓ 使用备用方案生成收敛曲线\n');
            catch conv_err2
                fprintf('✗ 备用方案也失败: %s\n', conv_err2.message);
            end
        end
        
        fprintf('\n收敛演示完成！\n');
        fprintf('结果保存在: %s\n', result_dir);
        
    catch ME
        fprintf('收敛演示失败: %s\n', ME.message);
        fprintf('错误位置: %s (行 %d)\n', ME.stack(1).name, ME.stack(1).line);
    end
else
    fprintf('没有找到数据集文件\n');
end

%% 本地函数
function [ml_violations, cl_violations] = check_constraint_violations_local(labels, ml_constraints, cl_constraints)
    ml_violations = 0;
    cl_violations = 0;
    
    % 检查must-link违规
    if ~isempty(ml_constraints)
        for i = 1:size(ml_constraints, 1)
            idx1 = ml_constraints(i, 1);
            idx2 = ml_constraints(i, 2);
            if labels(idx1) ~= labels(idx2)
                ml_violations = ml_violations + 1;
            end
        end
    end
    
    % 检查cannot-link违规
    if ~isempty(cl_constraints)
        for i = 1:size(cl_constraints, 1)
            idx1 = cl_constraints(i, 1);
            idx2 = cl_constraints(i, 2);
            if labels(idx1) == labels(idx2)
                cl_violations = cl_violations + 1;
            end
        end
    end
end
