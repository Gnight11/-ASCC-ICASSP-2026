function X_reduced = pca_reduce(X, target_variance_ratio)
%PCA_REDUCE Reduce features by PCA retaining target variance ratio (e.g., 0.95)
%   X: N x D data matrix
%   target_variance_ratio: between 0 and 1
%   Returns X_reduced: N x d, d chosen to meet variance threshold

    if nargin < 2 || isempty(target_variance_ratio)
        target_variance_ratio = 0.95;
    end
    X = double(X);
    X(~isfinite(X)) = 0;

    % Center
    mu = mean(X, 1);
    Xc = bsxfun(@minus, X, mu);

    % SVD-based PCA
    [U, S, V] = svd(Xc, 'econ'); %#ok<ASGLU>
    sing_vals = diag(S);
    variances = sing_vals .^ 2;  % proportional to explained variance
    total_var = sum(variances);
    if total_var <= 0
        X_reduced = Xc; % nothing to reduce
        return;
    end
    cum_ratio = cumsum(variances) / total_var;
    d = find(cum_ratio >= target_variance_ratio, 1, 'first');
    if isempty(d)
        d = size(V, 2);
    end
    d = max(1, d);

    % Project
    W = V(:, 1:d);
    X_reduced = Xc * W;
end

















