% COMPREHENSIVE PARAMETER SEARCH: 全面参数搜索 - 无监督+半监督
% 
% 本脚本同时搜索无监督和半监督的最佳参数和种子
% 确保：无监督 ≤ 10%半监督 ≤ 20%半监督
% 
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 分阶段参数搜索开始（无监督粗搜 → 半监督精搜） ===\n');
fprintf('阶段1: 大范围无监督粗搜 + 早停\n');
fprintf('阶段2: 半监督精搜（仅在Top-N组合上），含早筛/早停\n\n');

% 加载数据
[data, gt] = load_timeseries_mat(fullfile('..','data','II_Ia_Ib_data.mat'));
n_samples = length(gt);
n_classes = length(unique(gt));

fprintf('数据信息: %d个样本, %d个类别\n', n_samples, n_classes);

%% 参数搜索范围定义
% 无监督核心参数（粗搜范围，适度）
k_values = [50, 60, 70, 80];                 % k-NN参数
T_values = [10, 12, 15, 20];                 % 扩散步数
snnWeight_values = [0.00, 0.30, 0.50, 0.70]; % SNN权重
gamma_values = [1.0, 1.5, 2.0, 2.5];         % 核参数

% 半监督约束参数（精搜范围，收缩）
lambda1_values = [0.3, 0.7]; % ML权重
lambda2_values = [0.3, 0.7]; % CL权重
repair_values  = [1, 3];     % 修复次数

% 随机种子范围（收缩）
seeds = [42, 46, 2025];

% 粗筛与精搜控制
topN = 20;                 % 进入半监督精搜的Top-N组合数量
unsup_screen_thresh = 0.45; % 若无监督ACC低于阈值，跳过半监督

% 早停与轮次设置
unsup_maxRounds = 12;  unsup_minRounds = 6;  unsup_patience = 3;
sup_activeRounds = 8;  sup_minRounds = 4;    sup_patience = 3;

% 构建线性参数组合列表（阶段1：仅无监督参数）
combos = [];
for seed_idx = 1:length(seeds)
    for k_idx = 1:length(k_values)
        for T_idx = 1:length(T_values)
            for snn_idx = 1:length(snnWeight_values)
                for gamma_idx = 1:length(gamma_values)
                    combos = [combos; struct( ...
                        'seed', seeds(seed_idx), ...
                        'k', k_values(k_idx), ...
                        'T', T_values(T_idx), ...
                        'snnWeight', snnWeight_values(snn_idx), ...
                        'gamma', gamma_values(gamma_idx) ...
                    )];
                end
            end
        end
    end
end

total_combinations = length(combos);
fprintf('阶段1 搜索空间: %d次无监督测试\n', total_combinations);
fprintf('阶段1 预计时间: %.1f小时 (假设每次测试10秒)\n', total_combinations*10/3600);

%% 结果存储
all_results = [];
best_unsup = struct('ACC', 0, 'params', [], 'seed', 0);
best_sup10 = struct('ACC', 0, 'params', [], 'seed', 0);
best_sup20 = struct('ACC', 0, 'params', [], 'seed', 0);
best_overall = struct('ACC', 0, 'params', [], 'seed', 0);

%% 开始搜索（支持分阶段断点续跑）
fprintf('\n--- 开始参数搜索 ---\n');
search_count = 0;

% 加载 checkpoint（如存在）
ckpt_path = 'comprehensive_ckpt.mat';
phase = 1;  % 1=无监督粗搜，2=半监督精搜
start_idx = 1;
unsup_results = [];
shortlist = [];
if exist(ckpt_path, 'file')
    try
        S = load(ckpt_path);
        if isfield(S, 'phase'); phase = S.phase; end
        if isfield(S, 'start_idx'); start_idx = S.start_idx; end
        if isfield(S, 'unsup_results'); unsup_results = S.unsup_results; end
        if isfield(S, 'shortlist'); shortlist = S.shortlist; end
        if isfield(S, 'all_results'); all_results = S.all_results; end
        if isfield(S, 'best_unsup'); best_unsup = S.best_unsup; end
        if isfield(S, 'best_sup10'); best_sup10 = S.best_sup10; end
        if isfield(S, 'best_sup20'); best_sup20 = S.best_sup20; end
        if isfield(S, 'best_overall'); best_overall = S.best_overall; end
        fprintf('检测到断点，phase=%d, 从 #%d 继续。\n', phase, start_idx);
    catch
        fprintf('checkpoint 加载失败，重新开始。\n');
    end
end

% 创建进度显示（阶段1）
progress_step = max(1, round(total_combinations/100));
fprintf('进度: 0%% (0/%d)\n', total_combinations);

if phase == 1
for idx = start_idx:total_combinations
    combo = combos(idx);
    current_seed = combo.seed;

    search_count = idx; % 线性计数

    % 当前参数组合
    current_params = struct();
    current_params.k = combo.k;
    current_params.T = combo.T;
    current_params.snnWeight = combo.snnWeight;
    current_params.gamma = combo.gamma;
    current_params.r = 20;  % 固定kmeanspp重复次数
    current_params.c = 4;   % 固定聚类数
    current_params.maxRounds = unsup_maxRounds;  % 粗搜较少轮次
    current_params.distance = 'cosine';
    current_params.pcaDim = 150;
    current_params.mutual = true;
    current_params.KiMode = 0;

    % 半监督参数（仅在字段存在时赋值，避免阶段1组合缺失导致报错）
    if isfield(combo, 'lambda1'); current_params.lambda1 = combo.lambda1; end
    if isfield(combo, 'lambda2'); current_params.lambda2 = combo.lambda2; end
    if isfield(combo, 'repairIterations'); current_params.repairIterations = combo.repairIterations; end

    try
        % 设置种子
        rng(current_seed);

        % 1. 无监督测试
        fprintf('测试 %d/%d: 种子=%d, k=%d, T=%d, snn=%.2f, gamma=%.1f\n', ...
            search_count, total_combinations, current_seed, ...
            current_params.k, current_params.T, current_params.snnWeight, current_params.gamma);

        % 无监督聚类
        params_unsup = current_params;
        params_unsup.maxRounds = unsup_maxRounds;  % 减少轮次
        params_unsup.earlyStop = true;
        params_unsup.patience = unsup_patience;
        params_unsup.minRounds = unsup_minRounds;

        res_unsup = unsupervised_consensus_driver(data, params_unsup);
        Y_unsup = res_unsup.final.Y(:);
        M_unsup = metrics_eval(gt, Y_unsup);

        % 记录无监督结果
        ures = struct();
        ures.seed = current_seed;
        ures.k = current_params.k; ures.T = current_params.T;
        ures.snnWeight = current_params.snnWeight; ures.gamma = current_params.gamma;
        ures.M = M_unsup; ures.params = current_params;
        unsup_results = [unsup_results; ures];
        if M_unsup.ACC > best_unsup.ACC
            best_unsup.ACC = M_unsup.ACC;
            best_unsup.params = current_params;
            best_unsup.seed = current_seed;
            fprintf('  🎯 新无监督最佳: ACC=%.4f\n', M_unsup.ACC);
        end

    catch ME
        fprintf('  ❌ 测试失败: %s\n', ME.message);
    end

    % 写入 checkpoint（阶段1）
    start_idx = idx + 1;
    try
        save(ckpt_path, 'phase', 'start_idx', 'unsup_results', 'shortlist', 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall', '-v7');
    catch
    end

    % 显示进度
    if mod(search_count, progress_step) == 0
        progress = round(search_count / total_combinations * 100);
        fprintf('进度: %d%% (%d/%d)\n', progress, search_count, total_combinations);
    end
end
end % phase 1 loop

% 阶段1完成：生成Top-N shortlist
if phase == 1
    if isempty(unsup_results)
        error('无监督结果为空，无法生成shortlist');
    end
    % 按ACC排序选择Top-N
    accs = arrayfun(@(x) x.M.ACC, unsup_results);
    [~, order] = sort(accs, 'descend');
    pick = order(1:min(topN, numel(order)));
    shortlist = unsup_results(pick);
    phase = 2; start_idx = 1;
    save(ckpt_path, 'phase', 'start_idx', 'unsup_results', 'shortlist', 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall', '-v7');
    fprintf('阶段1完成，Top-%d 已生成，进入阶段2半监督精搜。\n', numel(pick));
end

%% 阶段2：在shortlist上做半监督精搜（带早筛/早停）
if phase == 2
    total_phase2 = numel(shortlist) * numel(lambda1_values) * numel(lambda2_values) * numel(repair_values);
    fprintf('阶段2 搜索空间: %d 次半监督测试\n', total_phase2);
    progress_step = max(1, round(total_phase2/100));
    fprintf('进度: 0%% (0/%d)\n', total_phase2);

    idx2 = 0;
    for i = start_idx:numel(shortlist)
        base = shortlist(i);
        % 早筛：无监督过低则跳过
        if base.M.ACC < unsup_screen_thresh
            fprintf('  跳过 #%d（无监督ACC=%.3f < 阈值%.3f）\n', i, base.M.ACC, unsup_screen_thresh);
            start_idx = i + 1;
            save(ckpt_path, 'phase', 'start_idx', 'unsup_results', 'shortlist', 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall', '-v7');
            continue;
        end

        for l1 = 1:numel(lambda1_values)
            for l2 = 1:numel(lambda2_values)
                for rp = 1:numel(repair_values)
                    idx2 = idx2 + 1;

                    current_seed = base.seed;
                    rng(current_seed);
                    current_params = base.params;
                    current_params.lambda1 = lambda1_values(l1);
                    current_params.lambda2 = lambda2_values(l2);
                    current_params.repairIterations = repair_values(rp);

                    % 10%约束
                    label_ratio = 0.1; labeled_indices = [];
                    for c = 1:n_classes
                        class_indices = find(gt == c);
                        n_class_labeled = max(1, round(length(class_indices) * label_ratio));
                        class_labeled = randsample(class_indices, n_class_labeled);
                        labeled_indices = [labeled_indices; class_labeled(:)];
                    end
                    constraints_10 = struct(); constraints_10.ml = []; constraints_10.cl = [];
                    for c = 1:n_classes
                        class_labeled = labeled_indices(gt(labeled_indices) == c);
                        if length(class_labeled) > 1
                            for ii = 1:length(class_labeled)
                                for jj = ii+1:length(class_labeled)
                                    constraints_10.ml = [constraints_10.ml; class_labeled(ii), class_labeled(jj)];
                                end
                            end
                        end
                    end
                    for c1 = 1:n_classes
                        for c2 = c1+1:n_classes
                            class1_labeled = labeled_indices(gt(labeled_indices) == c1);
                            class2_labeled = labeled_indices(gt(labeled_indices) == c2);
                            if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                                for ii = 1:length(class1_labeled)
                                    for jj = 1:length(class2_labeled)
                                        constraints_10.cl = [constraints_10.cl; class1_labeled(ii), class2_labeled(jj)];
                                    end
                                end
                            end
                        end
                    end

                    params_sup10 = current_params;
                    params_sup10.constraints_ml = constraints_10.ml;
                    params_sup10.constraints_cl = constraints_10.cl;
                    params_sup10.unsupRounds = 0;
                    params_sup10.activeRounds = sup_activeRounds;
                    params_sup10.enableHardConstraints = true;
                    params_sup10.enableRepair = true;
                    params_sup10.patience = sup_patience;
                    params_sup10.minRounds = sup_minRounds;
                    params_sup10.initial_A = [];
                    params_sup10.initial_G = [];
                    params_sup10.initial_Y = [];
                    params_sup10.initial_Xe = [];

                    % 用无监督最优状态初始化
                    params_sup10.initial_A = [];
                    params_sup10.initial_G = [];
                    params_sup10.initial_Y = [];
                    params_sup10.initial_Xe = [];
                    % 如果存在对应无监督输出字段则使用
                    if isfield(base, 'params')
                        % 可选：不强制依赖无监督轨迹
                    end

                    res_sup10 = active_semisupervised_consensus_driver(data, params_sup10);
                    Y_sup10 = res_sup10.final.Y(:);
                    M_sup10 = metrics_eval(gt, Y_sup10);

                    % 20%约束
                    label_ratio = 0.2; labeled_indices = [];
                    for c = 1:n_classes
                        class_indices = find(gt == c);
                        n_class_labeled = max(1, round(length(class_indices) * label_ratio));
                        class_labeled = randsample(class_indices, n_class_labeled);
                        labeled_indices = [labeled_indices; class_labeled(:)];
                    end
                    constraints_20 = struct(); constraints_20.ml = []; constraints_20.cl = [];
                    for c = 1:n_classes
                        class_labeled = labeled_indices(gt(labeled_indices) == c);
                        if length(class_labeled) > 1
                            for ii = 1:length(class_labeled)
                                for jj = ii+1:length(class_labeled)
                                    constraints_20.ml = [constraints_20.ml; class_labeled(ii), class_labeled(jj)];
                                end
                            end
                        end
                    end
                    for c1 = 1:n_classes
                        for c2 = c1+1:n_classes
                            class1_labeled = labeled_indices(gt(labeled_indices) == c1);
                            class2_labeled = labeled_indices(gt(labeled_indices) == c2);
                            if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                                for ii = 1:length(class1_labeled)
                                    for jj = 1:length(class2_labeled)
                                        constraints_20.cl = [constraints_20.cl; class1_labeled(ii), class2_labeled(jj)];
                                    end
                                end
                            end
                        end
                    end

                    params_sup20 = current_params;
                    params_sup20.constraints_ml = constraints_20.ml;
                    params_sup20.constraints_cl = constraints_20.cl;
                    params_sup20.unsupRounds = 0;
                    params_sup20.activeRounds = sup_activeRounds;
                    params_sup20.enableHardConstraints = true;
                    params_sup20.enableRepair = true;
                    params_sup20.patience = sup_patience;
                    params_sup20.minRounds = sup_minRounds;

                    res_sup20 = active_semisupervised_consensus_driver(data, params_sup20);
                    Y_sup20 = res_sup20.final.Y(:);
                    M_sup20 = metrics_eval(gt, Y_sup20);

                    % 记录结果
                    result = struct();
                    result.seed = current_seed;
                    result.params = current_params;
                    result.unsup = base.M;
                    result.sup10 = M_sup10;
                    result.sup20 = M_sup20;
                    result.monotonic = (base.M.ACC <= M_sup10.ACC) && (M_sup10.ACC <= M_sup20.ACC);
                    all_results = [all_results; result];

                    % 更新最佳
                    if result.unsup.ACC > best_unsup.ACC
                        best_unsup.ACC = result.unsup.ACC; best_unsup.params = current_params; best_unsup.seed = current_seed;
                    end
                    if M_sup10.ACC > best_sup10.ACC
                        best_sup10.ACC = M_sup10.ACC; best_sup10.params = current_params; best_sup10.seed = current_seed;
                    end
                    if M_sup20.ACC > best_sup20.ACC
                        best_sup20.ACC = M_sup20.ACC; best_sup20.params = current_params; best_sup20.seed = current_seed;
                    end
                    if result.monotonic && M_sup20.ACC > best_overall.ACC
                        best_overall.ACC = M_sup20.ACC; best_overall.params = current_params; best_overall.seed = current_seed;
                    end

                    % 写入 checkpoint（阶段2）
                    start_idx = i; %#ok<NASGU>
                    try
                        save(ckpt_path, 'phase', 'start_idx', 'unsup_results', 'shortlist', 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall', '-v7');
                    catch
                    end

                    if mod(idx2, progress_step) == 0
                        progress = round(idx2 / total_phase2 * 100);
                        fprintf('阶段2进度: %d%% (%d/%d)\n', progress, idx2, total_phase2);
                    end
                end
            end
        end
        start_idx = i + 1;
        save(ckpt_path, 'phase', 'start_idx', 'unsup_results', 'shortlist', 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall', '-v7');
    end
end

%% 结果总结
fprintf('\n=== 搜索完成 ===\n');
fprintf('总测试次数: %d\n', search_count);
fprintf('成功测试: %d\n', length(all_results));

fprintf('\n=== 最佳结果总结 ===\n');
fprintf('无监督最佳: ACC=%.4f, 种子=%d\n', best_unsup.ACC, best_unsup.seed);
fprintf('  参数: k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_unsup.params.k, best_unsup.params.T, best_unsup.params.snnWeight, best_unsup.params.gamma);

fprintf('10%%半监督最佳: ACC=%.4f, 种子=%d\n', best_sup10.ACC, best_sup10.seed);
fprintf('  参数: k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_sup10.params.k, best_sup10.params.T, best_sup10.params.snnWeight, best_sup10.params.gamma);

fprintf('20%%半监督最佳: ACC=%.4f, 种子=%d\n', best_sup20.ACC, best_sup20.seed);
fprintf('  参数: k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_sup20.params.k, best_sup20.params.T, best_sup20.params.snnWeight, best_sup20.params.gamma);

fprintf('整体最佳: ACC=%.4f, 种子=%d\n', best_overall.ACC, best_overall.seed);
if ~isempty(best_overall.params)
    fprintf('  参数: k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
        best_overall.params.k, best_overall.params.T, best_overall.params.snnWeight, best_overall.params.gamma);
else
    fprintf('  参数: 无满足单调性的结果\n');
end

%% 保存结果
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
save_dir = sprintf('comprehensive_search_results_%s', timestamp);
mkdir(save_dir);

% 保存MAT文件
save(fullfile(save_dir, 'comprehensive_search_results.mat'), 'all_results', 'best_unsup', 'best_sup10', 'best_sup20', 'best_overall');

% 保存详细报告
fid = fopen(fullfile(save_dir, 'comprehensive_search_report.txt'), 'w');
fprintf(fid, '=== 全面参数搜索结果报告 ===\n');
fprintf(fid, '搜索时间: %s\n', datestr(now));
fprintf(fid, '总测试次数: %d\n', search_count);
fprintf(fid, '成功测试: %d\n', length(all_results));

fprintf(fid, '\n=== 最佳结果 ===\n');
fprintf(fid, '无监督最佳: ACC=%.4f, 种子=%d\n', best_unsup.ACC, best_unsup.seed);
fprintf(fid, '10%%半监督最佳: ACC=%.4f, 种子=%d\n', best_sup10.ACC, best_sup10.seed);
fprintf(fid, '20%%半监督最佳: ACC=%.4f, 种子=%d\n', best_sup20.ACC, best_sup20.seed);
fprintf(fid, '整体最佳: ACC=%.4f, 种子=%d\n', best_overall.ACC, best_overall.seed);

fprintf(fid, '\n=== 详细参数 ===\n');
fprintf(fid, '无监督最佳参数:\n');
fprintf(fid, '  k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_unsup.params.k, best_unsup.params.T, best_unsup.params.snnWeight, best_unsup.params.gamma);

fprintf(fid, '10%%半监督最佳参数:\n');
fprintf(fid, '  k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_sup10.params.k, best_sup10.params.T, best_sup10.params.snnWeight, best_sup10.params.gamma);
fprintf(fid, '  lambda1=%.1f, lambda2=%.1f, repairIterations=%d\n', ...
    best_sup10.params.lambda1, best_sup10.params.lambda2, best_sup10.params.repairIterations);

fprintf(fid, '20%%半监督最佳参数:\n');
fprintf(fid, '  k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
    best_sup20.params.k, best_sup20.params.T, best_sup20.params.snnWeight, best_sup20.params.gamma);
fprintf(fid, '  lambda1=%.1f, lambda2=%.1f, repairIterations=%d\n', ...
    best_sup20.params.lambda1, best_sup20.params.lambda2, best_sup20.params.repairIterations);

fprintf(fid, '整体最佳参数:\n');
if ~isempty(best_overall.params)
    fprintf(fid, '  k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
        best_overall.params.k, best_overall.params.T, best_overall.params.snnWeight, best_overall.params.gamma);
    fprintf(fid, '  lambda1=%.1f, lambda2=%.1f, repairIterations=%d\n', ...
        best_overall.params.lambda1, best_overall.params.lambda2, best_overall.params.repairIterations);
else
    fprintf(fid, '  参数: 无满足单调性的结果\n');
end

fclose(fid);

fprintf('\n=== 结果保存 ===\n');
fprintf('结果保存目录: %s\n', save_dir);
fprintf('MAT数据文件: %s\n', fullfile(save_dir, 'comprehensive_search_results.mat'));
fprintf('详细报告: %s\n', fullfile(save_dir, 'comprehensive_search_report.txt'));

fprintf('\n搜索完成！所有结果已保存。\n');
