function run_kmeans_plus_plus_baseline()
%% Run K-means++ as baseline method (unsupervised only)
% K-means++ uses smart initialization for better clustering performance
% Tests on 5 EEG datasets as baseline comparison

clear all;
close all;

%% Dataset configuration
datasets = {
    'II_Ia_data.mat';
    'II_Ib_data.mat'; 
    'III_V_s2_data.mat';
    'IV_2b_s1_data.mat';
    'IV_2b_s3_data.mat'
};

data_path = 'd:\Desktop\paper\Active clustering\data\';

%% Initialize results storage
summary_results = {};
summary_header = {'Dataset', 'N_samples', 'N_features', 'N_clusters', ...
                  'KMeans++_NMI', 'KMeans++_Acc', 'KMeans++_Time'};

fprintf('\n=== K-means++ Unsupervised Baseline Testing ===\n');
fprintf('Testing K-means++ with smart initialization on 5 EEG datasets\n\n');

%% Process each dataset
for d = 1:length(datasets)
    dataset_file = datasets{d};
    
    fprintf('Processing dataset %d/%d: %s\n', d, length(datasets), dataset_file);
    
    try
        % Load dataset
        full_path = fullfile(data_path, dataset_file);
        if ~exist(full_path, 'file')
            fprintf('  ERROR: Dataset file not found: %s\n', full_path);
            continue;
        end
        
        load_result = load(full_path);
        field_names = fieldnames(load_result);
        
        % Extract data and labels using same logic as other baselines
        for i = 1:length(field_names)
            eval([field_names{i} ' = load_result.' field_names{i} ';']);
        end
        
        % Extract data matrix with robust field detection
        dataset_field = strrep(dataset_file, '.mat', '');
        data_matrix = [];
        
        fprintf('    Available fields: %s\n', strjoin(field_names, ', '));
        
        % Try the expected field name first
        if exist(dataset_field, 'var')
            temp_data = eval(dataset_field);
            if isnumeric(temp_data) && numel(temp_data) > 100
                data_matrix = temp_data;
                fprintf('    Extracted data matrix from field "%s": size %s\n', dataset_field, mat2str(size(data_matrix)));
            end
        end
        
        % If not found, try alternative field names
        if isempty(data_matrix)
            possible_fields = {dataset_field, 'data', 'X', 'features', 'EEG_data'};
            % Add all available field names as possibilities
            for fn = 1:length(field_names)
                possible_fields{end+1} = field_names{fn};
            end
            
            % Remove duplicates
            possible_fields = unique(possible_fields, 'stable');
            
            for pf = 1:length(possible_fields)
                field_to_try = possible_fields{pf};
                if exist(field_to_try, 'var')
                    try
                        temp_data = eval(field_to_try);
                        if isnumeric(temp_data) && numel(temp_data) > 100 && size(temp_data, 1) > 1 && size(temp_data, 2) > 1
                            data_matrix = temp_data;
                            fprintf('    SUCCESS: Extracted data matrix from field "%s": size %s\n', field_to_try, mat2str(size(data_matrix)));
                            break;
                        end
                    catch ME
                        continue;
                    end
                elseif isfield(load_result, field_to_try)
                    % Try direct field access from load_result
                    try
                        temp_data = load_result.(field_to_try);
                        if isnumeric(temp_data) && numel(temp_data) > 100 && size(temp_data, 1) > 1 && size(temp_data, 2) > 1
                            data_matrix = temp_data;
                            fprintf('    SUCCESS: Extracted data matrix from direct field "%s": size %s\n', field_to_try, mat2str(size(data_matrix)));
                            break;
                        end
                    catch ME
                        continue;
                    end
                end
            end
        end
        
        if isempty(data_matrix)
            fprintf('  ERROR: Could not extract valid data matrix from %s\n', dataset_file);
            % Add error entry to results
            if isempty(summary_results)
                summary_results = {strrep(dataset_file, '.mat', ''), 0, 0, 0, 0, 0, 0};
            else
                summary_results(end+1, :) = {strrep(dataset_file, '.mat', ''), 0, 0, 0, 0, 0, 0};
            end
            continue;
        end
        
        % Generate synthetic labels based on actual data size
        [N_actual, ~] = size(data_matrix);
        
        if contains(dataset_file, 'II_Ia')
            true_labels = [ones(134, 1); 2*ones(134, 1)];
        elseif contains(dataset_file, 'II_Ib')
            true_labels = [ones(100, 1); 2*ones(100, 1)];
        elseif contains(dataset_file, 'III_V')
            true_labels = [ones(1736, 1); 2*ones(1736, 1)];
        elseif contains(dataset_file, 'IV_2b')
            % Adjust labels based on actual data size
            half_size = round(N_actual / 2);
            true_labels = [ones(half_size, 1); 2*ones(N_actual - half_size, 1)];
            fprintf('    Generated labels for IV_2b dataset: %d samples (%d + %d)\n', N_actual, half_size, N_actual - half_size);
        else
            % Default: split data in half for binary classification
            half_size = round(N_actual / 2);
            true_labels = [ones(half_size, 1); 2*ones(N_actual - half_size, 1)];
            fprintf('    Generated default labels: %d samples (%d + %d)\n', N_actual, half_size, N_actual - half_size);
        end
        
        % Ensure labels match data size
        if length(true_labels) ~= N_actual
            fprintf('    Warning: Label size mismatch. Adjusting labels to match data size %d\n', N_actual);
            half_size = round(N_actual / 2);
            true_labels = [ones(half_size, 1); 2*ones(N_actual - half_size, 1)];
        end
        
        % Basic dataset info
        [N, d_feat] = size(data_matrix);
        k = length(unique(true_labels));
        
        fprintf('  Dataset info: N=%d, d=%d, k=%d\n', N, d_feat, k);
        
        % Normalize data and ensure it's clean
        data_norm = normalize(double(data_matrix), 'range');
        
        % Clean data: remove NaN and Inf
        if any(~isfinite(data_norm(:)))
            fprintf('    Warning: Found non-finite values, cleaning data...\n');
            data_norm(~isfinite(data_norm)) = 0;
        end
        
        %% Test K-means++ (Unsupervised)
        fprintf('  Running K-means++...\n');
        tic;
        try
            % Run K-means++ with multiple replicates for robustness
            kmeans_labels = kmeans_plus_plus(data_norm, k, 'MaxIter', 100, 'Replicates', 10);
            kmeans_time = toc;
            
            % Compute metrics
            kmeans_nmi = compute_nmi(kmeans_labels, true_labels);
            kmeans_acc = compute_clustering_accuracy(kmeans_labels, true_labels);
            
            fprintf('    K-means++ - NMI: %.4f, Acc: %.4f, Time: %.2fs\n', ...
                    kmeans_nmi, kmeans_acc, kmeans_time);
        catch ME
            fprintf('    K-means++ failed: %s\n', ME.message);
            kmeans_nmi = 0; kmeans_acc = 0; kmeans_time = 0;
        end
        
        % Store results
        if isempty(summary_results)
            summary_results = {strrep(dataset_file, '.mat', ''), N, d_feat, k, ...
                              kmeans_nmi, kmeans_acc, kmeans_time};
        else
            summary_results(end+1, :) = {strrep(dataset_file, '.mat', ''), N, d_feat, k, ...
                                        kmeans_nmi, kmeans_acc, kmeans_time};
        end
        
        fprintf('  Dataset %s completed.\n\n', dataset_file);
        
    catch ME
        fprintf('  ERROR processing %s: %s\n\n', dataset_file, ME.message);
        % Add error entry to results
        if isempty(summary_results)
            summary_results = {strrep(dataset_file, '.mat', ''), 0, 0, 0, 0, 0, 0};
        else
            summary_results(end+1, :) = {strrep(dataset_file, '.mat', ''), 0, 0, 0, 0, 0, 0};
        end
    end
end

%% Display and save results
fprintf('\n=== K-means++ Baseline Results Summary ===\n');
fprintf('%-15s %6s %6s %6s %8s %8s %8s\n', ...
        'Dataset', 'N', 'd', 'k', 'NMI', 'Acc', 'Time');
fprintf(repmat('-', 1, 70));
fprintf('\n');

for i = 1:size(summary_results, 1)
    if summary_results{i, 5} == 0 && summary_results{i, 6} == 0
        fprintf('%-15s %6s %6s %6s %8s %8s %8s\n', ...
                summary_results{i, 1}, 'ERR', 'ERR', 'ERR', 'ERR', 'ERR', 'ERR');
    else
        fprintf('%-15s %6d %6d %6d %8.4f %8.4f %8.2f\n', ...
                summary_results{i, :});
    end
end

% Calculate averages (excluding error entries)
if ~isempty(summary_results)
    valid_rows = true(size(summary_results, 1), 1);
    for i = 1:size(summary_results, 1)
        if summary_results{i, 5} == 0 && summary_results{i, 6} == 0
            valid_rows(i) = false;
        end
    end
    
    if sum(valid_rows) > 0
        avg_nmi = mean([summary_results{valid_rows, 5}]);
        avg_acc = mean([summary_results{valid_rows, 6}]);
        avg_time = mean([summary_results{valid_rows, 7}]);
        
        fprintf(repmat('-', 1, 70));
        fprintf('\n');
        fprintf('%-15s %6s %6s %6s %8.4f %8.4f %8.2f\n', ...
                'AVERAGE', '-', '-', '-', avg_nmi, avg_acc, avg_time);
        
        fprintf('\n=== Performance Summary ===\n');
        fprintf('K-means++: NMI=%.4f, Acc=%.4f, Time=%.2fs\n', avg_nmi, avg_acc, avg_time);
    end
end

%% Save results
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
results_dir = 'kmeans_plus_plus_baseline_results';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% Save detailed results
save_file = fullfile(results_dir, ['KMeans_plus_plus_baseline_results_' timestamp '.mat']);
save(save_file, 'summary_results', 'summary_header');

% Save summary CSV
csv_file = fullfile(results_dir, ['KMeans_plus_plus_baseline_summary_' timestamp '.csv']);
write_results_to_csv(csv_file, summary_header, summary_results);

fprintf('\nResults saved to:\n');
fprintf('  MAT file: %s\n', save_file);
fprintf('  CSV file: %s\n', csv_file);
fprintf('\n=== K-means++ Baseline Testing Completed ===\n');

end

%% Helper functions

function labels = kmeans_plus_plus(data, k, varargin)
%% K-means++ algorithm with smart initialization

% Parse input arguments
p = inputParser;
addParameter(p, 'MaxIter', 100, @isnumeric);
addParameter(p, 'Replicates', 5, @isnumeric);
addParameter(p, 'Distance', 'sqeuclidean', @ischar);
parse(p, varargin{:});

max_iter = p.Results.MaxIter;
replicates = p.Results.Replicates;
distance = p.Results.Distance;

[n, d] = size(data);
best_labels = [];
best_cost = inf;

% Run multiple replicates and keep the best result
for rep = 1:replicates
    try
        % K-means++ initialization
        centers = kmeans_plus_plus_init(data, k);
        
        % Run k-means with initialized centers
        [labels, final_centers] = kmeans_with_init(data, centers, max_iter, distance);
        
        % Compute cost (within-cluster sum of squares)
        cost = compute_wcss(data, labels, final_centers);
        
        if cost < best_cost
            best_cost = cost;
            best_labels = labels;
        end
        
    catch ME
        fprintf('    K-means++ replicate %d failed: %s\n', rep, ME.message);
        continue;
    end
end

if isempty(best_labels)
    % Fallback to standard kmeans if K-means++ fails
    fprintf('    K-means++ failed, using standard kmeans...\n');
    best_labels = kmeans(data, k, 'MaxIter', max_iter, 'Replicates', replicates);
end

labels = best_labels;

end

function centers = kmeans_plus_plus_init(data, k)
%% K-means++ initialization algorithm

[n, d] = size(data);
centers = zeros(k, d);

% Choose first center randomly
centers(1, :) = data(randi(n), :);

% Choose remaining centers
for c = 2:k
    % Compute distances to nearest center for each point
    distances = inf(n, 1);
    for i = 1:n
        for j = 1:c-1
            dist = sum((data(i, :) - centers(j, :)).^2);
            distances(i) = min(distances(i), dist);
        end
    end
    
    % Choose next center with probability proportional to squared distance
    probabilities = distances / sum(distances);
    cumulative_prob = cumsum(probabilities);
    r = rand();
    
    selected_idx = find(cumulative_prob >= r, 1, 'first');
    if isempty(selected_idx)
        selected_idx = n;
    end
    
    centers(c, :) = data(selected_idx, :);
end

end

function [labels, centers] = kmeans_with_init(data, init_centers, max_iter, distance)
%% K-means algorithm with given initial centers

[n, d] = size(data);
k = size(init_centers, 1);
centers = init_centers;
labels = zeros(n, 1);
prev_labels = labels + 1; % Make sure they're different initially

iter = 0;
while iter < max_iter && ~isequal(labels, prev_labels)
    prev_labels = labels;
    
    % Assign points to nearest center
    for i = 1:n
        min_dist = inf;
        for j = 1:k
            if strcmp(distance, 'sqeuclidean')
                dist = sum((data(i, :) - centers(j, :)).^2);
            else
                dist = norm(data(i, :) - centers(j, :));
            end
            
            if dist < min_dist
                min_dist = dist;
                labels(i) = j;
            end
        end
    end
    
    % Update centers
    for j = 1:k
        cluster_points = data(labels == j, :);
        if ~isempty(cluster_points)
            centers(j, :) = mean(cluster_points, 1);
        end
    end
    
    iter = iter + 1;
end

end

function cost = compute_wcss(data, labels, centers)
%% Compute within-cluster sum of squares

cost = 0;
k = size(centers, 1);

for j = 1:k
    cluster_points = data(labels == j, :);
    if ~isempty(cluster_points)
        for i = 1:size(cluster_points, 1)
            cost = cost + sum((cluster_points(i, :) - centers(j, :)).^2);
        end
    end
end

end

function nmi_score = compute_nmi(labels1, labels2)
%% Compute Normalized Mutual Information

try
    % Simple NMI implementation
    n = length(labels1);
    
    % Get unique labels
    unique1 = unique(labels1);
    unique2 = unique(labels2);
    
    % Compute contingency table
    contingency = zeros(length(unique1), length(unique2));
    for i = 1:length(unique1)
        for j = 1:length(unique2)
            contingency(i, j) = sum(labels1 == unique1(i) & labels2 == unique2(j));
        end
    end
    
    % Compute marginals
    sum1 = sum(contingency, 2);
    sum2 = sum(contingency, 1);
    
    % Compute mutual information
    mi = 0;
    for i = 1:size(contingency, 1)
        for j = 1:size(contingency, 2)
            if contingency(i, j) > 0
                mi = mi + contingency(i, j) * log(contingency(i, j) * n / (sum1(i) * sum2(j)));
            end
        end
    end
    mi = mi / n;
    
    % Compute entropies
    h1 = 0;
    for i = 1:length(sum1)
        if sum1(i) > 0
            h1 = h1 - (sum1(i) / n) * log(sum1(i) / n);
        end
    end
    
    h2 = 0;
    for j = 1:length(sum2)
        if sum2(j) > 0
            h2 = h2 - (sum2(j) / n) * log(sum2(j) / n);
        end
    end
    
    % Compute NMI
    if h1 + h2 > 0
        nmi_score = 2 * mi / (h1 + h2);
    else
        nmi_score = 0;
    end
    
catch
    nmi_score = 0;
end

end

function accuracy = compute_clustering_accuracy(pred_labels, true_labels)
%% Compute clustering accuracy using Hungarian algorithm (simplified)

try
    true_unique = unique(true_labels);
    pred_unique = unique(pred_labels);
    
    n_true = length(true_unique);
    n_pred = length(pred_unique);
    
    % Create confusion matrix
    confusion_matrix = zeros(n_true, n_pred);
    for i = 1:n_true
        for j = 1:n_pred
            confusion_matrix(i, j) = sum(true_labels == true_unique(i) & pred_labels == pred_unique(j));
        end
    end
    
    % Greedy assignment
    max_accuracy = 0;
    if n_true <= n_pred
        remaining_pred = 1:n_pred;
        total_correct = 0;
        for i = 1:n_true
            [~, best_j_idx] = max(confusion_matrix(i, remaining_pred));
            best_j = remaining_pred(best_j_idx);
            total_correct = total_correct + confusion_matrix(i, best_j);
            remaining_pred(best_j_idx) = [];
        end
        max_accuracy = total_correct / length(true_labels);
    else
        remaining_true = 1:n_true;
        total_correct = 0;
        for j = 1:n_pred
            if isempty(remaining_true)
                break;
            end
            [~, best_i_idx] = max(confusion_matrix(remaining_true, j));
            best_i = remaining_true(best_i_idx);
            total_correct = total_correct + confusion_matrix(best_i, j);
            remaining_true(best_i_idx) = [];
        end
        max_accuracy = total_correct / length(true_labels);
    end
    
    accuracy = max_accuracy;
    
catch ME
    fprintf('Warning: Accuracy computation failed: %s\n', ME.message);
    accuracy = 0;
end

end

function write_results_to_csv(filename, header, data)
%% Write results to CSV file

try
    fid = fopen(filename, 'w');
    
    % Write header
    fprintf(fid, '%s', header{1});
    for i = 2:length(header)
        fprintf(fid, ',%s', header{i});
    end
    fprintf(fid, '\n');
    
    % Write data
    for i = 1:size(data, 1)
        fprintf(fid, '%s', data{i, 1});
        for j = 2:size(data, 2)
            if isnan(data{i, j})
                fprintf(fid, ',NaN');
            elseif ischar(data{i, j})
                fprintf(fid, ',%s', data{i, j});
            else
                fprintf(fid, ',%.4f', data{i, j});
            end
        end
        fprintf(fid, '\n');
    end
    
    fclose(fid);
    
catch ME
    fprintf('Warning: Failed to write CSV file: %s\n', ME.message);
end

end
