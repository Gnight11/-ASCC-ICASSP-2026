function D = EuDist2(fea_a, fea_b, bSqrt)
% EuDist2 - 计算欧几里得距离矩阵
% 输入:
%   fea_a - 第一个数据矩阵 (n1 x d)
%   fea_b - 第二个数据矩阵 (n2 x d)，可选，默认为fea_a
%   bSqrt - 是否开平方根，可选，默认为1
% 输出:
%   D - 距离矩阵 (n1 x n2)

if nargin < 2
    fea_b = fea_a;
end
if nargin < 3
    bSqrt = 1;
end

% 确保输入数据是实数数组
fea_a = real(fea_a);
fea_b = real(fea_b);

% 检查并处理NaN和Inf值
fea_a(isnan(fea_a) | isinf(fea_a)) = 0;
fea_b(isnan(fea_b) | isinf(fea_b)) = 0;

% 计算欧几里得距离
D = pdist2(fea_a, fea_b, 'euclidean');

% 如果需要，计算平方距离
if bSqrt == 0
    D = D.^2;
end

end

