function [labels_fixed, C_fixed] = repair_constraints_kmeans(X, labels, C, mustPairs, cannotPairs, maxIter)
%REPAIR_CONSTRAINTS_KMEANS 局部修复K-means标签以满足must-link/cannot-link约束
%
% Inputs:
%   X           : n x d 数据矩阵
%   labels      : n x 1 初始K-means标签
%   C           : c x d 初始簇中心
%   mustPairs   : m1 x 2 must-link样本对
%   cannotPairs : m2 x 2 cannot-link样本对
%   maxIter     : 最大迭代次数 (默认10)
%
% Outputs:
%   labels_fixed : n x 1 修复后的标签
%   C_fixed      : c x d 修复后的簇中心

if nargin < 6
    maxIter = 10;
end

[n,d] = size(X);
c = size(C,1);

labels_fixed = labels;
C_fixed = C;

for iter = 1:maxIter
    changed = false;
    
    % --- must-link 修复 ---
    for t = 1:size(mustPairs,1)
        i = mustPairs(t,1); j = mustPairs(t,2);
        if labels_fixed(i) ~= labels_fixed(j)
            % 计算两种移动距离
            dist_i_to_j = norm(X(i,:) - C_fixed(labels_fixed(j),:));
            dist_j_to_i = norm(X(j,:) - C_fixed(labels_fixed(i),:));
            if dist_i_to_j < dist_j_to_i
                labels_fixed(i) = labels_fixed(j);
            else
                labels_fixed(j) = labels_fixed(i);
            end
            changed = true;
        end
    end
    
    % --- cannot-link 修复 ---
    for t = 1:size(cannotPairs,1)
        i = cannotPairs(t,1); j = cannotPairs(t,2);
        if labels_fixed(i) == labels_fixed(j)
            % i 移动到最近且不违反cannot-link的簇
            distMat = vecnorm(X(i,:) - C_fixed,2,2);
            % 排除当前簇
            distMat(labels_fixed(j)) = inf;
            
            % 找所有可能导致cannot-link冲突的簇
            conflictClusters = [];
            idx = find(cannotPairs(:,1) == i); 
            conflictClusters = [conflictClusters; labels_fixed(cannotPairs(idx,2))];
            idx = find(cannotPairs(:,2) == i); 
            conflictClusters = [conflictClusters; labels_fixed(cannotPairs(idx,1))];
            conflictClusters = unique(conflictClusters);
            
            distMat(conflictClusters) = inf; % 排除冲突簇
            
            [~, newCluster] = min(distMat);
            labels_fixed(i) = newCluster;
            changed = true;
        end
    end
    
    % --- 更新簇中心 ---
    for k = 1:c
        idxk = labels_fixed == k;
        if any(idxk)
            C_fixed(k,:) = mean(X(idxk,:),1);
        else
            % 如果簇为空，随机选择一个样本
            C_fixed(k,:) = X(randi(n),:);
        end
    end
    
    % 如果没有任何变化，提前退出
    if ~changed
        fprintf('Constraints satisfied after %d iterations.\n', iter);
        break;
    end
end

% 最终检查
[violMust, violCannot] = check_constraint_violations(labels_fixed, mustPairs, cannotPairs);
fprintf('Remaining violated must-link: %d, cannot-link: %d\n', violMust, violCannot);

end

% --- 辅助函数：检查约束 ---
function [numViolMust, numViolCannot] = check_constraint_violations(labels, mustPairs, cannotPairs)
numViolMust = 0; numViolCannot = 0;

for t = 1:size(mustPairs,1)
    if labels(mustPairs(t,1)) ~= labels(mustPairs(t,2))
        numViolMust = numViolMust + 1;
    end
end

for t = 1:size(cannotPairs,1)
    if labels(cannotPairs(t,1)) == labels(cannotPairs(t,2))
        numViolCannot = numViolCannot + 1;
    end
end
end
