function [selectedPairs, scores, cache] = select_pairs_mmr(G, A_pair_norm, U_norm, budget, lambda3)
%==========================================================================
% FUNCTION:
%   [selectedPairs, scores, cache] = select_pairs_mmr(G, A_pair_norm, U_norm, budget, lambda3)
% DESCRIPTION:
%   Greedy MMR pair selection combining representativeness and uncertainty
%   with redundancy penalization over already selected pairs.
%   Score:
%       F_ij = (A_pair_norm_ij - mu_a)/sigma_a^2 + (U_norm_ij - mu_u)/sigma_u^2
%              - lambda3 * max_{(p,q) in S} sim_pair((i,j),(p,q))
%   where sim_pair uses cosine similarity between pair embeddings derived
%   from G. We represent a pair by the averaged embedding (g_i + g_j)/2.
%
% INPUTS:
%   G            : n x c embedding matrix (rows are sample embeddings)
%   A_pair_norm  : n x n normalized representativeness scores (â_ij)
%   U_norm       : n x n normalized uncertainty scores (u_ij)
%   budget       : number of pairs to select
%   lambda3      : redundancy weight (default 0.5)
%
% OUTPUTS:
%   selectedPairs: K x 2 matrix of 1-based indices (i,j)
%   scores       : K x 1 vector of final scores for the selected pairs
%   cache        : struct with precomputed pair embeddings for reuse
%==========================================================================

    if nargin < 5 || isempty(lambda3)
        lambda3 = 0.5;
    end

    n = size(G,1);

    % Compute statistics for inverse-variance weighting on normalized inputs
    mask = triu(true(n),1);
    a_vals = A_pair_norm(mask);
    u_vals = U_norm(mask);
    mu_a = mean(a_vals);  sd_a = std(a_vals); if sd_a < 1e-12, sd_a = 1; end
    mu_u = mean(u_vals);  sd_u = std(u_vals); if sd_u < 1e-12, sd_u = 1; end

    baseScore = (A_pair_norm - mu_a) / (sd_a^2) + (U_norm - mu_u) / (sd_u^2);
    baseScore(1:n+1:end) = -inf; % exclude diagonal

    % Precompute pair embeddings as needed (lazy)
    cache = struct();
    cache.G = G;
    cache.pairEmbed = [];

    selectedPairs = zeros(budget, 2);
    scores = zeros(budget,1);
    Sset = false(n,n);

    for t = 1:budget
        % Redundancy penalty against current set
        penalty = zeros(n,n);
        if t > 1
            % For efficiency, compute max similarity row-wise
            [penalty] = compute_pair_redundancy(G, Sset);
        end

        F = baseScore - lambda3 * penalty;
        F = triu(F,1);
        [bestVal, idx] = max(F(:));
        if ~isfinite(bestVal)
            break;
        end
        [i,j] = ind2sub([n,n], idx);
        selectedPairs(t,:) = [i,j];
        scores(t) = bestVal;
        Sset(i,j) = true; Sset(j,i) = true;
        % Invalidate chosen pair to avoid reselection
        baseScore(i,j) = -inf; baseScore(j,i) = -inf;
    end

end

function penalty = compute_pair_redundancy(G, Sset)
    n = size(G,1);
    % Build pair embedding as average of endpoints
    % For selected set, precompute their embeddings
    [ii, jj] = find(triu(Sset,1));
    m = numel(ii);
    if m == 0
        penalty = zeros(n,n);
        return;
    end
    selEmb = (G(ii,:) + G(jj,:)) / 2;
    selEmb = NormalizeFea(selEmb, 1);

    % For all candidate pairs, approximate penalty by max similarity with
    % any selected pair: we compute per node the best similarity then merge.
    penalty = zeros(n,n);
    Gnorm = NormalizeFea(G, 1);
    simNodeSel = Gnorm * selEmb'; % n x m
    % For a pair (i,j), similarity of pair embeddings approximated by
    % average of similarities of nodes to selected pair embeddings
    maxSimI = max(simNodeSel, [], 2); % n x 1
    maxSimJ = maxSimI; % symmetric approximation
    penalty = maxSimI + maxSimJ';
    penalty = penalty / 2; % average
    penalty(1:n+1:end) = 0;
end


