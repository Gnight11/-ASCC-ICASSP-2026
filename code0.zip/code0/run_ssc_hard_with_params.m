function results = run_ssc_hard_with_params(lambda1, lambda2, knn)
% SSC-Hard with parameter input for grid search

    % Paths
    this_file = mfilename('fullpath');
    [this_dir,~,~] = fileparts(this_file);
    base_dir = fullfile(this_dir, '..');
    data_path  = fullfile(base_dir, 'data','II_Ia_Ib_data.mat');

    addpath(this_dir);

    % Load
    S = load(data_path);
    [fea, gt] = local_extract_fea_gt(S);
    gt = double(gt(:)); [~,~,gt] = unique(gt,'stable');

    % PCA 95% then z-score
    fea = pca_reduce(fea, 0.95);
    mu = mean(fea,1); sd = std(fea,[],1)+1e-8; fea = (fea-mu)./sd;

    k = numel(unique(gt));

    % Affinity with parameter
    A = build_knn_affinity_local(fea, knn);

    % Unsupervised
    [DU_uns, ~] = fast_spectral_clustering(A, k);
    labels_uns = seeded_kmeans(DU_uns', k, [], gt);
    M_uns = metrics_eval(gt, labels_uns);

    % Semi-supervised settings
    settings = {'semi10','semi20'}; ratios=[0.10,0.20];
    results = struct();
    results.unsup = struct('ACC',M_uns.ACC,'NMI',M_uns.NMI,'ARI',M_uns.ARI);

    cached_idx10 = [];
    for si=1:numel(settings)
        ratio = ratios(si);
        [pairs_ml, pairs_cl, idxL] = sample_pairs_nested(gt, ratio, 44, cached_idx10);
        if isempty(cached_idx10), cached_idx10 = idxL; end

        % Use parameters for constraint weights
        [A_tilde, ~, ~] = build_constraint_augmented_affinity(A, pairs_ml, pairs_cl, lambda1, lambda2, 1e-6);

        [DU, ~] = fast_spectral_clustering(A_tilde, k);
        labels = seeded_kmeans(DU', k, [], gt);
        M = metrics_eval(gt, labels);

        % Violations
        [vml, vcl] = count_violations(labels, pairs_ml, pairs_cl);

        results.(settings{si}) = struct('ACC',M.ACC,'NMI',M.NMI,'ARI',M.ARI,'ViolML',vml,'ViolCL',vcl);

        % Hard constraint version
        labels_hard = repair_labels_with_constraints(labels, struct('ml',pairs_ml,'cl',pairs_cl), DU, k);
        M_hard = metrics_eval(gt, labels_hard);
        [vml_hard, vcl_hard] = count_violations(labels_hard, pairs_ml, pairs_cl);
        results.([settings{si} '_hard']) = struct('ACC',M_hard.ACC,'NMI',M_hard.NMI,'ARI',M_hard.ARI,'ViolML',vml_hard,'ViolCL',vcl_hard);
    end
end
