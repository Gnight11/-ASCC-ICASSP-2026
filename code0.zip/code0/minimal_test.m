%% 最简测试版本 - 调试闪退问题
clear; clc;

fprintf('=== 最简测试开始 ===\n');

try
    % 测试1: 基本MATLAB功能
    fprintf('测试1: 基本MATLAB功能...\n');
    test_data = rand(10, 5);
    fprintf('✅ 随机数据生成成功: %dx%d\n', size(test_data));
    
    % 测试2: 路径检查
    fprintf('测试2: 检查路径...\n');
    current_path = pwd;
    fprintf('当前路径: %s\n', current_path);
    
    % 测试3: 数据文件检查
    fprintf('测试3: 检查数据文件...\n');
    data_file = fullfile('..','data','II_Ia_Ib_data.mat');
    if exist(data_file, 'file')
        fprintf('✅ 数据文件存在: %s\n', data_file);
        
        % 测试4: 加载数据
        fprintf('测试4: 尝试加载数据...\n');
        try
            data_info = whos('-file', data_file);
            fprintf('✅ 数据文件包含 %d 个变量:\n', length(data_info));
            for i = 1:length(data_info)
                fprintf('  - %s: %s\n', data_info(i).name, mat2str(data_info(i).size));
            end
        catch ME2
            fprintf('❌ 数据文件信息读取失败: %s\n', ME2.message);
        end
    else
        fprintf('❌ 数据文件不存在: %s\n', data_file);
    end
    
    % 测试5: 函数可用性检查
    fprintf('测试5: 检查关键函数...\n');
    
    functions_to_check = {'load_timeseries_mat', 'metrics_eval', 'unsupervised_consensus_driver'};
    for i = 1:length(functions_to_check)
        func_name = functions_to_check{i};
        if exist(func_name, 'file')
            fprintf('✅ 函数存在: %s\n', func_name);
        else
            fprintf('❌ 函数不存在: %s\n', func_name);
        end
    end
    
    % 测试6: 简单k-means测试
    fprintf('测试6: 基本聚类测试...\n');
    simple_data = randn(100, 3);
    simple_labels = kmeans(simple_data, 3);
    fprintf('✅ 基本k-means成功: %d个聚类\n', length(unique(simple_labels)));
    
    fprintf('\n=== 所有基本测试完成 ===\n');
    fprintf('如果看到这条消息，说明MATLAB基本功能正常\n');
    
catch ME
    fprintf('❌ 测试失败: %s\n', ME.message);
    fprintf('错误详情:\n');
    disp(ME);
end

fprintf('测试结束，按任意键退出...\n');
pause(2);  % 等待2秒让用户看到结果




