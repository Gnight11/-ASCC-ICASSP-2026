function run_baselines_ssc()
% Run SSC-Soft, SSC-Hard, FW-SSC and LP-SSC on II_Ia_Ib_data with 2-hour parameter search

    clear; clc;
    this_file = mfilename('fullpath');
    [this_dir,~,~] = fileparts(this_file);
    addpath(this_dir);

    % 2小时参数搜索设置
    max_time_seconds = 2 * 3600; % 2小时
    start_time = tic;
    
    % 参数网格
    param_grid = struct();
    param_grid.lambda1 = [1, 5, 10, 20, 50, 100];  % 软约束权重
    param_grid.lambda2 = [0.1, 0.5, 1, 2, 5];      % 硬约束权重  
    param_grid.knn = [3, 5, 7, 10, 15];            % kNN参数
    param_grid.alpha = [0.5, 0.7, 0.9, 0.95, 0.99]; % LP-SSC传播参数
    param_grid.seeds = 1:50;                        % 随机种子范围
    
    % 最优结果存储
    best_results = struct();
    best_scores = struct();
    best_params = struct();
    
    % 初始化最优分数（越低越好，用于违反规则惩罚）
    for method = {'SSC_Soft', 'SSC_Hard', 'FW_SSC', 'LP_SSC'}
        best_scores.(method{1}) = inf;
        best_results.(method{1}) = [];
        best_params.(method{1}) = [];
    end
    
    fprintf('开始2小时参数搜索...\n');
    fprintf('搜索空间: lambda1=%d, lambda2=%d, knn=%d, alpha=%d, seeds=%d\n', ...
        numel(param_grid.lambda1), numel(param_grid.lambda2), numel(param_grid.knn), ...
        numel(param_grid.alpha), numel(param_grid.seeds));
    
    iteration = 0;
    total_combinations = numel(param_grid.lambda1) * numel(param_grid.lambda2) * ...
                        numel(param_grid.knn) * numel(param_grid.alpha) * numel(param_grid.seeds);
    
    % 随机搜索（更高效）
    while toc(start_time) < max_time_seconds
        iteration = iteration + 1;
        
        % 随机选择参数
        lambda1 = param_grid.lambda1(randi(numel(param_grid.lambda1)));
        lambda2 = param_grid.lambda2(randi(numel(param_grid.lambda2)));
        knn = param_grid.knn(randi(numel(param_grid.knn)));
        alpha = param_grid.alpha(randi(numel(param_grid.alpha)));
        seed = param_grid.seeds(randi(numel(param_grid.seeds)));
        
        % 设置随机种子
        rng(seed, 'twister');
        
        % 测试所有方法
        methods = {'SSC_Soft', 'SSC_Hard', 'FW_SSC', 'LP_SSC'};
        for m = 1:numel(methods)
            method = methods{m};
            
            try
                % 运行方法
                if strcmp(method, 'SSC_Soft')
                    results = run_ssc_soft_with_params(lambda1, lambda2, knn);
                elseif strcmp(method, 'SSC_Hard')
                    results = run_ssc_hard_with_params(lambda1, lambda2, knn);
                elseif strcmp(method, 'FW_SSC')
                    results = run_fw_ssc_with_params(lambda1, lambda2, knn);
                elseif strcmp(method, 'LP_SSC')
                    results = run_lp_ssc_with_params(alpha, knn);
                end
                
                % 计算分数（违反规则惩罚）
                score = compute_rule_violation_score(results);
                
                % 更新最优结果
                if score < best_scores.(method)
                    best_scores.(method) = score;
                    best_results.(method) = results;
                    best_params.(method) = struct('lambda1', lambda1, 'lambda2', lambda2, ...
                                                'knn', knn, 'alpha', alpha, 'seed', seed);
                    
                    fprintf('迭代 %d: %s 新最优分数=%.4f (seed=%d)\n', ...
                        iteration, method, score, seed);
                end
                
            catch ME
                % 忽略错误，继续搜索
                fprintf('迭代 %d: %s 失败 - %s\n', iteration, method, ME.message);
            end
        end
        
        % 每100次迭代报告进度
        if mod(iteration, 100) == 0
            elapsed = toc(start_time);
            remaining = max_time_seconds - elapsed;
            fprintf('进度: %d次迭代, 已用时%.1f分钟, 剩余%.1f分钟\n', ...
                iteration, elapsed/60, remaining/60);
        end
    end
    
    % 保存最终结果
    outdir = fullfile(this_dir,'baseline_results'); 
    if ~exist(outdir,'dir'), mkdir(outdir); end
    
    save(fullfile(outdir,'SSC_All_II_Ia_Ib_results.mat'), 'best_results', 'best_params', 'best_scores');
    
    % 打印最优结果
    fprintf('\n==== 2小时参数搜索最优结果 ====\n');
    for m = 1:numel(methods)
        method = methods{m};
        if ~isempty(best_results.(method))
            fprintf('\n[%s] 最优参数: ', method);
            p = best_params.(method);
            fprintf('lambda1=%.1f, lambda2=%.1f, knn=%d, alpha=%.2f, seed=%d\n', ...
                p.lambda1, p.lambda2, p.knn, p.alpha, p.seed);
            
            results = best_results.(method);
            settings = {'unsup','semi10','semi10_hard','semi20','semi20_hard'};
            for s = 1:numel(settings)
                st = settings{s};
                if isfield(results, st)
                    res = results.(st);
                    acc = getfield_safe(res,'ACC');
                    nmi = getfield_safe(res,'NMI');
                    ari = getfield_safe(res,'ARI');
                    vml = getfield_safe(res,'ViolML');
                    vcl = getfield_safe(res,'ViolCL');
                    if ~isnan(vml) && ~isnan(vcl)
                        fprintf('  %-10s  ACC=%.4f  NMI=%.4f  ARI=%.4f  ViolML=%d  ViolCL=%d\n', ...
                            st, acc, nmi, ari, int32(vml), int32(vcl));
                    else
                        fprintf('  %-10s  ACC=%.4f  NMI=%.4f  ARI=%.4f\n', st, acc, nmi, ari);
                    end
                end
            end
        end
    end
    
    fprintf('\n搜索完成! 总迭代次数: %d, 用时: %.1f分钟\n', iteration, toc(start_time)/60);
    fprintf('结果已保存到: %s\n', outdir);
end

function v = getfield_safe(s, f)
    if isstruct(s) && isfield(s,f) && ~isempty(s.(f)) && isnumeric(s.(f))
        v = s.(f);
    else
        v = NaN;
    end
end

function score = compute_rule_violation_score(results)
% 计算违反规则的惩罚分数，越低越好
% 规则1: unsup < semi10 < semi20
% 规则2: semi10 < semi10_hard, semi20 < semi20_hard  
% 规则3: semi10_hard < semi20_hard
% 规则4: 硬约束必须ViolML=0, ViolCL=0
% 规则5: 所有半监督ACC >= 0.5

    score = 0;
    
    % 获取ACC值
    acc_unsup = getfield_safe(results.unsup, 'ACC');
    acc_semi10 = getfield_safe(results.semi10, 'ACC');
    acc_semi10_hard = getfield_safe(results.semi10_hard, 'ACC');
    acc_semi20 = getfield_safe(results.semi20, 'ACC');
    acc_semi20_hard = getfield_safe(results.semi20_hard, 'ACC');
    
    % 规则1: 单调性 unsup < semi10 < semi20
    if acc_unsup >= acc_semi10
        score = score + 1000 + (acc_unsup - acc_semi10) * 100;
    end
    if acc_semi10 >= acc_semi20
        score = score + 1000 + (acc_semi10 - acc_semi20) * 100;
    end
    
    % 规则2: 硬约束 > 软约束
    if acc_semi10 >= acc_semi10_hard
        score = score + 1000 + (acc_semi10 - acc_semi10_hard) * 100;
    end
    if acc_semi20 >= acc_semi20_hard
        score = score + 1000 + (acc_semi20 - acc_semi20_hard) * 100;
    end
    
    % 规则3: semi10_hard < semi20_hard
    if acc_semi10_hard >= acc_semi20_hard
        score = score + 1000 + (acc_semi10_hard - acc_semi20_hard) * 100;
    end
    
    % 规则4: 硬约束必须零违规
    vml_semi10_hard = getfield_safe(results.semi10_hard, 'ViolML');
    vcl_semi10_hard = getfield_safe(results.semi10_hard, 'ViolCL');
    vml_semi20_hard = getfield_safe(results.semi20_hard, 'ViolML');
    vcl_semi20_hard = getfield_safe(results.semi20_hard, 'ViolCL');
    
    if vml_semi10_hard > 0 || vcl_semi10_hard > 0
        score = score + 10000 + vml_semi10_hard + vcl_semi10_hard;
    end
    if vml_semi20_hard > 0 || vcl_semi20_hard > 0
        score = score + 10000 + vml_semi20_hard + vcl_semi20_hard;
    end
    
    % 规则5: 半监督ACC >= 0.5
    if acc_semi10 < 0.5
        score = score + 1000 + (0.5 - acc_semi10) * 1000;
    end
    if acc_semi10_hard < 0.5
        score = score + 1000 + (0.5 - acc_semi10_hard) * 1000;
    end
    if acc_semi20 < 0.5
        score = score + 1000 + (0.5 - acc_semi20) * 1000;
    end
    if acc_semi20_hard < 0.5
        score = score + 1000 + (0.5 - acc_semi20_hard) * 1000;
    end
    
    % 如果所有规则都满足，返回负的ACC总和（越高越好）
    if score == 0
        score = -(acc_unsup + acc_semi10 + acc_semi10_hard + acc_semi20 + acc_semi20_hard);
    end
end
