function plot_eeg_channel_visualization(data, labels, dataset_name, result_dir)
% PLOT_EEG_CHANNEL_VISUALIZATION: 绘制EEG通道可视化图
% 调用增强版EEG脑地形图可视化

if nargin < 4
    result_dir = '.';
end

fprintf('绘制增强版EEG通道可视化图 - %s\n', dataset_name);

% 调用增强版可视化函数
try
    % 切换到代码目录
    current_dir = pwd;
    code_dir = fileparts(mfilename('fullpath'));
    cd(code_dir);
    
    % 调用增强版函数
    enhanced_eeg_topographic_visualization();
    
    % 返回原目录
    cd(current_dir);
    
    fprintf('增强版EEG可视化完成\n');
    return;
catch ME
    fprintf('增强版可视化失败，使用原版本: %s\n', ME.message);
    cd(current_dir);
end

fprintf('使用原版EEG通道可视化图 - %s\n', dataset_name);

try
    % 获取数据维度
    [n_samples, n_channels, n_timepoints] = size(data);
    unique_labels = unique(labels);
    n_clusters = length(unique_labels);
    
    % 标准EEG电极位置 (10-20系统)
    electrode_positions = get_standard_electrode_positions(n_channels);
    
    % 创建图形
    fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
    
    % 为每个聚类计算平均激活模式
    cluster_patterns = zeros(n_clusters, n_channels);
    
    for i = 1:n_clusters
        cluster_idx = (labels == unique_labels(i));
        if sum(cluster_idx) > 0
            % 计算该聚类的平均功率谱密度
            cluster_data = data(cluster_idx, :, :);
            cluster_mean = squeeze(mean(cluster_data, 1)); % channels x time_points
            
            % 计算每个通道的平均功率
            cluster_patterns(i, :) = mean(cluster_mean.^2, 2);
        end
    end
    
    % 归一化到0-1范围
    cluster_patterns = (cluster_patterns - min(cluster_patterns(:))) / ...
                      (max(cluster_patterns(:)) - min(cluster_patterns(:)));
    
    % 绘制每个聚类的脑地形图
    for i = 1:min(n_clusters, 4) % 最多显示4个聚类
        subplot(2, 2, i);
        
        % 创建脑地形图
        plot_topographic_map(cluster_patterns(i, :), electrode_positions, ...
                            sprintf('Cluster %d (n=%d)', i, sum(labels == unique_labels(i))));
    end
    
    % 设置总标题
    sgtitle(sprintf('EEG Channel Activation Patterns - %s', strrep(dataset_name, '_', '\_')), ...
            'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存图形
    fig_file = fullfile(result_dir, sprintf('%s_eeg_channels.png', dataset_name));
    saveas(fig, fig_file, 'png');
    
    % 保存高分辨率版本
    fig_file_hires = fullfile(result_dir, sprintf('%s_eeg_channels_hires.png', dataset_name));
    print(fig, fig_file_hires, '-dpng', '-r300');
    
    close(fig);
    
    fprintf('EEG通道可视化图已保存: %s\n', fig_file);
    
    % 绘制通道权重分析图
    plot_channel_weight_analysis(cluster_patterns, electrode_positions, dataset_name, result_dir);
    
catch ME
    fprintf('绘制EEG通道可视化图时出错: %s\n', ME.message);
    if exist('fig', 'var')
        close(fig);
    end
end

end

function electrode_positions = get_standard_electrode_positions(n_channels)
% 获取标准EEG电极位置 (基于10-20系统)

% 标准64通道位置 (theta, radius)
standard_64 = [
    0, 0;           % Cz (中心)
    90, 0.25;       % C3
    270, 0.25;      % C4
    0, 0.4;         % Fz
    180, 0.4;       % Pz
    45, 0.35;       % FC3
    315, 0.35;      % FC4
    135, 0.35;      % CP3
    225, 0.35;      % CP4
    90, 0.5;        % F3
    270, 0.5;       % F4
    180, 0.5;       % P3
    0, 0.5;         % P4
    60, 0.6;        % F7
    300, 0.6;       % F8
    120, 0.6;       % T7
    240, 0.6;       % T8
    150, 0.6;       % P7
    210, 0.6;       % P8
    30, 0.7;        % Fp1
    330, 0.7;       % Fp2
    90, 0.8;        % O1
    270, 0.8;       % O2
];

% 根据实际通道数调整
if n_channels <= size(standard_64, 1)
    electrode_positions = standard_64(1:n_channels, :);
else
    % 如果通道数超过标准位置，随机分布额外通道
    electrode_positions = standard_64;
    extra_channels = n_channels - size(standard_64, 1);
    
    for i = 1:extra_channels
        theta = rand() * 360;
        radius = 0.3 + rand() * 0.4;
        electrode_positions = [electrode_positions; theta, radius];
    end
end

% 转换为笛卡尔坐标
theta_rad = electrode_positions(:, 1) * pi / 180;
radius = electrode_positions(:, 2);
electrode_positions = [radius .* cos(theta_rad), radius .* sin(theta_rad)];

end

function plot_topographic_map(values, positions, title_str)
% 绘制脑地形图

% 创建插值网格
[xi, yi] = meshgrid(linspace(-1, 1, 100), linspace(-1, 1, 100));

% 插值数据
zi = griddata(positions(:, 1), positions(:, 2), values, xi, yi, 'cubic');

% 创建圆形掩码
mask = sqrt(xi.^2 + yi.^2) <= 1;
zi(~mask) = NaN;

% 绘制地形图
contourf(xi, yi, zi, 20, 'LineStyle', 'none');
hold on;

% 绘制电极位置
scatter(positions(:, 1), positions(:, 2), 30, 'k', 'filled');

% 绘制头部轮廓
theta = linspace(0, 2*pi, 100);
plot(cos(theta), sin(theta), 'k-', 'LineWidth', 2);

% 绘制鼻子
nose_x = [0, -0.1, 0.1, 0];
nose_y = [1, 1.1, 1.1, 1];
plot(nose_x, nose_y, 'k-', 'LineWidth', 2);

% 绘制耳朵
ear_theta = linspace(-pi/6, pi/6, 20);
left_ear_x = -1 + 0.1 * cos(ear_theta + pi/2);
left_ear_y = 0.1 * sin(ear_theta + pi/2);
right_ear_x = 1 + 0.1 * cos(ear_theta - pi/2);
right_ear_y = 0.1 * sin(ear_theta - pi/2);
plot(left_ear_x, left_ear_y, 'k-', 'LineWidth', 2);
plot(right_ear_x, right_ear_y, 'k-', 'LineWidth', 2);

% 设置坐标轴
axis equal;
axis off;
xlim([-1.2, 1.2]);
ylim([-1.2, 1.2]);

% 添加颜色条
colorbar;
colormap('jet');

% 设置标题
title(title_str, 'FontSize', 12, 'FontWeight', 'bold');

end

function plot_channel_weight_analysis(cluster_patterns, electrode_positions, dataset_name, result_dir)
% 绘制通道权重分析图

try
    fig = figure('Position', [100, 100, 1000, 600], 'Visible', 'off');
    
    % 计算通道重要性 (跨聚类的方差)
    channel_importance = var(cluster_patterns, [], 1);
    
    % 子图1: 通道重要性条形图
    subplot(2, 2, 1);
    bar(1:length(channel_importance), channel_importance, 'FaceColor', [0.2, 0.6, 0.8]);
    xlabel('Channel Index', 'FontSize', 10);
    ylabel('Importance (Variance)', 'FontSize', 10);
    title('Channel Importance Analysis', 'FontSize', 12);
    grid on;
    
    % 子图2: 聚类间相似性热图
    subplot(2, 2, 2);
    similarity_matrix = corr(cluster_patterns');
    imagesc(similarity_matrix);
    colorbar;
    colormap('RdBu');
    caxis([-1, 1]);
    xlabel('Cluster', 'FontSize', 10);
    ylabel('Cluster', 'FontSize', 10);
    title('Inter-cluster Similarity', 'FontSize', 12);
    
    % 子图3: 主成分分析
    subplot(2, 2, 3);
    [coeff, score, ~] = pca(cluster_patterns);
    scatter(score(:, 1), score(:, 2), 100, 1:size(cluster_patterns, 1), 'filled');
    xlabel('PC1', 'FontSize', 10);
    ylabel('PC2', 'FontSize', 10);
    title('PCA of Cluster Patterns', 'FontSize', 12);
    colorbar;
    grid on;
    
    % 子图4: 通道激活强度分布
    subplot(2, 2, 4);
    mean_activation = mean(cluster_patterns, 1);
    histogram(mean_activation, 20, 'FaceColor', [0.8, 0.4, 0.2], 'EdgeColor', 'black');
    xlabel('Activation Level', 'FontSize', 10);
    ylabel('Number of Channels', 'FontSize', 10);
    title('Channel Activation Distribution', 'FontSize', 12);
    grid on;
    
    sgtitle(sprintf('Channel Weight Analysis - %s', strrep(dataset_name, '_', '\_')), ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % 保存图形
    fig_file = fullfile(result_dir, sprintf('%s_channel_analysis.png', dataset_name));
    saveas(fig, fig_file, 'png');
    
    close(fig);
    
    fprintf('通道权重分析图已保存: %s\n', fig_file);
    
catch ME
    fprintf('绘制通道权重分析图时出错: %s\n', ME.message);
    if exist('fig', 'var')
        close(fig);
    end
end

end
