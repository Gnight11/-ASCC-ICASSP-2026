function S = knn_vec(X, k, metric)
% KNN_KERNEL_VEC: Vectorized k-NN kernel construction
%
% INPUTS:
%   X      - n x d data matrix
%   k      - number of neighbors
%   metric - distance metric ('euclidean', 'cosine', etc.)
%
% OUTPUT:
%   S      - n x n knn graph

if nargin < 3
    metric = 'euclidean';
end

n = size(X,1);

% 确保输入数据是实数数组
X = real(X);

% 检查并处理NaN和Inf值
X(isnan(X) | isinf(X)) = 0;

% Compute full pairwise distance matrix
D = pdist2(X, X, metric);   % n x n

% For each row, find indices of k nearest neighbors (exclude self)
[~, idx] = sort(D, 2, 'ascend'); 
neighbors = idx(:, 2:k+1);  % skip self (first column)

% Construct sparse adjacency matrix
I = repmat((1:n)', [1, k]);
J = neighbors;
V = ones(n, k);
S = sparse(I(:), J(:), V(:), n, n);
end
