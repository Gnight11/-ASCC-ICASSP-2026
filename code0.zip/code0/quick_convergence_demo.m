% QUICK_CONVERGENCE_DEMO: 快速收敛曲线演示
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 快速收敛曲线演示 ===\n');

% 创建结果目录
result_dir = 'quick_convergence_demo';
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 获取数据集
data_dir = fullfile('..', 'data');
mat_files = dir(fullfile(data_dir, '*.mat'));

if ~isempty(mat_files)
    % 使用第一个数据集
    dataset_file = mat_files(1).name;
    dataset_path = fullfile(data_dir, dataset_file);
    dataset_name = strrep(dataset_file, '.mat', '');
    
    fprintf('测试数据集: %s\n', dataset_name);
    
    try
        % 加载数据
        [data, gt] = load_timeseries_mat(dataset_path);
        n_samples = length(gt);
        n_classes = length(unique(gt));
        
        fprintf('数据: %d样本, %d类别\n', n_samples, n_classes);
        
        % 快速参数设置（展示收敛过程）
        params = struct();
        params.c = n_classes;
        params.k = 12;                    % 较小的k值
        params.T = 15;                    % 较少的扩散步数
        params.r = 15;                    % 较少的基聚类器
        params.maxRounds = 8;             % 8轮迭代
        params.earlyStop = false;         % 禁用早停
        params.acceptEps = 1e-6;          % 严格收敛标准
        params.snnWeight = 0.4;           % 较低SNN权重
        params.alpha = 0.5;               % 较低扩散系数
        params.beta = 0.3;                % 较低平衡参数
        params.gamma = 1.0;               % 较低gamma值
        
        rng(42); % 固定随机种子
        
        %% 无监督聚类
        fprintf('\n--- 无监督聚类 (8轮) ---\n');
        tic;
        res_unsup = unsupervised_consensus_driver(data, params);
        time_unsup = toc;
        
        Y_unsup = res_unsup.final.Y(:);
        M_unsup = metrics_eval(gt, Y_unsup);
        fprintf('无监督: ACC=%.4f (%.2fs)\n', M_unsup.ACC, time_unsup);
        
        %% 半监督聚类
        fprintf('\n--- 半监督聚类 (6轮) ---\n');
        tic;
        
        % 生成简单约束
        params_sup = params;
        params_sup.maxRounds = 6;
        
        % 快速约束生成
        n_constraints = min(20, round(n_samples * 0.02));
        constraints_ml = [];
        constraints_cl = [];
        
        % 生成ML约束
        for i = 1:n_constraints/2
            same_class_indices = find(gt == gt(randi(n_samples)));
            if length(same_class_indices) >= 2
                idx = randsample(same_class_indices, 2);
                constraints_ml = [constraints_ml; idx'];
            end
        end
        
        % 生成CL约束
        for i = 1:n_constraints/2
            idx1 = randi(n_samples);
            different_class_indices = find(gt ~= gt(idx1));
            if ~isempty(different_class_indices)
                idx2 = different_class_indices(randi(length(different_class_indices)));
                constraints_cl = [constraints_cl; [idx1, idx2]];
            end
        end
        
        params_sup.constraints_ml = constraints_ml;
        params_sup.constraints_cl = constraints_cl;
        params_sup.ml_weight = 30.0;
        params_sup.cl_weight = 30.0;
        
        fprintf('约束: ML=%d, CL=%d\n', size(constraints_ml,1), size(constraints_cl,1));
        
        res_sup = active_semisupervised_consensus_driver(data, params_sup);
        time_sup = toc;
        
        Y_sup = res_sup.final.Y(:);
        M_sup = metrics_eval(gt, Y_sup);
        fprintf('半监督: ACC=%.4f (%.2fs)\n', M_sup.ACC, time_sup);
        
        %% 检查收敛数据
        fprintf('\n--- 收敛数据检查 ---\n');
        
        % 无监督收敛数据
        if isfield(res_unsup, 'ObjHist') && ~isempty(res_unsup.ObjHist)
            rayleigh_unsup = arrayfun(@(o) real(o.rayleigh), res_unsup.ObjHist);
            fprintf('无监督收敛点数: %d\n', length(rayleigh_unsup));
            fprintf('Rayleigh轨迹: %s\n', mat2str(rayleigh_unsup, 4));
        else
            fprintf('无监督: 无ObjHist数据\n');
        end
        
        % 半监督收敛数据
        if isfield(res_sup, 'history') && ~isempty(res_sup.history)
            rayleigh_sup = [];
            for i = 1:length(res_sup.history)
                if isfield(res_sup.history(i), 'obj') && isfield(res_sup.history(i).obj, 'rayleigh')
                    rayleigh_sup = [rayleigh_sup, real(res_sup.history(i).obj.rayleigh)];
                end
            end
            fprintf('半监督收敛点数: %d\n', length(rayleigh_sup));
            fprintf('Rayleigh轨迹: %s\n', mat2str(rayleigh_sup, 4));
        else
            fprintf('半监督: 无history数据\n');
        end
        
        %% 生成收敛图
        fprintf('\n--- 生成收敛图 ---\n');
        try
            plot_convergence_robust(res_unsup, res_sup, dataset_name, result_dir);
            fprintf('✓ 收敛图已生成在: %s\n', result_dir);
            
            % 列出生成的文件
            files = dir(fullfile(result_dir, '*.png'));
            for i = 1:length(files)
                fprintf('  - %s\n', files(i).name);
            end
        catch err
            fprintf('✗ 收敛图生成失败: %s\n', err.message);
        end
        
        fprintf('\n=== 快速演示完成 ===\n');
        
    catch ME
        fprintf('演示失败: %s\n', ME.message);
    end
else
    fprintf('未找到数据集文件\n');
end
