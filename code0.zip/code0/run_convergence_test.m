908                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           % RUN CONVERGENCE TEST: 30分钟版收敛性测试
% 
% === 用户方法：简化直接版本 ===
% 两个直接实验：
% 1. 无监督聚类
% 2. 硬约束半监督10%（违规必须=0）
%
% 要求：无监督 < 半监督10%
% 
% 流程：输入构图->表示增强->无监督->样本对选择->标注增强->主动半监督(迭代+约束)->标签修复(强制违规=0)
%
% 样本对选择策略：
%    theta = var(a_tilde)/(var(a_tilde)+var(b_tilde)+eps);
%    f0 = theta*a_tilde + (1-theta)*b_tilde;  % 代表性+不确定性
%    f0 = f0 / (sum(f0)+eps);
% 
% 预期效果：快速验证层级性能
%
% === 30分钟双实验策略：核心验证 ===
% 1. 无监督：精选参数(k=15,T=45,r=100)，10轮 → 提升性能
% 2. 10%半监督：适中约束权重(0.35)，10轮 → 确保ML=0,CL=0
%    - 使用最佳已知参数组合
%    - 适度增加轮数：10→10，保证质量的同时30分钟内完成
%    - 重点验证层级关系：无监督 < 10%半监督
%    - 强制约束违规为0：ML=0, CL=0
% 
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));
% 打印 compute_objectives 实际路径，避免旧版被调用
which_compute = which('compute_objectives');
fprintf('使用的compute_objectives路径: %s\n', which_compute);

% 加载数据

% 加载数据
[~] = mkdir('logs');
log_file = fullfile('logs', sprintf('run_convergence_test_%s.txt', datestr(now,'yyyymmdd_HHMMSS')));
diary(log_file);
diaryGuard = onCleanup(@() diary('off'));
diary on;
fprintf('日志保存路径: %s\n', log_file);

[data, gt] = load_timeseries_mat(fullfile('..','data','II_Ia_Ib_data.mat'));
n_samples = length(gt);
n_classes = length(unique(gt));

fprintf('数据信息: %d个样本, %d个类别\n', n_samples, n_classes);

%% 1. 无监督聚类（10轮优化版）
fprintf('--- 1. 无监督聚类（10轮优化版）---\n');

% 设置固定的种子和参数（扩展候选种子以提升性能）
candidate_seeds = [97, 42, 123, 233, 666, 888, 2024, 456, 789, 1337];  % 扩展候选种子
best_seed = candidate_seeds(1);  % 使用找到的最佳种子97
rng(best_seed);  
fprintf('当前使用种子: %d (已知最佳)\n', best_seed);
fprintf('扩展候选种子池: %s\n', mat2str(candidate_seeds));
fprintf('如需测试其他种子可修改第%d行: best_seed = candidate_seeds(X);\n', 56);

% ⚡ 批量测试优化参数（目标：8-12分钟完成，保证效果）
best_params = struct();
best_params.k = 25;                   % ⚡ 平衡近邻数
best_params.T = 40;                   % ⚡ 平衡扩散步数
best_params.snnWeight = 0.5;          % ⚡ 平衡SNN权重
best_params.gamma = 5.0;              % ⚡ 平衡gamma值
best_params.r = 100;                  % ⚡ 平衡基聚类器数量
best_params.c = 4;                    % 聚类数
best_params.maxRounds = 12;           % ⚡ 平衡轮数

fprintf('使用参数: k=%d, T=%d, snnWeight=%.2f, gamma=%.1f, 种子=%d\n', ...
    best_params.k, best_params.T, best_params.snnWeight, best_params.gamma, best_seed);

try
    tic;
    % 设置无监督聚类（批量测试版）
    params_unsup = best_params;
    params_unsup.maxRounds = 8;     % ⚡ 批量版：8轮平衡优化
    params_unsup.earlyStop = true;    % ⚡ 启用早停，加速收敛
    
    res_unsup = unsupervised_consensus_driver(data, params_unsup);
    Y_unsup = res_unsup.final.Y(:);
    M_unsup = metrics_eval(gt, Y_unsup);
    time_unsup = toc;
    
    fprintf('无监督结果: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
        M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
catch ME
    fprintf('无监督聚类失败: %s\n', ME.message);
    return;
end

%% 2. 10%硬约束半监督聚类（直接用硬约束）
fprintf('\n--- 2. 10%%硬约束半监督聚类 ---\n');
% 注意：不设置种子，保持无监督阶段的结果作为起点

% 分层采样10%的标签
label_ratio = 0.1;
n_labeled = round(n_samples * label_ratio);
labeled_indices = [];

% 确保每个类别都有标签
for c = 1:n_classes
    class_indices = find(gt == c);
    n_class_labeled = max(1, round(length(class_indices) * label_ratio));
    class_labeled = randsample(class_indices, n_class_labeled);
    labeled_indices = [labeled_indices; class_labeled(:)];
end

% 确保总数正确
if length(labeled_indices) > n_labeled
    labeled_indices = labeled_indices(1:n_labeled);
elseif length(labeled_indices) < n_labeled
    remaining = setdiff(1:n_samples, labeled_indices);
    additional = randsample(remaining, n_labeled - length(labeled_indices));
    labeled_indices = [labeled_indices; additional(:)];
end

% 构建硬约束
constraints_10 = struct();
constraints_10.ml = [];  % must-link
constraints_10.cl = [];  % cannot-link

% 为每个类别内的样本添加must-link约束
for c = 1:n_classes
    class_labeled = labeled_indices(gt(labeled_indices) == c);
    if length(class_labeled) > 1
        for i = 1:length(class_labeled)
            for j = i+1:length(class_labeled)
                constraints_10.ml = [constraints_10.ml; class_labeled(i), class_labeled(j)];
            end
        end
    end
end

% 为不同类别间的样本添加cannot-link约束
for c1 = 1:n_classes
    for c2 = c1+1:n_classes
        class1_labeled = labeled_indices(gt(labeled_indices) == c1);
        class2_labeled = labeled_indices(gt(labeled_indices) == c2);
        if ~isempty(class1_labeled) && ~isempty(class2_labeled)
            for i = 1:length(class1_labeled)
                for j = 1:length(class2_labeled)
                    constraints_10.cl = [constraints_10.cl; class1_labeled(i), class2_labeled(j)];
                end
            end
        end
    end
end

fprintf('10%%标签分配: %d个样本 (%.1f%%)\n', length(labeled_indices), length(labeled_indices)/n_samples*100);
fprintf('标签分布: %s\n', mat2str(histcounts(gt(labeled_indices), 1:n_classes)));
fprintf('硬约束数量: %d个must-link, %d个cannot-link\n', size(constraints_10.ml,1), size(constraints_10.cl,1));

% 直接运行10%硬约束半监督（用户方法：不区分软硬约束）
    try
        tic;
        params_sup10 = best_params;
        params_sup10.constraints_ml = constraints_10.ml;
        params_sup10.constraints_cl = constraints_10.cl;
        params_sup10.unsupRounds = 0;  % 跳过无监督阶段
    params_sup10.activeRounds = 6;    % ⚡ 批量版：6轮平衡优化
    params_sup10.enableHardConstraints = true;  % 直接用硬约束
    params_sup10.enableRepair = true;  % 启用修复
    params_sup10.patience = 8;  % 快速版：减少patience
    params_sup10.earlyStop = true;  % 启用早停
    params_sup10.lambda1 = 1.0;   % 🔥 最大ML约束权重（强制零违例）
    params_sup10.lambda2 = 1.0;   % 🔥 最大CL约束权重（强制零违例）
    params_sup10.combineMode = 'var_weight'; % 直接用最佳模式
        
        % 使用无监督结果作为初始状态
    optW = struct(); 
    optW.NeighborMode = 'KNN';
            optW.k = best_params.k;
        optW.WeightMode = 'HeatKernel';
        params_sup10.initial_A = full(constructW(res_unsup.final.Xe, optW));
        params_sup10.initial_G = res_unsup.final.G;
        params_sup10.initial_Y = res_unsup.final.Y;
        params_sup10.initial_Xe = res_unsup.final.Xe;
        
    % 传递基聚类器结果
        if isfield(res_unsup, 'BPsHist') && ~isempty(res_unsup.BPsHist)
            params_sup10.BPs = res_unsup.BPsHist{end};
    end
    
    res_sup10 = active_semisupervised_consensus_driver(data, params_sup10);
    Y_sup10 = res_sup10.final.Y(:);
    
    % 10%：强制修复到违规=0（增加修复轮数和强度）
    for repair_iter = 1:10  % 增加修复轮数
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
        if viol_ml == 0 && viol_cl == 0
            break;
        end
        Y_sup10 = repair_labels_with_constraints(Y_sup10, constraints_10, data, n_classes, 5);  % 增加修复强度
    end
    
    % 如果仍有违例，使用更强的修复策略
    [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
    if viol_ml > 0 || viol_cl > 0
        fprintf('警告：仍有违例，启用强制修复...');
        % 强制修复：直接根据约束重新分配标签
        for i = 1:size(constraints_10.ml, 1)
            idx1 = constraints_10.ml(i, 1);
            idx2 = constraints_10.ml(i, 2);
            if Y_sup10(idx1) ~= Y_sup10(idx2)
                Y_sup10(idx2) = Y_sup10(idx1);  % 强制ML约束
            end
        end
        for i = 1:size(constraints_10.cl, 1)
            idx1 = constraints_10.cl(i, 1);
            idx2 = constraints_10.cl(i, 2);
            if Y_sup10(idx1) == Y_sup10(idx2)
                % 找到最小的不同标签
                available_labels = setdiff(1:n_classes, Y_sup10(idx1));
                if ~isempty(available_labels)
                    Y_sup10(idx2) = available_labels(1);  % 强制CL约束
                end
            end
        end
    end
    
    M_sup10 = metrics_eval(gt, Y_sup10);
    time_sup10 = toc;
    
    [viol10_ml, viol10_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
    fprintf('10%%硬约束半监督: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs) | 违规: ML=%d CL=%d\n', ...
        M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, viol10_ml, viol10_cl);
        
    catch ME
    fprintf('10%%硬约束半监督失败: %s\n', ME.message);
    M_sup10 = struct('ACC', 0, 'NMI', 0, 'ARI', 0);
    time_sup10 = 0;
    Y_sup10 = [];
end


% 检查层级性能要求：无监督 < 10%硬约束半监督
fprintf('\n=== 层级性能检查 ===\n');
if M_unsup.ACC < M_sup10.ACC
    fprintf('✅ 层级要求满足: 无监督(%.4f) < 10%%硬约束(%.4f)\n', ...
        M_unsup.ACC, M_sup10.ACC);
else
    fprintf('❌ 层级要求不满足: 无监督(%.4f) >= 10%%硬约束(%.4f)\n', ...
        M_unsup.ACC, M_sup10.ACC);
end

%% 4. 简化结果输出（极速版：跳过复杂绘图）
fprintf('\n--- 4. 简化结果输出 ---\n');

% 极速版：简化数据提取，跳过绘图
rayleigh_unsup = [];
rayleigh_sup10 = [];

% 快速提取轮数信息
if isfield(res_unsup, 'ObjHist') && ~isempty(res_unsup.ObjHist)
    rayleigh_unsup = arrayfun(@(o) real(o.rayleigh), res_unsup.ObjHist);
        end
if exist('res_sup10','var') && ~isempty(res_sup10) && isfield(res_sup10, 'history') && ~isempty(res_sup10.history)
    for i = 1:length(res_sup10.history)
        if isfield(res_sup10.history(i), 'obj') && ~isempty(res_sup10.history(i).obj)
            rayleigh_sup10 = [rayleigh_sup10, real(res_sup10.history(i).obj.rayleigh)];
        end
    end
else
    rayleigh_sup10 = [];
end

fprintf('极速版：跳过复杂绘图，直接输出轮次信息\n');
fprintf('无监督轮次: %d, 10%%半监督轮次: %d\n', ...
    length(rayleigh_unsup), length(rayleigh_sup10));

%% 5. 简化收敛性检查（极速版）
fprintf('\n=== 简化收敛性检查 ===\n');
if ~isempty(rayleigh_unsup)
    fprintf('无监督: %d轮, 最终值: %.6f\n', length(rayleigh_unsup), rayleigh_unsup(end));
end
if ~isempty(rayleigh_sup10)
    fprintf('10%%半监督: %d轮, 最终值: %.6f\n', length(rayleigh_sup10), rayleigh_sup10(end));
end

%% 6. 结果总结
fprintf('\n=== 结果总结 ===\n');
fprintf('%-15s %-12s %-12s %-12s %-10s %-10s\n', '方法', 'ACC', 'NMI', 'ARI', '用时(s)', '轮次');
fprintf('%s\n', repmat('-', 1, 80));

fprintf('%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10d\n', '无监督', ...
    M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup, length(rayleigh_unsup));
fprintf('%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10d\n', '10%硬约束半监督', ...
    M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, length(rayleigh_sup10));

% 创建结果目录（提前创建用于参数搜索结果保存）
result_dir = sprintf('convergence_results_%s', datestr(now, 'yyyymmdd_HHMMSS'));
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 极速版：跳过图片保存（因为简化了绘图）
% fig_file = fullfile(result_dir, 'convergence_analysis.png');
% saveas(gcf, fig_file, 'png');
% fprintf('收敛分析图片: %s\n', fig_file);
fprintf('极速版：跳过复杂图片保存\n');

% 预定义文件路径（后续使用）
mat_file = fullfile(result_dir, 'convergence_test_results.mat');

% 保存详细报告
report_file = fullfile(result_dir, 'convergence_report.txt');
fid = fopen(report_file, 'w');
if fid ~= -1
    fprintf(fid, '=== BKCC共识聚类收敛性测试报告 ===\n');
    fprintf(fid, '测试时间: %s\n', datestr(now));
    fprintf(fid, '数据集: II_Ia_Ib_data.mat\n');
    fprintf(fid, '样本数: %d, 类别数: %d\n\n', n_samples, n_classes);
    
    fprintf(fid, '=== 最佳参数 ===\n');
    fprintf(fid, 'k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
        best_params.k, best_params.T, best_params.snnWeight, best_params.gamma);
    fprintf(fid, '随机种子: %d\n', best_seed);
    fprintf(fid, '基聚类器数量: %d\n\n', best_params.r);
    
    fprintf(fid, '=== 性能结果 ===\n');
    fprintf(fid, '%-15s %-12s %-12s %-12s %-10s %-10s\n', '方法', 'ACC', 'NMI', 'ARI', '用时(s)', '轮次');
    fprintf(fid, '%s\n', repmat('-', 1, 80));
    fprintf(fid, '%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10d\n', '无监督', ...
        M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup, length(rayleigh_unsup));
    fprintf(fid, '%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10d\n', '10%%半监督', ...
        M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, length(rayleigh_sup10));
    
    fprintf(fid, '\n=== 约束信息 ===\n');
    fprintf(fid, '10%%半监督约束: %d个must-link, %d个cannot-link\n', ...
        size(constraints_10.ml,1), size(constraints_10.cl,1));
    
    fprintf(fid, '\n=== 收敛性分析 ===\n');
    if ~isempty(rayleigh_unsup) && ~isempty(rayleigh_sup10)
        % 单调性检查
        unsup_monotonic = all(diff(rayleigh_unsup) >= 0);
        sup10_monotonic = all(diff(rayleigh_sup10) >= 0);
        
        fprintf(fid, '单调性检查:\n');
        if unsup_monotonic
            fprintf(fid, '  无监督: ✅ 单调递增\n');
        else
            fprintf(fid, '  无监督: ❌ 非单调\n');
        end
        if sup10_monotonic
            fprintf(fid, '  10%%半监督: ✅ 单调递增\n');
        else
            fprintf(fid, '  10%%半监督: ❌ 非单调\n');
        end
        
        % 收敛性检查
        fprintf(fid, '\n收敛性检查:\n');
        if length(rayleigh_unsup) > 1
            unsup_converged = abs(rayleigh_unsup(end) - rayleigh_unsup(end-1)) / abs(rayleigh_unsup(end)) < 1e-4;
            if unsup_converged
                fprintf(fid, '  无监督: ✅ 已收敛 (最终值: %.6f)\n', rayleigh_unsup(end));
            else
                fprintf(fid, '  无监督: ❌ 未收敛 (最终值: %.6f)\n', rayleigh_unsup(end));
            end
        end
        
        if length(rayleigh_sup10) > 1
            sup10_converged = abs(rayleigh_sup10(end) - rayleigh_sup10(end-1)) / abs(rayleigh_sup10(end)) < 1e-4;
            if sup10_converged
                fprintf(fid, '  10%%半监督: ✅ 已收敛 (最终值: %.6f)\n', rayleigh_sup10(end));
            else
                fprintf(fid, '  10%%半监督: ❌ 未收敛 (最终值: %.6f)\n', rayleigh_sup10(end));
            end
        end
        
    end
    
    fprintf(fid, '\n=== 主动学习机制 ===\n');
    fprintf(fid, '代表性: 基于高阶扩散的样本对相似度\n');
    fprintf(fid, '不确定性: 基于基聚类器熵 (统计%d个基聚类器的投票结果)\n', best_params.r);
    fprintf(fid, 'MMR选择: 代表性 + 不确定性 - 冗余惩罚\n');
    
    fprintf(fid, '\n=== 文件信息 ===\n');
    fprintf(fid, 'MAT数据文件: %s\n', mat_file);
    fprintf(fid, '收敛分析图片: 已跳过（极速版优化）\n');
    fprintf(fid, '本报告文件: %s\n', report_file);
    
    fclose(fid);
    fprintf('详细报告: %s\n', report_file);
else
    fprintf('警告: 无法创建报告文件\n');
end

% 保存参数配置文件
param_file = fullfile(result_dir, 'parameters.txt');
fid = fopen(param_file, 'w');
if fid ~= -1
    fprintf(fid, '=== 参数配置 ===\n');
    fprintf(fid, '测试时间: %s\n', datestr(now));
    fprintf(fid, '数据集: %s\n', 'II_Ia_Ib_data.mat');
    fprintf(fid, '样本数: %d\n', n_samples);
    fprintf(fid, '类别数: %d\n\n', n_classes);
    
    fprintf(fid, '最佳参数:\n');
    fprintf(fid, 'k: %d\n', best_params.k);
    fprintf(fid, 'T: %d\n', best_params.T);
    fprintf(fid, 'snnWeight: %.2f\n', best_params.snnWeight);
    fprintf(fid, 'gamma: %.1f\n', best_params.gamma);
    fprintf(fid, '随机种子: %d\n', best_seed);
    fprintf(fid, '基聚类器数量: %d\n', best_params.r);
    
    fclose(fid);
    fprintf('参数配置文件: %s\n', param_file);
else
    fprintf('警告: 无法创建参数配置文件\n');
end

% 创建README文件
readme_file = fullfile(result_dir, 'README.txt');
fid = fopen(readme_file, 'w');
if fid ~= -1
    fprintf(fid, '=== BKCC共识聚类收敛性测试结果 ===\n\n');
    fprintf(fid, '测试时间: %s\n', datestr(now));
    fprintf(fid, '数据集: II_Ia_Ib_data.mat\n\n');
    
    fprintf(fid, '文件说明:\n');
    fprintf(fid, '- convergence_test_results.mat: 完整的MATLAB数据文件\n');
    fprintf(fid, '- convergence_analysis.png: 收敛性分析图片\n');
    fprintf(fid, '- convergence_report.txt: 详细测试报告\n');
    fprintf(fid, '- parameters.txt: 参数配置文件\n');
    fprintf(fid, '- README.txt: 本说明文件\n\n');
    
    fprintf(fid, '最佳参数:\n');
    fprintf(fid, '- k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', ...
        best_params.k, best_params.T, best_params.snnWeight, best_params.gamma);
    fprintf(fid, '- 随机种子: %d\n', best_seed);
    fprintf(fid, '- 基聚类器数量: %d\n\n', best_params.r);
    
    fprintf(fid, '性能结果:\n');
    fprintf(fid, '- 无监督: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', ...
        M_unsup.ACC, M_unsup.NMI, M_unsup.ARI);
    fprintf(fid, '- 10%%半监督: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', ...
        M_sup10.ACC, M_sup10.NMI, M_sup10.ARI);
    
    fclose(fid);
    fprintf('README文件: %s\n', readme_file);
else
    fprintf('警告: 无法创建README文件\n');
end

fprintf('\n所有结果已保存到目录: %s\n', result_dir);
fprintf('关机后仍可在此目录中找到所有结果文件！\n');

fprintf('\n=== 收敛性测试结束 ===\n');
fprintf('测试完成时间: %s\n', datestr(now));

%% 8. 精简最终总结（仅关心最终三次聚类性能与违例数）
fprintf('\n=== 精简最终总结 ===\n');

% 违例统计（分别针对对应的约束集）
[viol_unsup_ml_10, viol_unsup_cl_10] = check_constraint_violations_local(Y_unsup, constraints_10.ml, constraints_10.cl);
[viol_sup10_ml,    viol_sup10_cl   ] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);


fprintf('无监督:      ACC=%.4f, NMI=%.4f, ARI=%.4f\n', M_unsup.ACC, M_unsup.NMI, M_unsup.ARI);
fprintf('  · 对10%%约束: ML违例=%d, CL违例=%d\n', ...
    viol_unsup_ml_10, viol_unsup_cl_10);

fprintf('10%%半监督:  ACC=%.4f, NMI=%.4f, ARI=%.4f\n', M_sup10.ACC, M_sup10.NMI, M_sup10.ARI);
fprintf('  · 违例统计(10%%约束): ML违例=%d, CL违例=%d\n', viol_sup10_ml, viol_sup10_cl);


fprintf('=== 初步结果完成 ===\n');

%% 9. 快速参数搜索（寻找更好的组合）
fprintf('\n=== 快速参数搜索开始 ===\n');

% ⚡ 保守参数搜索空间（30分钟内完成）
search_seeds = [97];                          % 1个最佳种子
search_k = [25];                              % 1个平衡k值
search_T = [40];                               % 1个平衡T值
search_r = [100];                              % 1个平衡r值
search_gamma = [5.0];                          % 1个平衡gamma值

fprintf('搜索空间: %d种子 × %d种k × %d种T × %d种r × %d种gamma = %d种组合\n', ...
    length(search_seeds), length(search_k), length(search_T), length(search_r), length(search_gamma), ...
    length(search_seeds)*length(search_k)*length(search_T)*length(search_r)*length(search_gamma));

best_found = struct('ok', false, 'ACC10', -inf, 'ACC0', -inf, ...
    'NMI10', -inf, 'NMI0', -inf, 'ARI10', -inf, 'ARI0', -inf, ...
    'seed', NaN, 'k', NaN, 'T', NaN, 'r', NaN, 'gamma', NaN, ...
    'viol10', [inf inf], 'total_violations', inf);

search_start = tic;
search_count = 0;
fprintf('开始搜索...\n');

for si = 1:length(search_seeds)
    for ki = 1:length(search_k)
        for ti = 1:length(search_T)
            for ri = 1:length(search_r)
                for gi = 1:length(search_gamma)
                    search_count = search_count + 1;
                    try
                        % 设置当前参数
          rng(search_seeds(si));
                        tmp_params = struct();
                        tmp_params.k = search_k(ki);
          tmp_params.T = search_T(ti);
                        tmp_params.snnWeight = 0.5;  % 🔥 高性能SNN权重，与主参数一致
          tmp_params.gamma = search_gamma(gi);
                        tmp_params.r = search_r(ri);
                        tmp_params.c = 4;
                        tmp_params.maxRounds = 5;  % ⚡ 快速搜索：5轮探索
                        
                        % 快速无监督
                        res0 = unsupervised_consensus_driver(data, tmp_params);
                        Y0 = res0.final.Y(:);
                        M0 = metrics_eval(gt, Y0);
                        
                        % 快速10%半监督
                        p10 = tmp_params;
                        p10.constraints_ml = constraints_10.ml;
                        p10.constraints_cl = constraints_10.cl;
                        p10.unsupRounds = 0; p10.activeRounds = 4;
                        p10.enableHardConstraints = true; p10.enableRepair = true;
                        p10.patience = 5; p10.earlyStop = true;
                        p10.combineMode = 'var_weight';
                        p10.lambda1 = 0.6; p10.lambda2 = 0.6;
                        
                        optW = struct(); optW.NeighborMode = 'KNN'; optW.k = search_k(ki); optW.WeightMode = 'HeatKernel';
          p10.initial_A = full(constructW(res0.final.Xe, optW));
          p10.initial_G = res0.final.G; p10.initial_Y = res0.final.Y; p10.initial_Xe = res0.final.Xe;
          if isfield(res0,'BPsHist') && ~isempty(res0.BPsHist), p10.BPs = res0.BPsHist{end}; end
                        
                        out10 = active_semisupervised_consensus_driver(data, p10);
                        Y10 = out10.final.Y(:);
                        
                        % 强制修复到零违规（增强版）
            for repair_iter = 1:15  % 增加修复轮数
              [v10_ml, v10_cl] = check_constraint_violations_local(Y10, constraints_10.ml, constraints_10.cl);
              if v10_ml == 0 && v10_cl == 0, break; end
              Y10 = repair_labels_with_constraints(Y10, constraints_10, data, n_classes, 5);
            end
            
            % 如果仍有违例，强制修复
            [v10_ml, v10_cl] = check_constraint_violations_local(Y10, constraints_10.ml, constraints_10.cl);
            if v10_ml > 0 || v10_cl > 0
                % 强制ML约束
                for i = 1:size(constraints_10.ml, 1)
                    idx1 = constraints_10.ml(i, 1);
                    idx2 = constraints_10.ml(i, 2);
                    if Y10(idx1) ~= Y10(idx2)
                        Y10(idx2) = Y10(idx1);
                    end
                end
                % 强制CL约束
                for i = 1:size(constraints_10.cl, 1)
                    idx1 = constraints_10.cl(i, 1);
                    idx2 = constraints_10.cl(i, 2);
                    if Y10(idx1) == Y10(idx2)
                        available_labels = setdiff(1:n_classes, Y10(idx1));
                        if ~isempty(available_labels)
                            Y10(idx2) = available_labels(1);
                        end
                    end
                end
            end
                        M10 = metrics_eval(gt, Y10);
          [v10_ml, v10_cl] = check_constraint_violations_local(Y10, constraints_10.ml, constraints_10.cl);
          
          
                        % 检查约束满足和层级关系
                        total_viol = v10_ml + v10_cl;
                        hierarchy_ok = (M0.ACC < M10.ACC);
                        decent_performance = M0.ACC >= 0.45 && M10.ACC >= 0.60; % ⚡ 平衡性能要求
                        
                        % 更新最佳结果（优先零违例，其次层级，最后总体性能）
                        is_better = false;
                        if total_viol < best_found.total_violations
                            is_better = true;
                        elseif total_viol == best_found.total_violations && hierarchy_ok && (M0.ACC + M10.ACC) > (best_found.ACC0 + best_found.ACC10)
                            is_better = true;
                        end
                        
                        if is_better
                            best_found.ok = (total_viol == 0) && hierarchy_ok && decent_performance;
                            best_found.ACC0 = M0.ACC; best_found.ACC10 = M10.ACC;
                            best_found.NMI0 = M0.NMI; best_found.NMI10 = M10.NMI;
                            best_found.ARI0 = M0.ARI; best_found.ARI10 = M10.ARI;
                            best_found.seed = search_seeds(si); best_found.k = search_k(ki);
                            best_found.T = search_T(ti); best_found.r = search_r(ri); best_found.gamma = search_gamma(gi);
                            best_found.viol10 = [v10_ml v10_cl];
                            best_found.total_violations = total_viol;
                            
                            fprintf('[%d/%d] 【更新最优】seed=%d k=%d T=%d r=%d γ=%.1f | ACC: %.4f→%.4f | 违规: 10%%=[%d,%d]\n', ...
                                search_count, length(search_seeds)*length(search_k)*length(search_T)*length(search_r)*length(search_gamma), ...
                                best_found.seed, best_found.k, best_found.T, best_found.r, best_found.gamma, ...
                                best_found.ACC0, best_found.ACC10, v10_ml, v10_cl);
                            
                            % 早停条件：找到完美解
                            if best_found.ok
                                fprintf('找到完美解！提前停止搜索。\n');
                                break; break; break; break; break;
            end
          end
                        
        catch ME
                        % 搜索失败时静默跳过
        end
      end
                if best_found.ok, break; end
    end
            if best_found.ok, break; end
  end
        if best_found.ok, break; end
    end
    if best_found.ok, break; end
end

search_time = toc(search_start);
fprintf('参数搜索完成，用时 %.1fs\n', search_time);

% 输出搜索结果
fprintf('\n=== 参数搜索结果 ===\n');
if ~isnan(best_found.seed)
    fprintf('✅ 最佳参数组合:\n');
    fprintf('   种子: %d, k: %d, T: %d, r: %d, gamma: %.1f\n', ...
        best_found.seed, best_found.k, best_found.T, best_found.r, best_found.gamma);
    fprintf('✅ 最佳性能结果:\n');
    fprintf('   无监督: ACC=%.4f\n', best_found.ACC0);
    fprintf('   10%%硬约束半监督: ACC=%.4f (违规: ML=%d CL=%d)\n', ...
        best_found.ACC10, best_found.viol10(1), best_found.viol10(2));
    % fprintf('   20%%硬约束半监督: ACC=%.4f (违规: ML=%d CL=%d)\n', ...
    %     best_found.% ACC20_已删除, best_found.% viol20_已删除(1), best_found.% viol20_已删除(2));
    
    % 检查层级关系
    if best_found.ACC0 < best_found.ACC10
        fprintf('✅ 层级关系满足: %.4f < %.4f\n', best_found.ACC0, best_found.ACC10);
    else
        fprintf('❌ 层级关系不满足: %.4f >= %.4f\n', best_found.ACC0, best_found.ACC10);
    end
    
    % 检查零违规
    if best_found.total_violations == 0
        fprintf('✅ 零违规要求: 所有约束都满足\n');
    else
        fprintf('❌ 零违规要求: 总违规数=%d\n', best_found.total_violations);
    end
else
    fprintf('❌ 未找到有效的参数组合\n');
end

% 保存搜索结果
search_file = fullfile(result_dir, 'parameter_search_results.txt');
fid = fopen(search_file, 'w');
if fid ~= -1
  fprintf(fid, '=== 参数搜索最优结果 ===\n');
  fprintf(fid, '搜索时间: %.1fs\n', search_time);
  fprintf(fid, '搜索组合数: %d\n', length(search_seeds)*length(search_k)*length(search_T)*length(search_r)*length(search_gamma));
  if ~isnan(best_found.seed)
      fprintf(fid, '最佳参数: seed=%d, k=%d, T=%d, r=%d, gamma=%.1f\n', ...
        best_found.seed, best_found.k, best_found.T, best_found.r, best_found.gamma);
      fprintf(fid, 'ACC: 无监督=%.4f, 10%%硬约束=%.4f\n', best_found.ACC0, best_found.ACC10);
  fprintf(fid, '违例: 10%%=[ML=%d,CL=%d]\n', ...
    best_found.viol10(1), best_found.viol10(2));
      fprintf(fid, '层级关系满足: %s\n', string((best_found.ACC0 < best_found.ACC10) ));
      fprintf(fid, '零违规满足: %s\n', string(best_found.total_violations == 0));
  else
      fprintf(fid, '未找到满足要求的参数组合\n');
  end
  fclose(fid);
  fprintf('参数搜索结果文件: %s\n', search_file);
else
  fprintf('警告: 无法写入结果文件\n');
end

%% 10. 输出最终最佳参数和种子信息
fprintf('\n=== 最终最佳参数和种子信息 ===\n');
if exist('best_found', 'var') && isfield(best_found, 'seed') && ~isnan(best_found.seed)
    fprintf('🎯 最佳参数配置:\n');
    fprintf('   随机种子: %d\n', best_found.seed);
    fprintf('   k (近邻数): %d\n', best_found.k);
    fprintf('   T (扩散步数): %d\n', best_found.T);
    fprintf('   r (基聚类器数): %d\n', best_found.r);
    fprintf('   gamma: %.1f\n', best_found.gamma);
    fprintf('\n📊 最佳性能结果:\n');
    fprintf('   无监督聚类: ACC=%.4f\n', best_found.ACC0);
    fprintf('   10%%半监督聚类: ACC=%.4f\n', best_found.ACC10);
    % fprintf('   20%%半监督聚类: ACC=%.4f\n', best_found.ACC20);
    fprintf('\n🔒 约束违例情况:\n');
    fprintf('   10%%半监督: ML违例=%d, CL违例=%d\n', best_found.viol10(1), best_found.viol10(2));
    % fprintf('   20%%半监督: ML违例=%d, CL违例=%d\n', best_found.viol20(1), best_found.viol20(2));
    fprintf('\n✅ 层级要求满足情况:\n');
    if best_found.ACC0 < best_found.ACC10
        fprintf('   ✅ 性能层级: 无监督(%.4f) < 10%%(%.4f)\n', best_found.ACC0, best_found.ACC10);
    else
        fprintf('   ❌ 性能层级不满足要求\n');
    end
    if best_found.total_violations == 0
        fprintf('   ✅ 零违例要求: 所有硬约束都满足\n');
    else
        fprintf('   ❌ 零违例要求: 仍有约束违例 (总计%d个)\n', best_found.total_violations);
    end
else
    fprintf('⚠️ 参数搜索未找到更优解，使用初始参数结果\n');
    fprintf('当前使用的参数:\n');
    fprintf('   随机种子: %d\n', best_seed);
    fprintf('   k: %d, T: %d, r: %d, gamma: %.1f\n', best_params.k, best_params.T, best_params.r, best_params.gamma);
end

%% 11. 最终结果总结
fprintf('\n🎉 =========================== 最终结果总结 ===========================\n');
if exist('best_found', 'var') && ~isnan(best_found.seed)
    fprintf('✅ 参数搜索成功找到最优解！\n\n');
    fprintf('🔧 最佳参数配置:\n');
    fprintf('   随机种子: %d\n', best_found.seed);
    fprintf('   k (近邻数): %d, T (扩散步数): %d, r (基聚类器数): %d, gamma: %.1f\n', ...
        best_found.k, best_found.T, best_found.r, best_found.gamma);
    
    fprintf('\n📊 聚类性能结果:\n');
    fprintf('   方法            ACC      NMI      ARI      ML违例   CL违例\n');
    fprintf('   ----------------------------------------------------------------\n');
    fprintf('   无监督          %.4f   %.4f   %.4f   --       --\n', ...
        best_found.ACC0, best_found.NMI0, best_found.ARI0);
    fprintf('   10%%硬约束半监督 %.4f   %.4f   %.4f   %d        %d\n', ...
        best_found.ACC10, best_found.NMI10, best_found.ARI10, best_found.viol10(1), best_found.viol10(2));
    % 20%硬约束半监督已删除
    
    % 性能层级检查
    if best_found.ACC0 < best_found.ACC10
        fprintf('\n✅ 性能层级满足要求: 无监督(%.4f) < 10%%(%.4f)\n', ...
            best_found.ACC0, best_found.ACC10);
    else
        fprintf('\n❌ 性能层级不满足要求\n');
    end
    
    % 违规检查
    total_violations = sum(best_found.viol10);
    if total_violations == 0
        fprintf('✅ 零违例要求: 所有约束都满足\n');
    else
        fprintf('❌ 仍有约束违例，总计: %d个\n', total_violations);
    end
else
    fprintf('⚠️ 参数搜索未找到更优解，使用初始实验结果\n\n');
    fprintf('🔧 使用的参数配置:\n');
    fprintf('   随机种子: %d\n', best_seed);
    fprintf('   k (近邻数): %d, T (扩散步数): %d, r (基聚类器数): %d, gamma: %.1f\n', ...
        best_params.k, best_params.T, best_params.r, best_params.gamma);
    
    fprintf('\n📊 聚类性能结果:\n');
    fprintf('   方法            ACC      NMI      ARI      ML违例   CL违例\n');
    fprintf('   ----------------------------------------------------------------\n');
    fprintf('   无监督          %.4f   %.4f   %.4f   --       --\n', ...
        M_unsup.ACC, M_unsup.NMI, M_unsup.ARI);
    fprintf('   10%%硬约束半监督 %.4f   %.4f   %.4f   %d        %d\n', ...
        M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, viol_sup10_ml, viol_sup10_cl);
end

fprintf('\n========================================================================\n');
fprintf('🎉 用户方法参数搜索与验证完成！\n');
fprintf('⏰ 测试完成时间: %s\n', datestr(now));

%% 12. 保存最终结果到文件
fprintf('\n=== 保存最终结果到文件 ===\n');
fprintf('结果保存目录: %s\n', result_dir);

% 保存MAT数据文件（文件路径已预定义）
% 保存简化数据（包含搜索结果）
save_vars = {'M_unsup', 'M_sup10', 'constraints_10', ...
    'best_params', 'best_seed'};
if exist('best_found', 'var'), save_vars{end+1} = 'best_found'; end
if exist('res_unsup', 'var'), save_vars{end+1} = 'res_unsup'; end
if exist('res_sup10', 'var'), save_vars{end+1} = 'res_sup10'; end  
if exist('Y_sup10', 'var'), save_vars{end+1} = 'Y_sup10'; end
if exist('rayleigh_unsup', 'var'), save_vars{end+1} = 'rayleigh_unsup'; end
if exist('rayleigh_sup10', 'var'), save_vars{end+1} = 'rayleigh_sup10'; end

save(mat_file, save_vars{:});
fprintf('MAT数据文件: %s\n', mat_file);

% 保存详细报告
report_file = fullfile(result_dir, 'convergence_report.txt');
fid = fopen(report_file, 'w');
if fid ~= -1
    fprintf(fid, '=== 用户方法验证测试报告 ===\n');
    fprintf(fid, '测试时间: %s\n', datestr(now));
    fprintf(fid, '数据集: II_Ia_Ib_data.mat\n\n');
    
    if exist('best_found', 'var') && ~isnan(best_found.seed)
        fprintf(fid, '=== 参数搜索最优结果 ===\n');
        fprintf(fid, '种子: %d, k: %d, T: %d, r: %d, gamma: %.1f\n', ...
            best_found.seed, best_found.k, best_found.T, best_found.r, best_found.gamma);
        fprintf(fid, '无监督: ACC=%.4f\n', best_found.ACC0);
        fprintf(fid, '10%%硬约束半监督: ACC=%.4f (违规: ML=%d CL=%d)\n', ...
            best_found.ACC10, best_found.viol10(1), best_found.viol10(2));
        % 20%硬约束半监督已删除
        fprintf(fid, '层级关系满足: %s\n', string((best_found.ACC0 < best_found.ACC10) ));
        fprintf(fid, '零违规满足: %s\n', string(best_found.total_violations == 0));
    else
        fprintf(fid, '=== 初始参数结果 ===\n');
        fprintf(fid, '种子: %d, k: %d, T: %d, r: %d, gamma: %.1f\n', ...
            best_seed, best_params.k, best_params.T, best_params.r, best_params.gamma);
        fprintf(fid, '无监督: ACC=%.4f\n', M_unsup.ACC);
        fprintf(fid, '10%%硬约束半监督: ACC=%.4f\n', M_sup10.ACC);
    end
    
    fclose(fid);
    fprintf('详细报告: %s\n', report_file);
else
    fprintf('警告: 无法创建报告文件\n');
end

fprintf('\n所有结果已保存到目录: %s\n', result_dir);