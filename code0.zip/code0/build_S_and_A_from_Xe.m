function [S, A, sigma] = build_S_and_A_from_Xe(Xe, k, sigma, opts)
%==========================================================================
% FUNCTION: [S, A, sigma] = build_S_and_A_from_Xe(Xe, k, sigma)
% DESCRIPTION:
%   Build a kNN Gaussian similarity matrix S from enhanced representations
%   X_e, then construct an unsupervised affinity matrix A according to
%       A = 1/2 * (I + D * S * D),
%   where D = diag(S * 1).
%
% INPUTS:
%   Xe    : n x d_e enhanced representations (each row is x_i^(e))
%   k     : number of neighbors per node (k >= 1)
%   sigma : Gaussian kernel width. If empty or not provided, it will be set
%           to the median of nonzero kNN distances.
%
% OUTPUTS:
%   S     : n x n sparse, symmetric kNN Gaussian similarity matrix
%   A     : n x n sparse, symmetric positive-definite affinity matrix
%   sigma : the sigma value actually used
%
% NOTES:
%   - S is symmetrized as max(S, S').
%   - Distances are Euclidean on rows of X_e.
%==========================================================================

    if nargin < 2
        error('build_S_and_A_from_Xe: Require at least Xe and k.');
    end

    if ~isnumeric(Xe) || ndims(Xe) ~= 2
        error('build_S_and_A_from_Xe: Xe must be a 2D numeric matrix.');
    end

    if ~isscalar(k) || k < 1
        error('build_S_and_A_from_Xe: k must be a positive scalar.');
    end

    Xe = double(Xe);
    n = size(Xe,1);
    if nargin < 4 || isempty(opts), opts = struct(); end
    distance = 'euclidean';
    if isfield(opts,'distance') && ~isempty(opts.distance)
        distance = opts.distance;
    end
    use_mutual = false;
    if isfield(opts,'mutual') && ~isempty(opts.mutual)
        use_mutual = logical(opts.mutual);
    end
    % optional SNN weighting and gamma sharpening
    snnWeight = 0;
    if isfield(opts,'snnWeight') && ~isempty(opts.snnWeight)
        snnWeight = max(0, min(1, opts.snnWeight));
    end
    gamma = 1;
    if isfield(opts,'gamma') && ~isempty(opts.gamma)
        gamma = max(0.1, opts.gamma);
    end

    % Compute pairwise distances
    if strcmpi(distance,'cosine')
        % cosine distance = 1 - cosine similarity
        Xe_row_norm = sqrt(sum(Xe.^2,2)) + eps;
        Xe_n = Xe ./ Xe_row_norm;
        Sim = Xe_n * Xe_n';
        Sim = max(min(Sim,1),-1);
        Dmat = 1 - Sim;
    else
        % 确保输入数据是实数数组
        Xe = real(Xe);
        Xe(isnan(Xe) | isinf(Xe)) = 0;
        Dmat = pdist2(Xe, Xe, 'euclidean');
    end

    % kNN indices (excluding self)
    [~, idx] = sort(Dmat, 2, 'ascend');
    nnIdx = idx(:, 2:min(k+1, n));

    % Adaptive local scale: sigma_i = distance to the k-th neighbor of i
    % If sigma provided as scalar, still allow override; otherwise compute per-node
    if nargin < 3 || isempty(sigma) || ~isfinite(sigma) || sigma <= 0
        % take the last column (k-th neighbor distance) as local scale per node
        local_sigma = Dmat(sub2ind([n n], (1:n)', nnIdx(:, end)));
        % safety for zeros
        local_sigma(local_sigma <= 0) = median(local_sigma(local_sigma > 0));
        sigma = median(local_sigma); % return a representative scalar for logging
    else
        % user passed a scalar sigma; create per-node local scales around it
        local_sigma = sigma * ones(n,1);
    end

    % Adaptive Gaussian weights for kNN edges: S_ij = exp(-||xi-xj||^2/(sigma_i * sigma_j))
    rowI = repmat((1:n)', 1, size(nnIdx,2));
    colJ = nnIdx;
    dij2 = Dmat(sub2ind([n n], rowI(:), colJ(:))).^2;
    sigma_i = local_sigma(rowI(:));
    sigma_j = local_sigma(colJ(:));
    denom = sigma_i .* sigma_j;
    % protect from zeros
    denom(denom <= eps) = eps;
    W = exp(-dij2 ./ (denom));

    % Build sparse directed kNN graph
    S = sparse(rowI(:), colJ(:), W(:), n, n);
    if use_mutual
        % retain only mutual kNN edges
        S = min(S, S');
    else
        S = max(S, S');
    end

    % Optional: SNN common-neighbor weighting
    if snnWeight > 0
        kEff = size(nnIdx,2);
        snn_row = []; snn_col = []; snn_val = [];
        for i = 1:n
            Ni = nnIdx(i, :);
            Ni_sorted = sort(Ni);
            for jj = 1:kEff
                j = Ni(jj);
                Nj_sorted = sort(nnIdx(j, :));
                cnt = numel(intersect(Ni_sorted, Nj_sorted));
                if cnt > 0
                    snn_row(end+1,1) = i; %#ok<AGROW>
                    snn_col(end+1,1) = j; %#ok<AGROW>
                    snn_val(end+1,1) = cnt / kEff; %#ok<AGROW>
                end
            end
        end
        S_snn = sparse(snn_row, snn_col, snn_val, n, n);
        if use_mutual
            S_snn = min(S_snn, S_snn');
        else
            S_snn = max(S_snn, S_snn');
        end
        S = S .* (1 + snnWeight * S_snn);
        S = min(S, 1);
    end

    % Optional: gamma sharpening on similarities
    if abs(gamma - 1) > eps
        [ii, jj, vv] = find(S);
        vv = vv .^ gamma;
        S = sparse(ii, jj, vv, n, n);
    end

    % Degree matrix D = diag(S*1)
    deg = full(sum(S,2));
    D = spdiags(deg, 0, n, n);

    % Affinity A = 1/2 (I + D S D)
    A = 0.5 * (speye(n) + D * S * D);

end


