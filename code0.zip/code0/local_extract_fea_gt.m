function [fea, gt] = local_extract_fea_gt(S)
%LOCAL_EXTRACT_FEA_GT Robustly extract feature matrix fea (N x D) and labels gt (N x 1)
% from a loaded .mat struct S with flexible field names.

    fea = [];
    gt  = [];

    % Common explicit field names
    if isfield(S, 'fea') && ismatrix(S.fea)
        fea = S.fea; 
    elseif isfield(S, 'X') && ismatrix(S.X)
        fea = S.X; 
    elseif isfield(S, 'data') && ismatrix(S.data)
        fea = S.data; 
    end

    if isfield(S, 'gt') && isvector(S.gt)
        gt = S.gt;
    elseif isfield(S, 'y') && isvector(S.y)
        gt = S.y;
    elseif isfield(S, 'labels') && isvector(S.labels)
        gt = S.labels;
    end

    % If still missing, try auto-detect: choose the largest 2D matrix as fea,
    % and any 1D vector with matching length as gt.
    if isempty(fea) || isempty(gt)
        fns = fieldnames(S);
        mats = {}; vecs = {};
        for t = 1:numel(fns)
            v = S.(fns{t});
            if isnumeric(v)
                if isvector(v)
                    vecs{end+1} = fns{t}; %#ok<AGROW>
                elseif ismatrix(v) && size(v,1) >= 5 && size(v,2) >= 2
                    mats{end+1} = fns{t}; %#ok<AGROW>
                end
            end
        end
        bestName = '';
        bestScore = -inf;
        for t = 1:numel(mats)
            vn = mats{t}; v = S.(vn);
            sc = size(v,1) * size(v,2);
            if sc > bestScore
                bestScore = sc; bestName = vn;
            end
        end
        if ~isempty(bestName)
            fea = S.(bestName);
            N = size(fea,1);
            gtName = '';
            for t = 1:numel(vecs)
                vn = vecs{t}; v = S.(vn);
                if numel(v) == N
                    gt = v; gtName = vn; break;
                end
            end
            % If labels are first column of data
            if isempty(gt)
                firstCol = fea(:,1);
                if isvector(firstCol) && all(isfinite(firstCol)) && numel(unique(firstCol)) < N
                    gt = firstCol; fea = fea(:,2:end);
                end
            end
            if isempty(gt)
                error('Unrecognized data fields: found feature %s but no label vector', bestName);
            else
                fprintf('Auto-detected features from %s; labels=%s\n', bestName, gtName);
            end
        end
    end

    fea = double(fea); fea(~isfinite(fea)) = 0;
    gt  = double(gt(:));
end

















