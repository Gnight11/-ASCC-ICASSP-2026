function w = feature_weights_fisher(fea, gt_labeled)
% Compute simple Fisher score per feature using labeled subset.
% fea: N x D
% gt_labeled: N x 1, with 0 for unlabeled, 1..K for labeled classes
% Returns weights w (1 x D) normalized to sum(w)=D

    [N,D] = size(fea);
    y = gt_labeled(:);
    labeled_mask = y > 0 & isfinite(y);
    if ~any(labeled_mask)
        w = ones(1,D);
        return;
    end

    X = fea(labeled_mask,:);
    y = y(labeled_mask);
    classes = unique(y)';

    mu = mean(X,1);
    Sw = zeros(1,D);
    Sb = zeros(1,D);

    for c = classes
        idx = (y == c);
        if nnz(idx) < 2, continue; end
        Xc = X(idx,:);
        muc = mean(Xc,1);
        % within-class variance
        Sw = Sw + var(Xc,0,1) * nnz(idx);
        % between-class variance
        Sb = Sb + (muc - mu).^2 * nnz(idx);
    end

    score = Sb ./ (Sw + eps);
    score(~isfinite(score)) = 0;

    % normalise weights
    w = score(:)';
    if all(w==0)
        w = ones(1,D);
    end
    w = w / (mean(w) + eps) ; % average 1.0 for stable scaling
end
