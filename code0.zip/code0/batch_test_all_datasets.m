% BATCH TEST ALL DATASETS: 批量测试所有数据集
% 
% 基于run_convergence_test.m修改，支持批量处理data目录中的所有数据集
% 自动识别簇数、维度、变量名等信息，最后汇总输出所有结果
%
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

% 创建结果目录
result_dir = sprintf('batch_results_%s', datestr(now, 'yyyymmdd_HHMMSS'));
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 创建日志文件
log_file = fullfile(result_dir, 'batch_test_log.txt');
diary(log_file);
diaryGuard = onCleanup(@() diary('off'));
diary on;

fprintf('=== 批量数据集测试开始 ===\n');
fprintf('测试时间: %s\n', datestr(now));
fprintf('结果保存目录: %s\n', result_dir);

% 获取所有数据集文件
data_dir = fullfile('..', 'data');
mat_files = dir(fullfile(data_dir, '*.mat'));
fprintf('发现 %d 个数据集文件\n\n', length(mat_files));

% 批量测试优化参数（目标：快速完成大数据集，保证基本效果）
best_params = struct();
best_params.k = 15;                   % ⚡ 减少近邻数加速
best_params.T = 20;                   % ⚡ 减少扩散步数加速  
best_params.snnWeight = 0.5;          % ⚡ 平衡SNN权重
best_params.gamma = 4.0;              % ⚡ 减少gamma值
best_params.r = 50;                   % ⚡ 减少基聚类器数量加速
best_params.maxRounds = 12;           % ⚡ 平衡轮数

% 初始化结果汇总
results_summary = [];
dataset_names = {};

% 逐个处理数据集
for file_idx = 1:length(mat_files)
    dataset_file = mat_files(file_idx).name;
    dataset_path = fullfile(data_dir, dataset_file);
    dataset_name = strrep(dataset_file, '.mat', '');
    
    fprintf('=== 处理数据集 %d/%d: %s ===\n', file_idx, length(mat_files), dataset_name);
    
    try
        % 加载数据集
        [data, gt] = load_timeseries_mat(dataset_path);
        n_samples = length(gt);
        n_classes = length(unique(gt));
        n_features = size(data, 2);
        
        fprintf('数据信息: %d个样本, %d个类别, %d维特征\n', n_samples, n_classes, n_features);
        
        % 设置当前数据集的参数
        current_params = best_params;
        current_params.c = n_classes;  % 自动设置簇数
        
        % 设置随机种子
        rng(97);  % 使用固定种子确保可重复性
        
        %% 1. 无监督聚类
        fprintf('--- 无监督聚类 ---\n');
        tic;
        params_unsup = current_params;
        params_unsup.maxRounds = 5;     % ⚡ 大数据集：减少到5轮
        params_unsup.earlyStop = true;  % ⚡ 启用早停，加速收敛
        
        res_unsup = unsupervised_consensus_driver(data, params_unsup);
        Y_unsup = res_unsup.final.Y(:);
        M_unsup = metrics_eval(gt, Y_unsup);
        time_unsup = toc;
        
        fprintf('无监督结果: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
            M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
        
        %% 2. 10%硬约束半监督聚类
        fprintf('--- 10%%硬约束半监督聚类 ---\n');
        tic;
        
        % 大数据集优化：减少半监督轮数
        params_sup10 = current_params;
        params_sup10.maxRounds = 4;     % ⚡ 大数据集：减少到4轮
        % 分层采样10%的标签
        label_ratio = 0.1;
        n_labeled = round(n_samples * label_ratio);
        labeled_indices = [];
        
        % 确保每个类别都有标签
        for c = 1:n_classes
            class_indices = find(gt == c);
            n_class_labeled = max(1, round(length(class_indices) * label_ratio));
            class_labeled = randsample(class_indices, n_class_labeled);
            labeled_indices = [labeled_indices; class_labeled(:)];
        end
        
        % 确保总数正确
        if length(labeled_indices) > n_labeled
            labeled_indices = labeled_indices(1:n_labeled);
        elseif length(labeled_indices) < n_labeled
            remaining = setdiff(1:n_samples, labeled_indices);
            additional = randsample(remaining, n_labeled - length(labeled_indices));
            labeled_indices = [labeled_indices; additional(:)];
        end
        
        % 构建硬约束
        constraints_10 = struct();
        constraints_10.ml = [];  % must-link
        constraints_10.cl = [];  % cannot-link
        
        % 为每个类别内的样本添加must-link约束
        for c = 1:n_classes
            class_labeled = labeled_indices(gt(labeled_indices) == c);
            if length(class_labeled) > 1
                for i = 1:length(class_labeled)
                    for j = i+1:length(class_labeled)
                        constraints_10.ml = [constraints_10.ml; class_labeled(i), class_labeled(j)];
                    end
                end
            end
        end
        
        % 为不同类别间的样本添加cannot-link约束
        for c1 = 1:n_classes
            for c2 = c1+1:n_classes
                class1_labeled = labeled_indices(gt(labeled_indices) == c1);
                class2_labeled = labeled_indices(gt(labeled_indices) == c2);
                if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                    for i = 1:length(class1_labeled)
                        for j = 1:length(class2_labeled)
                            constraints_10.cl = [constraints_10.cl; class1_labeled(i), class2_labeled(j)];
                        end
                    end
                end
            end
        end
        
        fprintf('10%%标签分配: %d个样本 (%.1f%%)\n', length(labeled_indices), length(labeled_indices)/n_samples*100);
        fprintf('硬约束数量: %d个must-link, %d个cannot-link\n', size(constraints_10.ml,1), size(constraints_10.cl,1));
        
        % 运行10%硬约束半监督
        tic;
        params_sup10 = current_params;
        params_sup10.constraints_ml = constraints_10.ml;
        params_sup10.constraints_cl = constraints_10.cl;
        params_sup10.unsupRounds = 0;  % 跳过无监督阶段
        params_sup10.activeRounds = 6;    % ⚡ 批量版：6轮平衡优化
        params_sup10.enableHardConstraints = true;  % 直接用硬约束
        params_sup10.enableRepair = true;  % 启用修复
        params_sup10.patience = 8;  % 快速版：减少patience
        params_sup10.earlyStop = true;  % 启用早停
        params_sup10.lambda1 = 1.0;   % 🔥 最大ML约束权重（强制零违例）
        params_sup10.lambda2 = 1.0;   % 🔥 最大CL约束权重（强制零违例）
        params_sup10.combineMode = 'var_weight'; % 直接用最佳模式
        
        % 使用无监督结果作为初始状态
        optW = struct(); 
        optW.NeighborMode = 'KNN';
        optW.k = current_params.k;
        optW.WeightMode = 'HeatKernel';
        params_sup10.initial_A = full(constructW(res_unsup.final.Xe, optW));
        params_sup10.initial_G = res_unsup.final.G;
        params_sup10.initial_Y = res_unsup.final.Y;
        params_sup10.initial_Xe = res_unsup.final.Xe;
        
        % 传递基聚类器结果
        if isfield(res_unsup, 'BPsHist') && ~isempty(res_unsup.BPsHist)
            params_sup10.BPs = res_unsup.BPsHist{end};
        end
        
        res_sup10 = active_semisupervised_consensus_driver(data, params_sup10);
        Y_sup10 = res_sup10.final.Y(:);
        
        % 10%：强制修复到违规=0（增加修复轮数和强度）
        for repair_iter = 1:10  % 增加修复轮数
            [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
            if viol_ml == 0 && viol_cl == 0
                break;
            end
            Y_sup10 = repair_labels_with_constraints(Y_sup10, constraints_10, data, n_classes, 5);  % 增加修复强度
        end
        
        % 如果仍有违例，使用更强的修复策略
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
        if viol_ml > 0 || viol_cl > 0
            fprintf('警告：仍有违例，启用强制修复...\n');
            % 强制修复：直接根据约束重新分配标签
            for i = 1:size(constraints_10.ml, 1)
                idx1 = constraints_10.ml(i, 1);
                idx2 = constraints_10.ml(i, 2);
                if Y_sup10(idx1) ~= Y_sup10(idx2)
                    Y_sup10(idx2) = Y_sup10(idx1);  % 强制ML约束
                end
            end
            for i = 1:size(constraints_10.cl, 1)
                idx1 = constraints_10.cl(i, 1);
                idx2 = constraints_10.cl(i, 2);
                if Y_sup10(idx1) == Y_sup10(idx2)
                    % 找到最小的不同标签
                    available_labels = setdiff(1:n_classes, Y_sup10(idx1));
                    if ~isempty(available_labels)
                        Y_sup10(idx2) = available_labels(1);  % 强制CL约束
                    end
                end
            end
        end
        
        M_sup10 = metrics_eval(gt, Y_sup10);
        time_sup10 = toc;
        
        [viol10_ml, viol10_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
        fprintf('10%%硬约束半监督: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs) | 违规: ML=%d CL=%d\n', ...
            M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, viol10_ml, viol10_cl);
        
        % 检查层级性能要求
        hierarchy_ok = M_unsup.ACC < M_sup10.ACC;
        total_violations = viol10_ml + viol10_cl;
        
        if hierarchy_ok
            fprintf('层级要求: %s (无监督%.4f < 半监督%.4f)\n', ...
                string(hierarchy_ok), M_unsup.ACC, M_sup10.ACC);
        else
            fprintf('层级要求: %s (无监督%.4f >= 半监督%.4f)\n', ...
                string(hierarchy_ok), M_unsup.ACC, M_sup10.ACC);
        end
        fprintf('约束违例: %d个 (ML=%d, CL=%d)\n', total_violations, viol10_ml, viol10_cl);
        
        % 保存当前数据集结果
        current_result = struct();
        current_result.dataset = dataset_name;
        current_result.n_samples = n_samples;
        current_result.n_classes = n_classes;
        current_result.n_features = n_features;
        current_result.unsup_ACC = M_unsup.ACC;
        current_result.unsup_NMI = M_unsup.NMI;
        current_result.unsup_ARI = M_unsup.ARI;
        current_result.sup10_ACC = M_sup10.ACC;
        current_result.sup10_NMI = M_sup10.NMI;
        current_result.sup10_ARI = M_sup10.ARI;
        current_result.time_unsup = time_unsup;
        current_result.time_sup10 = time_sup10;
        current_result.total_time = time_unsup + time_sup10;
        current_result.violations_ML = viol10_ml;
        current_result.violations_CL = viol10_cl;
        current_result.total_violations = total_violations;
        current_result.hierarchy_ok = hierarchy_ok;
        current_result.n_constraints_ML = size(constraints_10.ml, 1);
        current_result.n_constraints_CL = size(constraints_10.cl, 1);
        
        % 添加到汇总结果
        results_summary = [results_summary; current_result];
        dataset_names{end+1} = dataset_name;
        
        % 绘制收敛性分析图
        try
            plot_convergence_analysis(res_unsup, res_sup10, dataset_name, result_dir);
        catch
            fprintf('警告: 收敛性图绘制失败\n');
        end
        
        fprintf('数据集 %s 完成，总用时 %.2f 分钟\n\n', dataset_name, (time_unsup + time_sup10)/60);
        
    catch ME
        fprintf('数据集 %s 处理失败: %s\n\n', dataset_name, ME.message);
        
        % 添加失败记录
        failed_result = struct();
        failed_result.dataset = dataset_name;
        failed_result.error = ME.message;
        failed_result.n_samples = NaN;
        failed_result.n_classes = NaN;
        failed_result.n_features = NaN;
        failed_result.unsup_ACC = NaN;
        failed_result.unsup_NMI = NaN;
        failed_result.unsup_ARI = NaN;
        failed_result.sup10_ACC = NaN;
        failed_result.sup10_NMI = NaN;
        failed_result.sup10_ARI = NaN;
        failed_result.time_unsup = NaN;
        failed_result.time_sup10 = NaN;
        failed_result.total_time = NaN;
        failed_result.violations_ML = NaN;
        failed_result.violations_CL = NaN;
        failed_result.total_violations = NaN;
        failed_result.hierarchy_ok = false;
        failed_result.n_constraints_ML = NaN;
        failed_result.n_constraints_CL = NaN;
        
        results_summary = [results_summary; failed_result];
        dataset_names{end+1} = dataset_name;
    end
end

%% 汇总输出所有结果
fprintf('\n=== 批量测试结果汇总 ===\n');
fprintf('测试完成时间: %s\n', datestr(now));
fprintf('总共处理数据集: %d个\n\n', length(results_summary));

% 创建汇总表格
fprintf('%-15s %-8s %-8s %-8s %-10s %-10s %-10s %-10s %-10s %-10s %-8s %-6s %-6s %-8s %-8s %-8s\n', ...
    'Dataset', 'Samples', 'Classes', 'Features', 'Unsup_ACC', 'Sup10_ACC', 'Unsup_NMI', 'Sup10_NMI', 'Unsup_ARI', 'Sup10_ARI', 'Time(min)', 'ML_Viol', 'CL_Viol', 'Total_Viol', 'Hierarchy', 'Constraints');
fprintf('%s\n', repmat('-', 1, 165));

total_time = 0;
successful_count = 0;
zero_violation_count = 0;
hierarchy_ok_count = 0;

for i = 1:length(results_summary)
    r = results_summary(i);
    if ~isnan(r.unsup_ACC)  % 成功的测试
        fprintf('%-15s %-8d %-8d %-8d %-10.4f %-10.4f %-10.4f %-10.4f %-10.4f %-10.4f %-8.2f %-6d %-6d %-8d %-8s %-8d\n', ...
            r.dataset, r.n_samples, r.n_classes, r.n_features, ...
            r.unsup_ACC, r.sup10_ACC, r.unsup_NMI, r.sup10_NMI, r.unsup_ARI, r.sup10_ARI, ...
            r.total_time/60, r.violations_ML, r.violations_CL, r.total_violations, string(r.hierarchy_ok), r.n_constraints_ML + r.n_constraints_CL);
        
        total_time = total_time + r.total_time;
        successful_count = successful_count + 1;
        if r.total_violations == 0
            zero_violation_count = zero_violation_count + 1;
        end
        if r.hierarchy_ok
            hierarchy_ok_count = hierarchy_ok_count + 1;
        end
    else  % 失败的测试
        fprintf('%-15s %-8s %-8s %-8s %-10s %-10s %-10s %-10s %-10s %-10s %-8s %-6s %-6s %-8s %-8s %-8s\n', ...
            r.dataset, 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED', 'FAILED');
    end
end

fprintf('\n=== 统计摘要 ===\n');
fprintf('成功测试数据集: %d/%d\n', successful_count, length(results_summary));
fprintf('零违例数据集: %d/%d (%.1f%%)\n', zero_violation_count, successful_count, zero_violation_count/successful_count*100);
fprintf('层级关系满足: %d/%d (%.1f%%)\n', hierarchy_ok_count, successful_count, hierarchy_ok_count/successful_count*100);
fprintf('总测试时间: %.2f 分钟 (平均每个数据集 %.2f 分钟)\n', total_time/60, total_time/60/successful_count);

% 计算平均性能
if successful_count > 0
    avg_unsup_ACC = mean([results_summary(~isnan([results_summary.unsup_ACC])).unsup_ACC]);
    avg_sup10_ACC = mean([results_summary(~isnan([results_summary.sup10_ACC])).sup10_ACC]);
    avg_unsup_NMI = mean([results_summary(~isnan([results_summary.unsup_NMI])).unsup_NMI]);
    avg_sup10_NMI = mean([results_summary(~isnan([results_summary.sup10_NMI])).sup10_NMI]);
    avg_unsup_ARI = mean([results_summary(~isnan([results_summary.unsup_ARI])).unsup_ARI]);
    avg_sup10_ARI = mean([results_summary(~isnan([results_summary.sup10_ARI])).sup10_ARI]);
    
    fprintf('\n=== 平均性能 ===\n');
    fprintf('无监督平均: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', avg_unsup_ACC, avg_unsup_NMI, avg_unsup_ARI);
    fprintf('10%%半监督平均: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', avg_sup10_ACC, avg_sup10_NMI, avg_sup10_ARI);
    fprintf('性能提升: ACC=+%.4f, NMI=+%.4f, ARI=+%.4f\n', ...
        avg_sup10_ACC - avg_unsup_ACC, avg_sup10_NMI - avg_unsup_NMI, avg_sup10_ARI - avg_unsup_ARI);
end

% 保存详细结果到MAT文件
results_file = fullfile(result_dir, 'batch_results_summary.mat');
save(results_file, 'results_summary', 'dataset_names', 'best_params');
fprintf('\n详细结果已保存到: %s\n', results_file);

% 保存CSV格式的汇总表格
csv_file = fullfile(result_dir, 'batch_results_summary.csv');
fid = fopen(csv_file, 'w');
if fid ~= -1
    fprintf(fid, 'Dataset,Samples,Classes,Features,Unsup_ACC,Sup10_ACC,Unsup_NMI,Sup10_NMI,Unsup_ARI,Sup10_ARI,Time_min,ML_Violations,CL_Violations,Total_Violations,Hierarchy_OK,Total_Constraints\n');
    for i = 1:length(results_summary)
        r = results_summary(i);
        if ~isnan(r.unsup_ACC)
            fprintf(fid, '%s,%d,%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.2f,%d,%d,%d,%s,%d\n', ...
                r.dataset, r.n_samples, r.n_classes, r.n_features, ...
                r.unsup_ACC, r.sup10_ACC, r.unsup_NMI, r.sup10_NMI, r.unsup_ARI, r.sup10_ARI, ...
                r.total_time/60, r.violations_ML, r.violations_CL, r.total_violations, string(r.hierarchy_ok), r.n_constraints_ML + r.n_constraints_CL);
        else
            fprintf(fid, '%s,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED,FAILED\n', r.dataset);
        end
    end
    fclose(fid);
    fprintf('CSV汇总表格已保存到: %s\n', csv_file);
end

%% 生成汇总收敛性对比图
fprintf('\n=== 生成汇总收敛性对比图 ===\n');
try
    plot_batch_convergence_summary(results_summary, result_dir);
catch ME
    fprintf('汇总收敛性图绘制失败: %s\n', ME.message);
end

fprintf('\n=== 批量测试完成 ===\n');
fprintf('所有结果文件保存在目录: %s\n', result_dir);
