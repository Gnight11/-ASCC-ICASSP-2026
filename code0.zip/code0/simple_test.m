% 简单测试SSE计算修复
clear; clc;

% 模拟数据
n = 401; c = 4;
DU = randn(n, c);  % 模拟谱嵌入结果
labels = randi(c, n, 1);  % 模拟标签

fprintf('测试SSE计算修复...\n');
fprintf('DU维度: %s\n', mat2str(size(DU)));
fprintf('labels范围: [%d, %d]\n', min(labels), max(labels));
fprintf('唯一标签: %s\n', mat2str(unique(labels)));

% 测试SSE计算
SSE = 0;
for i = 1:c
    % 使用find函数获取索引，避免逻辑索引问题
    cluster_idx = find(labels == i);
    if ~isempty(cluster_idx)
        cluster_points = DU(cluster_idx, :);  % 注意：这里应该是行索引，不是列索引
        % 直接计算聚类中心均值，避免维度不匹配
        cluster_center = mean(cluster_points, 1);  % 按行计算均值
        SSE = SSE + sum(sum((cluster_points - cluster_center).^2));
        fprintf('聚类%d: %d个点, SSE=%.2f\n', i, length(cluster_idx), sum(sum((cluster_points - cluster_center).^2)));
    end
end

fprintf('总SSE: %.2f\n', SSE);
fprintf('测试成功！\n');
