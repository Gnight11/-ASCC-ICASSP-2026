function [L,C] = kmeanspp(X,k)
%KMEANS Cluster multivariate data using the k-means++ algorithm.
%   [L,C] = kmeans(X,k) produces a 1-by-size(X,2) vector L with one class
%   label per column in X and a size(X,1)-by-k matrix C containing the
%   centers corresponding to each class.

%   Version: 2013-02-08 (修复版)
%   Authors: Laurent Sorber (Laurent.Sorber@cs.kuleuven.be)
%   Fixed by: Assistant

%   References:
%   [1] J. B. MacQueen, "Some Methods for Classification and Analysis of 
%       MultiVariate Observations", in Proc. of the fifth Berkeley
%       Symposium on Mathematical Statistics and Probability, L. M. L. Cam
%       and J. Neyman, eds., vol. 1, UC Press, 1967, pp. 281-297.
%   [2] D. Arthur and S. Vassilvitskii, "k-means++: The Advantages of
%       Careful Seeding", Technical Report 2006-13, Stanford InfoLab, 2006.

% 输入验证
if nargin < 2 || isempty(X) || isempty(k) || k <= 0
    error('Invalid input: X must be non-empty and k must be positive');
end

n = size(X,2);
if k > n
    error('k cannot be larger than the number of data points');
end

% 如果k=1，直接返回
if k == 1
    L = ones(1, n);
    C = mean(X, 2);
    return;
end

% 最大尝试次数，防止无限循环
max_attempts = 100;
attempt = 0;

while attempt < max_attempts
    attempt = attempt + 1;
    
    try
        % 改进的k-means++初始化
        used_indices = false(1, n);
        first_idx = randi(n);
        used_indices(first_idx) = true;
        C = X(:, first_idx);
        
        % 后续中心：k-means++（按到最近中心的距离平方作权）
        for i = 2:k
            % 计算每个点到最近已选中心的最小平方距离
            diffs = X - C(:,1); d2 = sum(diffs.^2, 1);
            for c_idx = 2:size(C,2)
                diffs = X - C(:,c_idx);
                d2 = min(d2, sum(diffs.^2, 1));
            end
            d2(used_indices) = 0;  % 已使用的不再选择
            s = sum(d2);
            if s <= 0
                % 所有点重合：随机补齐中心
                remaining = find(~used_indices);
                if numel(remaining) < (k - size(C,2))
                    break;
                end
                pick = remaining(randperm(numel(remaining), k - size(C,2)));
                C = [C, X(:, pick)]; %#ok<AGROW>
                used_indices(pick) = true;
                break;
            end
            probs = d2 / s;
            cdf = cumsum(probs);
            r = rand();
            next_idx = find(cdf >= r, 1, 'first');
            if isempty(next_idx)
                next_idx = find(~used_indices, 1, 'first');
            end
            if isempty(next_idx)
                break;
            end
            used_indices(next_idx) = true;
            C = [C, X(:, next_idx)]; %#ok<AGROW>
        end
        
        % 若中心数不足，重新尝试
        if size(C,2) < k
            continue;
        end
        
        % k-means迭代
        max_iter = 100;
        L = ones(1, n);
        for iter = 1:max_iter
            % 分配
            % 计算到各中心的距离平方矩阵（1xn 每次）
            % 使用增广法计算更快：对每个中心构造距离
            dists = zeros(k, n);
            for i = 1:k
                diffs = X - C(:,i);
                dists(i,:) = sum(diffs.^2, 1);
            end
            [~, L] = min(dists, [], 1);
            
            % 处理空簇：将最远样本回填到空簇
            counts = histcounts(L, 0.5:1:(k+0.5));
            empty_clusters = find(counts == 0);
            if ~isempty(empty_clusters)
                % 找到当前分配中距离其中心最远的样本（优先大的）
                [~, far_idx_order] = sort(dists(sub2ind([k, n], L, 1:n)), 'descend');
                ptr = 1;
                for ec = empty_clusters
                    while ptr <= n && ismember(L(far_idx_order(ptr)), empty_clusters)
                        ptr = ptr + 1; % 避免从空簇再拿
                    end
                    if ptr <= n
                        j = far_idx_order(ptr);
                        L(j) = ec;
                        ptr = ptr + 1;
                    end
                end
            end
            
            % 更新中心
            C_old = C;
            for i = 1:k
                idx = (L == i);
                if any(idx)
                    C(:,i) = mean(X(:, idx), 2);
                end
            end
            
            % 收敛检测
            if all(vecnorm(C - C_old) < 1e-8)
                break;
            end
        end
        
        % 确保输出含有恰好k个簇
        if numel(unique(L)) == k
            return;
        else
            % 再做一次空簇回填保护
            counts = histcounts(L, 0.5:1:(k+0.5));
            empty_clusters = find(counts == 0);
            if ~isempty(empty_clusters)
                % 从最大簇中搬移样本
                [~, largest_cluster] = max(counts);
                move_idx = find(L == largest_cluster, numel(empty_clusters), 'first');
                for t = 1:numel(empty_clusters)
                    L(move_idx(t)) = empty_clusters(t);
                end
            end
            if numel(unique(L)) == k
                return;
            end
        end
        
    catch
        % 忽略，进入下一次尝试
        continue;
    end
end

% 随机回退：保证每簇至少一个样本
L = ones(1, n);
perm = randperm(n);
L(1:k) = 1:k;  % 每簇至少一个
if n > k
    L(k+1:end) = randi(k, 1, n-k);
end
C = zeros(size(X,1), k);
for i = 1:k
    C(:,i) = mean(X(:, L==i), 2);
end
end
