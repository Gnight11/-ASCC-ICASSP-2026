function [A_tilde, A1, A2, lambda3_used, stats] = build_constraint_augmented_affinity(A, pairs_ml, pairs_cl, lambda1, lambda2, epsilon)
%==========================================================================
% FUNCTION:
%   [A_tilde, A1, A2, lambda3_used, stats] = build_constraint_augmented_affinity(...)
% DESCRIPTION:
%   Build hard-constraint augmented affinity matrix:
%       A~ = A + lambda1 * A1 - lambda2 * A2 + lambda3 * I,
%   where A1 encodes must-link pairs, A2 encodes cannot-link pairs. lambda3
%   is chosen to ensure positive-definiteness by shifting eigenvalues:
%       lambda3 = -lambda_min(A0) + epsilon,
%   with A0 = A + lambda1*A1 - lambda2*A2. epsilon > 0 is a small number.
%
% INPUTS:
%   A        : n x n symmetric affinity matrix (sparse allowed)
%   pairs_ml : K1 x 2 must-link pairs (1-based indices)
%   pairs_cl : K2 x 2 cannot-link pairs (1-based indices)
%   lambda1  : weight for must-link (default 1)
%   lambda2  : weight for cannot-link (default 1)
%   epsilon  : minimal positive shift (default 1e-6)
%
% OUTPUTS:
%   A_tilde      : n x n PSD affinity after eigenvalue shift
%   A1, A2       : constraint adjacency matrices
%   lambda3_used : scalar shift value applied
%   stats        : struct with fields {lambda_min, num_ml, num_cl}
%==========================================================================

    if nargin < 4 || isempty(lambda1), lambda1 = 1; end
    if nargin < 5 || isempty(lambda2), lambda2 = 1; end
    if nargin < 6 || isempty(epsilon), epsilon = 1e-6; end

    n = size(A,1);
    A = max(A, A');

    A1 = sparse(n,n);
    A2 = sparse(n,n);

    if ~isempty(pairs_ml)
        i = pairs_ml(:,1); j = pairs_ml(:,2);
        v = ones(size(i));
        A1 = A1 + sparse([i;j], [j;i], [v;v], n, n);
    end
    if ~isempty(pairs_cl)
        i = pairs_cl(:,1); j = pairs_cl(:,2);
        v = ones(size(i));
        A2 = A2 + sparse([i;j], [j;i], [v;v], n, n);
    end

    A0 = A + lambda1 * A1 - lambda2 * A2;

    % Estimate the smallest eigenvalue (use eigs with 'sa' for sparse)
    try
        lambda_min = eigs(A0, 1, 'sa');
    catch
        % Fall back to dense eig for small n
        ev = eig(full(A0));
        lambda_min = min(ev);
    end

    lambda3_used = 0;
    if lambda_min < 0
        lambda3_used = -lambda_min + epsilon;
    else
        lambda3_used = epsilon; % keep strictly PSD
    end

    A_tilde = A0 + lambda3_used * speye(n);

    stats = struct('lambda_min', full(lambda_min), 'num_ml', size(pairs_ml,1), 'num_cl', size(pairs_cl,1));

end


