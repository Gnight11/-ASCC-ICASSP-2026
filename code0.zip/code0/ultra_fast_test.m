%% 超稳定快速测试版 - 防止闪退
% 添加错误处理，减少内存使用
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 超稳定快速测试 (防闪退版) ===\n');

try
    % 加载数据
    fprintf('正在加载数据...\n');
    [data, gt] = load_timeseries_mat(fullfile('..','data','II_Ia_Ib_data.mat'));
    n_samples = length(gt);
    n_classes = length(unique(gt));
    fprintf('数据加载成功: %d样本, %d类别\n', n_samples, n_classes);
    
    % 超保守参数 - 防止内存溢出
    rng(97);
    params = struct();
    params.k = 5;                    % 🔧 超保守近邻数
    params.T = 15;                   % 🔧 超保守扩散步数
    params.snnWeight = 0.05;         % 🔧 超保守权重
    params.gamma = 1.5;              % 🔧 超保守gamma
    params.r = 50;                   % 🔧 超保守基聚类器
    params.c = 4;
    params.maxRounds = 5;            % ⚡ 超快版：仅5轮
    params.earlyStop = true;         % 启用早停
    params.patience = 3;             % 🔧 快速早停
    
catch ME
    fprintf('❌ 初始化失败: %s\n', ME.message);
    exit;
end

fprintf('保守参数: k=%d, T=%d, gamma=%.1f, 轮数=%d\n', params.k, params.T, params.gamma, params.maxRounds);

%% 1. 无监督聚类 - 添加错误处理
fprintf('\n--- 无监督聚类 (5轮) ---\n');
try
    fprintf('开始无监督聚类...\n');
    tic;
    res_unsup = unsupervised_consensus_driver(data, params);
    
    if isempty(res_unsup) || ~isfield(res_unsup, 'final') || isempty(res_unsup.final)
        error('无监督聚类返回空结果');
    end
    
    Y_unsup = res_unsup.final.Y(:);
    M_unsup = metrics_eval(gt, Y_unsup);
    time_unsup = toc;
    fprintf('✅ 无监督: ACC=%.4f, NMI=%.4f, ARI=%.4f (%.1fs)\n', M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
    
    % 清理内存
    if isfield(res_unsup, 'BPsHist')
        fprintf('保留基聚类器结果，清理其他数据...\n');
    end
    
catch ME
    fprintf('❌ 无监督聚类失败: %s\n', ME.message);
    fprintf('尝试简化参数重试...\n');
    
    % 极简参数重试
    simple_params = params;
    simple_params.r = 20;  % 极少基聚类器
    simple_params.maxRounds = 3;  % 极少轮数
    simple_params.k = 3;   % 极少近邻
    
    try
        res_unsup = unsupervised_consensus_driver(data, simple_params);
        Y_unsup = res_unsup.final.Y(:);
        M_unsup = metrics_eval(gt, Y_unsup);
        time_unsup = toc;
        fprintf('✅ 简化无监督: ACC=%.4f, NMI=%.4f, ARI=%.4f (%.1fs)\n', M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
    catch ME2
        fprintf('❌ 简化无监督也失败: %s\n', ME2.message);
        fprintf('退出测试\n');
        exit;
    end
end

%% 2. 10%半监督聚类 - 超简化版本
fprintf('\n--- 10%%半监督聚类 (5轮) ---\n');

try
    % 极简标签采样
    fprintf('生成标签样本...\n');
    labeled_indices = [];
    for c = 1:n_classes
        class_indices = find(gt == c);
        n_class_labeled = max(1, min(5, round(length(class_indices) * 0.1))); % 每类最多5个
        if length(class_indices) >= n_class_labeled
            class_labeled = randsample(class_indices, n_class_labeled);
            labeled_indices = [labeled_indices; class_labeled(:)];
        end
    end
    fprintf('标签样本数: %d\n', length(labeled_indices));
    
    % 极简约束生成 - 减少约束数量防止内存问题
    constraints = struct();
    constraints.ml = [];
    constraints.cl = [];
    
    % 每类内最多1个ML约束
    for c = 1:n_classes
        class_labeled = labeled_indices(gt(labeled_indices) == c);
        if length(class_labeled) >= 2
            % 只连接前两个
            constraints.ml = [constraints.ml; class_labeled(1), class_labeled(2)];
        end
    end
    
    % 类间最多1个CL约束
    for c1 = 1:n_classes
        for c2 = c1+1:n_classes
            class1_labeled = labeled_indices(gt(labeled_indices) == c1);
            class2_labeled = labeled_indices(gt(labeled_indices) == c2);
            if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                % 只连接第一对
                constraints.cl = [constraints.cl; class1_labeled(1), class2_labeled(1)];
            end
        end
    end
    
    fprintf('约束: %d个ML, %d个CL\n', size(constraints.ml,1), size(constraints.cl,1));
    
    if size(constraints.ml,1) + size(constraints.cl,1) > 20
        fprintf('⚠️ 约束过多，可能导致内存问题，减少约束...\n');
        % 强制减少约束
        constraints.ml = constraints.ml(1:min(end, 5), :);
        constraints.cl = constraints.cl(1:min(end, 10), :);
        fprintf('简化后约束: %d个ML, %d个CL\n', size(constraints.ml,1), size(constraints.cl,1));
    end
    
catch ME
    fprintf('❌ 约束生成失败: %s\n', ME.message);
    % 使用空约束
    constraints = struct();
    constraints.ml = [];
    constraints.cl = [];
    fprintf('使用空约束继续测试\n');
end

% 运行10%半监督 - 超保守版本
try
    fprintf('开始半监督聚类...\n');
    tic;
    
    % 超保守半监督参数
    params_sup = params;
    params_sup.constraints_ml = constraints.ml;
    params_sup.constraints_cl = constraints.cl;
    params_sup.unsupRounds = 0;
    params_sup.activeRounds = 3;     % ⚡ 超快版：仅3轮
    params_sup.enableHardConstraints = true;
    params_sup.enableRepair = true;
    params_sup.patience = 2;         % 🔧 超快早停
    params_sup.lambda1 = 0.2;        % 🔧 降低约束权重
    params_sup.lambda2 = 0.2;
    params_sup.combineMode = 'var_weight';
    params_sup.maxRounds = 3;        % 🔧 强制最大轮数
    
    % 安全的初始化
    if exist('res_unsup', 'var') && ~isempty(res_unsup) && isfield(res_unsup, 'final')
        fprintf('使用无监督结果初始化...\n');
        try
            optW = struct(); 
            optW.NeighborMode = 'KNN';
            optW.k = params.k;
            optW.WeightMode = 'HeatKernel';
            params_sup.initial_A = full(constructW(res_unsup.final.Xe, optW));
            params_sup.initial_G = res_unsup.final.G;
            params_sup.initial_Y = res_unsup.final.Y;
            params_sup.initial_Xe = res_unsup.final.Xe;
            if isfield(res_unsup, 'BPsHist') && ~isempty(res_unsup.BPsHist)
                params_sup.BPs = res_unsup.BPsHist{end};
            end
            fprintf('初始化成功\n');
        catch
            fprintf('⚠️ 初始化失败，使用默认设置\n');
        end
    end
    
    % 执行半监督聚类
    res_sup = active_semisupervised_consensus_driver(data, params_sup);
    
    if isempty(res_sup) || ~isfield(res_sup, 'final') || isempty(res_sup.final)
        error('半监督聚类返回空结果');
    end
    
    Y_sup = res_sup.final.Y(:);
    
    % 简化违规修复
    if ~isempty(constraints.ml) || ~isempty(constraints.cl)
        fprintf('检查约束违规...\n');
        for repair_iter = 1:2  % 最多2次修复
            [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup, constraints.ml, constraints.cl);
            if viol_ml == 0 && viol_cl == 0
                break;
            end
            try
                Y_sup = repair_labels_with_constraints(Y_sup, constraints, data, n_classes, 2);
            catch
                fprintf('⚠️ 违规修复失败，跳过\n');
                break;
            end
        end
    end
    
    M_sup = metrics_eval(gt, Y_sup);
    time_sup = toc;
    
    [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup, constraints.ml, constraints.cl);
    fprintf('✅ 10%%半监督: ACC=%.4f, NMI=%.4f, ARI=%.4f (%.1fs)\n', M_sup.ACC, M_sup.NMI, M_sup.ARI, time_sup);
    fprintf('🚨 违规检查: ML=%d, CL=%d\n', viol_ml, viol_cl);
    
catch ME
    fprintf('❌ 半监督聚类失败: %s\n', ME.message);
    % 使用无监督结果作为半监督结果
    fprintf('使用无监督结果作为半监督结果\n');
    Y_sup = Y_unsup;
    M_sup = M_unsup;
    time_sup = 0;
    viol_ml = 999;
    viol_cl = 999;
end

%% 3. 结果总结 - 安全输出
fprintf('\n=== 超稳定测试结果总结 ===\n');

try
    % 安全地显示结果
    fprintf('%-18s %-8s %-8s %-8s %-8s %-10s\n', '方法', 'ACC', 'NMI', 'ARI', '时间(s)', '违规');
    fprintf('----------------------------------------------------------------\n');
    
    % 检查变量是否存在
    if exist('M_unsup', 'var') && isfield(M_unsup, 'ACC')
        fprintf('%-18s %-8.4f %-8.4f %-8.4f %-8.1f %-10s\n', '无监督', ...
            M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup, 'N/A');
    else
        fprintf('%-18s %-8s %-8s %-8s %-8s %-10s\n', '无监督', '失败', '--', '--', '--', 'N/A');
    end
    
    if exist('M_sup', 'var') && isfield(M_sup, 'ACC')
        fprintf('%-18s %-8.4f %-8.4f %-8.4f %-8.1f %-10s\n', '10%硬约束半监督', ...
            M_sup.ACC, M_sup.NMI, M_sup.ARI, time_sup, sprintf('ML:%d CL:%d', viol_ml, viol_cl));
        
        % 层级关系检查
        if exist('M_unsup', 'var') && isfield(M_unsup, 'ACC')
            if M_unsup.ACC < M_sup.ACC
                fprintf('\n✅ 层级关系满足: 无监督(%.4f) < 10%%半监督(%.4f)\n', M_unsup.ACC, M_sup.ACC);
            else
                fprintf('\n❌ 层级关系不满足: 无监督(%.4f) >= 10%%半监督(%.4f)\n', M_unsup.ACC, M_sup.ACC);
            end
        end
    else
        fprintf('%-18s %-8s %-8s %-8s %-8s %-10s\n', '10%硬约束半监督', '失败', '--', '--', '--', 'ML:? CL:?');
    end
    
    % 总时间计算
    total_time = 0;
    if exist('time_unsup', 'var'), total_time = total_time + time_unsup; end
    if exist('time_sup', 'var'), total_time = total_time + time_sup; end
    
    fprintf('\n总用时: %.1f分钟\n', total_time/60);
    fprintf('🎉 超稳定测试完成！\n');
    
    % 清理内存
    fprintf('\n正在清理内存...\n');
    clear res_unsup res_sup data;
    
catch ME
    fprintf('❌ 结果输出失败: %s\n', ME.message);
    fprintf('测试可能部分完成\n');
end

fprintf('安全退出\n');
exit;
