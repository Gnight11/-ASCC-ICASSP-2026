function [pairs_ml, pairs_cl, idxL] = sample_pairs_nested(gt, ratio, seed, idx10)
%SAMPLE_PAIRS_NESTED Sample labeled subset and balanced ML/CL pairs; nested at 20%.
%   gt: N x 1 ground truth labels
%   ratio: 0.10 or 0.20
%   seed: rng seed
%   idx10: previously selected indices at 10% (for nesting), [] for first call

    if nargin < 4, idx10 = []; end
    rng(seed, 'twister');
    gt = gt(:);
    N = numel(gt);
    k = numel(unique(gt));

    % labeled indices per class
    per_class = max(1, round(ratio * N / k));
    idxL = [];
    classes = unique(gt)';
    for c = classes
        idxc = find(gt == c);
        if ratio > 0.10 && ~isempty(idx10)
            idxc10 = intersect(idx10, idxc);
        else
            idxc10 = [];
        end
        need = per_class - numel(idxc10);
        need = max(0, need);
        rest = setdiff(idxc, idxc10);
        pick = rest(randperm(numel(rest), min(need, numel(rest))));
        idxL = [idxL; idxc10(:); pick(:)]; %#ok<AGROW>
    end
    idxL = unique(idxL);

    % build ML/CL pairs with limits
    max_pairs = max(10, round(2 * numel(idxL))); % simple heuristic
    pairs_ml = [];
    pairs_cl = [];
    L = numel(idxL);
    tries = 0;
    while (size(pairs_ml,1) < max_pairs || size(pairs_cl,1) < max_pairs) && tries < 20000
        tries = tries + 1;
        i = idxL(randi(L)); j = idxL(randi(L));
        if i == j, continue; end
        if gt(i) == gt(j)
            if size(pairs_ml,1) < max_pairs
                pairs_ml = [pairs_ml; i, j]; %#ok<AGROW>
            end
        else
            if size(pairs_cl,1) < max_pairs
                pairs_cl = [pairs_cl; i, j]; %#ok<AGROW>
            end
        end
    end
end

















