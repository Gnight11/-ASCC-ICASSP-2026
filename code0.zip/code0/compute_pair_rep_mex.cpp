// compute_pair_rep_mex.cpp
// Compile with: mex -O compute_pair_rep_mex.cpp
// INPUTS:
//   Astar : n x n double (full or sparse) diffused similarity
//   pairs : K x 2 int32/double indices (1-based)
//   diagA : optional n x 1 double diag(Astar*Astar') for normalization
// OUTPUTS:
//   scores : K x 1 double, if diagA provided returns normalized score

#include "mex.h"
#include <vector>

static inline mwIndex as_index(double v){ return (mwIndex)(v - 1.0); }

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs < 2) {
        mexErrMsgIdAndTxt("rep_mex:args", "Need Astar and pairs.");
    }
    const mxArray* A = prhs[0];
    const mxArray* P = prhs[1];
    const bool hasDiag = (nrhs >= 3 && !mxIsEmpty(prhs[2]));

    const mwSize n = mxGetM(A);
    const bool isSparse = mxIsSparse(A);

    if (mxGetM(P) < 1 || mxGetN(P) != 2)
        mexErrMsgIdAndTxt("rep_mex:pairs", "pairs must be Kx2.");
    const mwSize K = mxGetM(P);

    plhs[0] = mxCreateDoubleMatrix(K, 1, mxREAL);
    double* out = mxGetPr(plhs[0]);

    const double* diagA = nullptr;
    if (hasDiag) diagA = mxGetPr(prhs[2]);

    const double* Apr = mxGetPr(A);
    const mwIndex* Air = mxGetIr(A);
    const mwIndex* Ajc = mxGetJc(A);

    const double* Ppr = mxGetPr(P);

    // Helper: compute dot of two rows of Astar
    auto rowdot = [&](mwIndex i, mwIndex j) -> double {
        if (!isSparse){
            const double* ri = Apr + i; // column-major
            const double* rj = Apr + j;
            double s = 0.0;
            for (mwIndex c=0; c<n; ++c){ s += ri[c*n]*rj[c*n]; }
            return s;
        } else {
            // access as columns; dot rows => we iterate columns and sum A(ci,i)*A(cj,j)
            double s = 0.0;
            for (mwIndex col=0; col<n; ++col){
                mwIndex start = Ajc[col];
                mwIndex end   = Ajc[col+1];
                double vi = 0.0, vj = 0.0;
                for (mwIndex p=start; p<end; ++p){
                    if (Air[p]==i) vi = Apr[p];
                    if (Air[p]==j) vj = Apr[p];
                }
                s += vi * vj;
            }
            return s;
        }
    };

    for (mwIndex k=0; k<K; ++k){
        mwIndex i = as_index(Ppr[k]);
        mwIndex j = as_index(Ppr[k + K]);
        if (i>=n || j>=n) mexErrMsgIdAndTxt("rep_mex:idx", "pair index out of range");
        double s = rowdot(i, j);
        if (hasDiag){
            double di = diagA[i];
            double dj = diagA[j];
            double denom = sqrt(di)*sqrt(dj);
            if (denom>0) s /= denom; else s = 0.0;
        }
        out[k] = s;
    }
}


