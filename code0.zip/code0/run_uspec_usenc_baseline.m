function run_uspec_usenc_baseline()
%% Run USPEC and USENC as baseline methods on EEG datasets
% This script tests both USPEC and USENC methods on the same datasets
% used for the main ASCC method comparison

clear all;
close all;

% Add USPEC-USENC path
addpath('d:\Desktop\paper\Active clustering\USPEC-USENC-TKDE-2020-Huang\USPEC_USENC-master');

%% Dataset configuration
datasets = {
    'II_Ia_data.mat', 'data', 'labels';
    'II_Ib_data.mat', 'data', 'labels'; 
    'III_V_s2_data.mat', 'data', 'labels';
    'IV_2b_s1_data.mat', 'data', 'labels';
    'IV_2b_s2_data.mat', 'data', 'labels'
};

data_path = 'd:\Desktop\paper\Active clustering\data\';

%% Initialize results storage
summary_results = {};
summary_header = {'Dataset', 'N_samples', 'N_features', 'N_clusters', ...
                  'USPEC_NMI', 'USPEC_Acc', 'USPEC_Time', ...
                  'USENC_NMI', 'USENC_Acc', 'USENC_Time'};

fprintf('\n=== USPEC-USENC Baseline Testing ===\n');
fprintf('Testing on %d EEG datasets\n\n', length(datasets));

%% Process each dataset
for d = 1:length(datasets)
    dataset_file = datasets{d, 1};
    data_field = datasets{d, 2};
    label_field = datasets{d, 3};
    
    fprintf('Processing dataset %d/%d: %s\n', d, length(datasets), dataset_file);
    
    try
        % Load dataset
        full_path = fullfile(data_path, dataset_file);
        if ~exist(full_path, 'file')
            fprintf('  ERROR: Dataset file not found: %s\n', full_path);
            continue;
        end
        
        load(full_path);
        
        % Extract data and labels
        if exist(data_field, 'var') && exist(label_field, 'var')
            eval(['data_matrix = ' data_field ';']);
            eval(['true_labels = ' label_field ';']);
        else
            fprintf('  ERROR: Required fields not found in %s\n', dataset_file);
            continue;
        end
        
        % Basic dataset info
        [N, d_feat] = size(data_matrix);
        k = length(unique(true_labels));
        
        fprintf('  Dataset info: N=%d, d=%d, k=%d\n', N, d_feat, k);
        
        % Normalize data
        data_norm = normalize(data_matrix, 'range');
        
        %% Test USPEC
        fprintf('  Running USPEC...\n');
        tic;
        try
            % Use default parameters: p=1000, KNN=5, distance='euclidean'
            p = min(1000, N); % Adjust p if dataset is small
            uspec_labels = USPEC(data_norm, k, 'euclidean', p, 5);
            uspec_time = toc;
            
            % Compute metrics
            uspec_nmi = computeNMI(uspec_labels, true_labels);
            uspec_acc = compute_clustering_accuracy(uspec_labels, true_labels);
            
            fprintf('    USPEC - NMI: %.4f, Acc: %.4f, Time: %.2fs\n', ...
                    uspec_nmi, uspec_acc, uspec_time);
        catch ME
            fprintf('    USPEC failed: %s\n', ME.message);
            uspec_nmi = 0; uspec_acc = 0; uspec_time = 0;
        end
        
        %% Test USENC
        fprintf('  Running USENC...\n');
        tic;
        try
            % Use default parameters: m=20 (ensemble size)
            m = 20;
            usenc_labels = USENC(data_norm, k, m);
            usenc_time = toc;
            
            % Compute metrics
            usenc_nmi = computeNMI(usenc_labels, true_labels);
            usenc_acc = compute_clustering_accuracy(usenc_labels, true_labels);
            
            fprintf('    USENC - NMI: %.4f, Acc: %.4f, Time: %.2fs\n', ...
                    usenc_nmi, usenc_acc, usenc_time);
        catch ME
            fprintf('    USENC failed: %s\n', ME.message);
            usenc_nmi = 0; usenc_acc = 0; usenc_time = 0;
        end
        
        % Store results
        summary_results{end+1, 1} = dataset_file;
        summary_results{end, 2} = N;
        summary_results{end, 3} = d_feat;
        summary_results{end, 4} = k;
        summary_results{end, 5} = uspec_nmi;
        summary_results{end, 6} = uspec_acc;
        summary_results{end, 7} = uspec_time;
        summary_results{end, 8} = usenc_nmi;
        summary_results{end, 9} = usenc_acc;
        summary_results{end, 10} = usenc_time;
        
        fprintf('  Dataset %s completed.\n\n', dataset_file);
        
    catch ME
        fprintf('  ERROR processing %s: %s\n\n', dataset_file, ME.message);
        % Add error entry to results
        summary_results{end+1, 1} = dataset_file;
        for col = 2:10
            summary_results{end, col} = NaN;
        end
    end
end

%% Display and save results
fprintf('\n=== USPEC-USENC Baseline Results Summary ===\n');
fprintf('%-20s %8s %8s %8s %10s %10s %10s %10s %10s %10s\n', summary_header{:});
fprintf(repmat('-', 1, 120));
fprintf('\n');

for i = 1:size(summary_results, 1)
    fprintf('%-20s %8d %8d %8d %10.4f %10.4f %10.2f %10.4f %10.4f %10.2f\n', ...
            summary_results{i, :});
end

% Calculate averages (excluding NaN/error entries)
valid_rows = ~any(cellfun(@(x) isnan(x) || x == 0, summary_results(:, 5:10)), 2);
if sum(valid_rows) > 0
    avg_uspec_nmi = mean([summary_results{valid_rows, 5}]);
    avg_uspec_acc = mean([summary_results{valid_rows, 6}]);
    avg_uspec_time = mean([summary_results{valid_rows, 7}]);
    avg_usenc_nmi = mean([summary_results{valid_rows, 8}]);
    avg_usenc_acc = mean([summary_results{valid_rows, 9}]);
    avg_usenc_time = mean([summary_results{valid_rows, 10}]);
    
    fprintf(repmat('-', 1, 120));
    fprintf('\n');
    fprintf('%-20s %8s %8s %8s %10.4f %10.4f %10.2f %10.4f %10.4f %10.2f\n', ...
            'AVERAGE', '-', '-', '-', avg_uspec_nmi, avg_uspec_acc, avg_uspec_time, ...
            avg_usenc_nmi, avg_usenc_acc, avg_usenc_time);
end

%% Save results
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
results_dir = 'uspec_usenc_results';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% Save detailed results
save_file = fullfile(results_dir, ['USPEC_USENC_results_' timestamp '.mat']);
save(save_file, 'summary_results', 'summary_header');

% Save summary CSV
csv_file = fullfile(results_dir, ['USPEC_USENC_summary_' timestamp '.csv']);
write_results_to_csv(csv_file, summary_header, summary_results);

fprintf('\nResults saved to:\n');
fprintf('  MAT file: %s\n', save_file);
fprintf('  CSV file: %s\n', csv_file);
fprintf('\n=== USPEC-USENC Baseline Testing Completed ===\n');

end

function accuracy = compute_clustering_accuracy(pred_labels, true_labels)
%% Compute clustering accuracy using Hungarian algorithm
% Similar to the compute_acc_fixed function but simplified

try
    % Get unique labels
    true_unique = unique(true_labels);
    pred_unique = unique(pred_labels);
    
    n_true = length(true_unique);
    n_pred = length(pred_unique);
    
    % Create confusion matrix
    confusion_matrix = zeros(n_true, n_pred);
    for i = 1:n_true
        for j = 1:n_pred
            confusion_matrix(i, j) = sum(true_labels == true_unique(i) & pred_labels == pred_unique(j));
        end
    end
    
    % Use Hungarian algorithm (simplified greedy approach)
    max_accuracy = 0;
    if n_true <= n_pred
        % Try all permutations for small cases, greedy for large cases
        if n_true <= 8
            perms = perms(1:n_pred);
            for p = 1:size(perms, 1)
                perm = perms(p, 1:n_true);
                acc = sum(diag(confusion_matrix(:, perm))) / length(true_labels);
                max_accuracy = max(max_accuracy, acc);
            end
        else
            % Greedy assignment
            remaining_pred = 1:n_pred;
            total_correct = 0;
            for i = 1:n_true
                [~, best_j_idx] = max(confusion_matrix(i, remaining_pred));
                best_j = remaining_pred(best_j_idx);
                total_correct = total_correct + confusion_matrix(i, best_j);
                remaining_pred(best_j_idx) = [];
            end
            max_accuracy = total_correct / length(true_labels);
        end
    else
        % More predicted clusters than true clusters
        % Greedy assignment
        remaining_true = 1:n_true;
        total_correct = 0;
        for j = 1:n_pred
            if isempty(remaining_true)
                break;
            end
            [~, best_i_idx] = max(confusion_matrix(remaining_true, j));
            best_i = remaining_true(best_i_idx);
            total_correct = total_correct + confusion_matrix(best_i, j);
            remaining_true(best_i_idx) = [];
        end
        max_accuracy = total_correct / length(true_labels);
    end
    
    accuracy = max_accuracy;
    
catch ME
    fprintf('Warning: Accuracy computation failed: %s\n', ME.message);
    accuracy = 0;
end

end

function write_results_to_csv(filename, header, data)
%% Write results to CSV file

try
    fid = fopen(filename, 'w');
    
    % Write header
    fprintf(fid, '%s', header{1});
    for i = 2:length(header)
        fprintf(fid, ',%s', header{i});
    end
    fprintf(fid, '\n');
    
    % Write data
    for i = 1:size(data, 1)
        fprintf(fid, '%s', data{i, 1});
        for j = 2:size(data, 2)
            if isnan(data{i, j})
                fprintf(fid, ',NaN');
            elseif ischar(data{i, j})
                fprintf(fid, ',%s', data{i, j});
            else
                fprintf(fid, ',%.4f', data{i, j});
            end
        end
        fprintf(fid, '\n');
    end
    
    fclose(fid);
    
catch ME
    fprintf('Warning: Failed to write CSV file: %s\n', ME.message);
end

end
