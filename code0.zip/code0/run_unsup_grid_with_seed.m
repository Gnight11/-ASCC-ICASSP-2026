% RUN UNSUP GRID WITH SEED: 遍历 k/T/snnWeight/gamma，评估无监督ACC/NMI/ARI并输出最佳
% 记录每次运行时的随机种子，找到最佳参数组合
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

% 数据
[data, gt] = load_timeseries_mat(fullfile('..','data','II_Ia_Ib_data.mat'));

% 固定项 - 不设置固定种子，让MATLAB使用默认随机行为
baseParams = struct('r',200,'K',4,'c',4,'maxRounds',1, ...
                    'distance','cosine','mutual',true,'pcaDim',150, ...
                    'KiMode',0);

% 网格
k_list = [30 40 50 60];
T_list = [8 10 12 15];
snn_list = [0 0.3 0.5 0.6];
gamma_list = [1 1.2 1.5 1.8 2.0];

% 结果存储
results = [];
best = struct('ACC',-inf,'NMI',-inf,'ARI',-inf,'params',[],'seed',[]);

% 检查是否有中断文件
interrupt_file = 'grid_search_with_seed_interrupt.mat';
if exist(interrupt_file, 'file')
    fprintf('发现中断文件，正在恢复...\n');
    load(interrupt_file);
    fprintf('已恢复 %d 个结果\n', length(results));
end

fprintf('=== 无监督参数网格搜索（记录种子）开始 ===\n');
total_combinations = length(k_list) * length(T_list) * length(snn_list) * length(gamma_list);
current_count = length(results) + 1;

for k = k_list
    for T = T_list
        for snnw = snn_list
            for gamma = gamma_list
                % 检查是否已经计算过
                if ~isempty(results) && any(cellfun(@(r) r.k == k && r.T == T && r.snnWeight == snnw && r.gamma == gamma, results))
                    fprintf('跳过已计算：k=%d T=%d snn=%.2f gamma=%.1f\n', k, T, snnw, gamma);
                    continue;
                end
                
                fprintf('进度: %d/%d - 计算: k=%d T=%d snn=%.2f gamma=%.1f\n', ...
                    current_count, total_combinations, k, T, snnw, gamma);
                
                % 设置随机种子并记录状态
                seed_value = randi([1, 1000]);  % 随机生成1-1000的种子
                rng(seed_value);
                current_seed = rng;
                
                params = baseParams;
                params.k = k; params.T = T;
                params.snnWeight = snnw; params.gamma = gamma;
                
                try
                    tic;
                    res = unsupervised_consensus_driver(data, params);
                    Y = res.final.Y(:);
                    M = metrics_eval(gt, Y);
                    elapsed_time = toc;
                    
                    % 保存结果（包含种子信息）
                    result = struct('k', k, 'T', T, 'snnWeight', snnw, 'gamma', gamma, ...
                                  'ACC', M.ACC, 'NMI', M.NMI, 'ARI', M.ARI, ...
                                  'elapsed_time', elapsed_time, 'timestamp', datestr(now), ...
                                  'seed', current_seed);
                    results{end+1} = result;
                    
                    fprintf('完成: k=%d T=%d snn=%.2f gamma=%.1f => ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
                        k, T, snnw, gamma, M.ACC, M.NMI, M.ARI, elapsed_time);
                    
                    % 更新最佳结果 - 按ACC排序（主要指标）
                    if any(isinf([best.ACC, best.NMI, best.ARI])) || M.ACC > best.ACC
                        best.ACC = M.ACC; best.NMI = M.NMI; best.ARI = M.ARI;
                        best.params = params;
                        best.seed = current_seed;
                        fprintf('*** 新的最佳结果！ ***\n');
                        fprintf('*** 最佳种子: %s ***\n', mat2str(current_seed.Seed));
                    end
                    
                    % 每完成一组就保存中断文件
                    save(interrupt_file, 'results', 'best', 'k_list', 'T_list', 'snn_list', 'gamma_list');
                    
                catch ME
                    fprintf('失败：k=%d T=%d snn=%.2f gamma=%.1f 错误: %s\n', k, T, snnw, gamma, ME.message);
                    % 即使失败也保存进度
                    save(interrupt_file, 'results', 'best', 'k_list', 'T_list', 'snn_list', 'gamma_list');
                end
                
                current_count = current_count + 1;
            end
        end
    end
end

% 删除中断文件
if exist(interrupt_file, 'file')
    delete(interrupt_file);
    fprintf('已删除中断文件\n');
end

% 输出最终结果
if ~isempty(best.params)
    p = best.params;
    fprintf('\n=== 最佳参数 ===\n');
    fprintf('k=%d, T=%d, snnWeight=%.2f, gamma=%.1f | ACC=%.4f NMI=%.4f ARI=%.4f\n', ...
        p.k, p.T, p.snnWeight, p.gamma, best.ACC, best.NMI, best.ARI);
    fprintf('最佳种子: %s\n', mat2str(best.seed.Seed));
else
    fprintf('\n未找到有效结果。\n');
end

% 保存完整结果到mat文件
save('grid_search_with_seed_results.mat', 'results', 'best', 'data', 'gt');

% 输出txt报告
fid = fopen('grid_search_with_seed_report.txt', 'w');
fprintf(fid, '=== 无监督聚类参数网格搜索结果报告（含种子） ===\n');
fprintf(fid, '生成时间: %s\n\n', datestr(now));

fprintf(fid, '参数网格:\n');
fprintf(fid, 'k: %s\n', mat2str(k_list));
fprintf(fid, 'T: %s\n', mat2str(T_list));
fprintf(fid, 'snnWeight: %s\n', mat2str(snn_list));
fprintf(fid, 'gamma: %s\n\n', mat2str(gamma_list));

fprintf(fid, '最佳参数:\n');
if ~isempty(best.params)
    p = best.params;
    fprintf(fid, 'k=%d, T=%d, snnWeight=%.2f, gamma=%.1f\n', p.k, p.T, p.snnWeight, p.gamma);
    fprintf(fid, 'ACC=%.4f, NMI=%.4f, ARI=%.4f\n', best.ACC, best.NMI, best.ARI);
    fprintf(fid, '最佳种子: %s\n\n', mat2str(best.seed.Seed));
end

fprintf(fid, '所有结果:\n');
fprintf(fid, '%-8s %-8s %-12s %-8s %-12s %-12s %-12s %-15s %-15s\n', ...
    'k', 'T', 'snnWeight', 'gamma', 'ACC', 'NMI', 'ARI', '用时(s)', '种子');
fprintf(fid, '%s\n', repmat('-', 1, 120));

for i = 1:length(results)
    r = results{i};
    fprintf(fid, '%-8d %-8d %-12.2f %-8.1f %-12.4f %-12.4f %-12.4f %-15.2f %-15s\n', ...
        r.k, r.T, r.snnWeight, r.gamma, r.ACC, r.NMI, r.ARI, r.elapsed_time, mat2str(r.seed.Seed));
end

fprintf(fid, '\n=== 报告结束 ===\n');
fclose(fid);

fprintf('\n=== 网格搜索（含种子）结束 ===\n');
fprintf('结果已保存到: grid_search_with_seed_results.mat\n');
fprintf('报告已保存到: grid_search_with_seed_report.txt\n');
