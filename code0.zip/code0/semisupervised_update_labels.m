function [Y_new, info] = semisupervised_update_labels(A_tilde, G, Y_init, pairs_ml, pairs_cl)
%==========================================================================
% FUNCTION:
%   [Y_new, info] = semisupervised_update_labels(A_tilde, G, Y_init, pairs_ml, pairs_cl)
% DESCRIPTION:
%   Update labels Y under hard must-link / cannot-link constraints with
%   three cases as in the spec. We compute Q = G' * A_tilde, and assign
%   labels based on different rules:
%     1) Free sample: Δ(i,r) = Q_{r,i} / sqrt(n_r + 1), choose argmax_r
%     2) Only must-link or only cannot-link for sample i:
%        - must-link only: merge its must-link set as a pseudo-cluster C,
%          score Δ(C,r) = sum_{i∈C} Q_{r,i} / sqrt(n_r + |C|)
%        - cannot-link only: ban set R_ban is the clusters of its cannot-link
%          partners; select r in {1..c}\R_ban maximizing Δ(i,r)
%     3) Both must-link and cannot-link: merge must-link set as C; compile
%        R_ban from cannot-link partners; select r∈{1..c}\R_ban maximizing
%        Δ(C,r).
%   This function operates on one-shot update for all nodes; outer alterna-
%   tion with recomputing G is expected to be handled by a driver.
%
% INPUTS:
%   A_tilde : n x n semi-supervised affinity
%   G       : n x c embedding (rows are samples)
%   Y_init  : n x 1 initial labels (1..c)
%   pairs_ml: K1 x 2 must-link pairs
%   pairs_cl: K2 x 2 cannot-link pairs
%
% OUTPUTS:
%   Y_new : n x 1 updated labels
%   info  : struct with fields {mergedSets, bannedSets}
%==========================================================================

    n = size(A_tilde,1);
    c = size(G,2);
    Y_new = Y_init(:);

    % Build ML connected components to enforce transitivity and avoid overwrites
    ML_graph = sparse(n,n);
    if ~isempty(pairs_ml)
        ML_graph = ML_graph + sparse(pairs_ml(:,1), pairs_ml(:,2), 1, n, n);
        ML_graph = ML_graph + sparse(pairs_ml(:,2), pairs_ml(:,1), 1, n, n);
    end
    % Connected components (each is a must-link group)
    % Connected components without relying on graphconncomp (use graph/conncomp)
    if nnz(ML_graph) == 0
        comps = (1:n); % each node alone
        S = n;
    else
        Gml = graph(ML_graph,'upper');
        comps = conncomp(Gml); % 1..S
        S = max(comps);
    end
    compCells = cell(1, max(S,1));
    for i = 1:n
        compCells{comps(i)}(end+1) = i; %#ok<AGROW>
    end

    % Build cannot-link neighbor list
    CL = cell(n,1);
    if ~isempty(pairs_cl)
        for k = 1:size(pairs_cl,1)
            i = pairs_cl(k,1); j = pairs_cl(k,2);
            CL{i}(end+1) = j; %#ok<AGROW>
            CL{j}(end+1) = i; %#ok<AGROW>
        end
    end

    % Q = G' * A_tilde
    Q = (G') * A_tilde;
    nr = accumarray(max(Y_init,1), 1, [c 1]);

    mergedSets = cell(n,1);
    bannedSets = cell(n,1);

    assigned = false(n,1);

    % Build component-level cannot-link graph
    node2comp = comps(:);
    compN = max(1, max(node2comp));
    CL_comp = cell(compN,1);
    if ~isempty(pairs_cl)
        for k = 1:size(pairs_cl,1)
            ca = node2comp(pairs_cl(k,1));
            cb = node2comp(pairs_cl(k,2));
            if ca~=cb
                CL_comp{ca}(end+1) = cb; %#ok<AGROW>
                CL_comp{cb}(end+1) = ca; %#ok<AGROW>
            end
        end
    end

    % Order components by size (large first) to reduce conflicts
    compSizes = cellfun(@numel, compCells);
    [~, compOrder] = sort(compSizes, 'descend');
    compLabel = zeros(compN,1);

    % Assign components sequentially with dynamic bans from already assigned neighbors
    for idx = 1:numel(compOrder)
        cid = compOrder(idx);
        Cset = unique(compCells{cid});
        if isempty(Cset), continue; end
        % Bans: labels already used by neighbor components
        neighborComps = unique(CL_comp{cid});
        usedByNeighbors = unique(compLabel(neighborComps));
        usedByNeighbors(usedByNeighbors==0) = [];

        scoreC = sum(Q(:,Cset), 2) ./ sqrt(nr + numel(Cset));
        if ~isempty(usedByNeighbors)
            scoreC(usedByNeighbors) = -inf;
        end
        [~, rbest] = max(scoreC);
        compLabel(cid) = rbest;
        Y_new(Cset) = rbest;
        assigned(Cset) = true;
        mergedSets{Cset(1)} = Cset;
        bannedSets{Cset(1)} = usedByNeighbors;
    end

    % Then, assign any remaining unassigned single nodes (should be none)
    for i = 1:n
        if assigned(i), continue; end
        cid = node2comp(i);
        neighborComps = unique(CL_comp{cid});
        usedByNeighbors = unique(compLabel(neighborComps));
        usedByNeighbors(usedByNeighbors==0) = [];
        score = Q(:,i) ./ sqrt(nr + 1);
        if ~isempty(usedByNeighbors)
            score(usedByNeighbors) = -inf;
        end
        [~, rbest] = max(score);
        Y_new(i) = rbest;
    end

    info = struct('mergedSets', {mergedSets}, 'bannedSets', {bannedSets});

end


