function [selectedPairs, scores] = select_pairs_mmr_candidates(G, Astar, candidatePairs, lambda3, diagA, BPs, pairBudget, combineMode)
%==========================================================================
% FUNCTION:
%   [selectedPairs, scores] = select_pairs_mmr_candidates(G, Astar, candidatePairs, lambda3, diagA, BPs)
% DESCRIPTION:
%   MMR selector using an explicit candidate pair list. Representativeness
%   for pairs is computed via MEX (dot between rows of Astar, optionally
%   normalized by diag(Astar*Astar')). Uncertainty is computed based on
%   entropy from base clusterers (BPs). Redundancy penalty uses cosine 
%   similarity of pair embeddings.
%==========================================================================

    if nargin < 4 || isempty(lambda3), lambda3 = 0.5; end
    n = size(G,1);

    if nargin < 5 || isempty(diagA)
        diagA = full(sum(Astar.^2,2));
    end

    % 默认选择预算：若未提供，则选择不超过候选集大小
    if nargin < 7 || isempty(pairBudget)
        pairBudget = min(20, size(candidatePairs,1));
    else
        pairBudget = min(pairBudget, size(candidatePairs,1));
    end

    % 合并打分方式（可选）：'var_weight'|'rank'|'scale'|'var_swap'|'log' 或 1..5
    if nargin < 8 || isempty(combineMode)
        combineMode = 'var_weight';
    end

    % 1) Representativeness via MEX
    rep = compute_pair_rep_mex(Astar, candidatePairs, diagA);

    % 2) Uncertainty based on entropy from base clusterers
    if nargin >= 6 && ~isempty(BPs)
        % 使用基聚类器熵不确定性
        U = compute_entropy_uncertainty(BPs, candidatePairs);
        fprintf('  · 使用基聚类器熵不确定性 (基于%d个基聚类器)\n', size(BPs,2));
    else
        % 回退到原来的距离不确定性
        c = size(G,2);
        [labels, centers] = kmeanspp(G', c); labels = labels(:);
        centers = centers';
        U = zeros(size(candidatePairs,1),1);
        for t = 1:size(candidatePairs,1)
            i = candidatePairs(t,1); j = candidatePairs(t,2);
            di = min(sum((G(i,:) - centers).^2,2));
            dj = min(sum((G(j,:) - centers).^2,2));
            U(t) = di + dj; % higher => more uncertain
        end
        % z-score
        U = (U - mean(U)) / max(std(U), 1e-12);
        fprintf('  · 使用距离不确定性 (回退方案)\n');
    end

    % 2.5) 代表性与不确定性打分归一化到 [0,1]
    a_tilde = rep(:);
    b_tilde = U(:);
    a_tilde = a_tilde - min(a_tilde); a_den = max(a_tilde); if a_den <= 0, a_den = 1; end; a_tilde = a_tilde / a_den;
    b_tilde = b_tilde - min(b_tilde); b_den = max(b_tilde); if b_den <= 0, b_den = 1; end; b_tilde = b_tilde / b_den;

    % 2.6) 合并得分 f0 按用户提供的方法
    if isnumeric(combineMode)
        modeKey = combineMode;
    else
        switch lower(string(combineMode))
            case {'var_weight'}
                modeKey = 1;
            case {'rank'}
                modeKey = 2;
            case {'scale'}
                modeKey = 3;
            case {'var_swap'}
                modeKey = 4;
            case {'log'}
                modeKey = 5;
            otherwise
                modeKey = 1;
        end
    end

    switch modeKey
        case 1 % (1) 方差加权融合
            theta = var(a_tilde) / (var(a_tilde) + var(b_tilde) + eps);
            f0 = theta*a_tilde + (1-theta)*b_tilde;
            f0 = f0 / (sum(f0) + eps);
            modeName = 'var_weight';
        case 2 % (2) 排名得分
            f0_raw = sqrt(max(a_tilde,0) .* max(b_tilde,0));
            [~, o] = sort(f0_raw, 'descend');
            ranks = (length(o):-1:1)';
            rank_scores = zeros(length(o),1);
            rank_scores(o) = ranks;
            f0 = rank_scores / max(rank_scores);
            f0 = f0 / (sum(f0) + eps);
            modeName = 'rank';
        case 3 % (3) 尺度变换
            a_std = (a_tilde - mean(a_tilde)) / (std(a_tilde) + eps);
            b_std = (b_tilde - mean(b_tilde)) / (std(b_tilde) + eps);
            a_scaled = (a_std - min(a_std)) / (max(a_std)-min(a_std)+eps);
            b_scaled = (b_std - min(b_std)) / (max(b_std)-min(b_std)+eps);
            f0 = 0.5*a_scaled + 0.5*b_scaled;
            f0 = (f0 - min(f0)) / (max(f0) - min(f0) + eps);
            f0 = f0 / (sum(f0) + eps);
            modeName = 'scale';
        case 4 % (4) 归一化+互换方差权重
            va = var(a_tilde); vb = var(b_tilde);
            wa = vb / (va + vb + eps);
            wb = va / (va + vb + eps);
            f0 = wa*a_tilde + wb*b_tilde;
            f0 = (f0 - min(f0)) / (max(f0) - min(f0) + eps);
            f0 = f0 / (sum(f0) + eps);
            modeName = 'var_swap';
        case 5 % (5) log 变换
            a_log = log(max(a_tilde,0) + 1e-6);
            b_log = log(max(b_tilde,0) + 1e-6);
            a_log = (a_log - min(a_log)) / (max(a_log)-min(a_log)+eps);
            b_log = (b_log - min(b_log)) / (max(b_log)-min(b_log)+eps);
            f0 = 0.5*a_log + 0.5*b_log;
            f0 = (f0 - min(f0)) / (max(f0) - min(f0) + eps);
            f0 = f0 / (sum(f0) + eps);
            modeName = 'log';
        otherwise
            f0 = (a_tilde + b_tilde) / max(sum(a_tilde + b_tilde), eps);
            modeName = 'simple_avg';
    end
    fprintf('  · 合并打分模式: %s\n', modeName);

    % 3) Greedy MMR with redundancy using pair embeddings
    pairEmb = NormalizeFea((G(candidatePairs(:,1),:) + G(candidatePairs(:,2),:))/2, 1);
    selectedPairs = zeros(0,2);
    scores = zeros(0,1);
    used = false(size(candidatePairs,1),1);
    
    % 增量更新的冗余惩罚：维护对已选集合的最大相似度，避免每轮全量乘法
    currentPenalty = zeros(size(candidatePairs,1),1);

    while sum(used) < pairBudget
        base = f0 - lambda3 * currentPenalty;
        base(used) = -inf;
        [val, idx] = max(base);
        if ~isfinite(val)
            break;
        end
        used(idx) = true;
        selectedPairs(end+1,:) = candidatePairs(idx,:); %#ok<AGROW>
        scores(end+1,1) = val; %#ok<AGROW>
        
        % 增量更新：只用新选中的一个向量更新最大相似度
        simNew = pairEmb * pairEmb(idx,:)';
        currentPenalty = max(currentPenalty, simNew);
    end

end


