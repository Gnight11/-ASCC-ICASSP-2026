function U = compute_entropy_uncertainty(BPs, candidatePairs)
%==========================================================================
% FUNCTION: U = compute_entropy_uncertainty(BPs, candidatePairs)
% DESCRIPTION: 基于基聚类器结果的熵不确定性计算
%   对于每个样本对(i,j)，统计r个基聚类器的投票结果
%   计算熵：H = -p_yes * log2(p_yes) - p_no * log2(p_no)
%   其中p_yes是基聚类器将i,j分到同簇的比例
%
% INPUTS:
%   BPs: n x r 基聚类器结果矩阵 (n个样本, r个基聚类器)
%   candidatePairs: K x 2 候选样本对矩阵
%
% OUTPUTS:
%   U: K x 1 不确定性向量，值越大表示不确定性越高
%==========================================================================

    if isempty(candidatePairs)
        U = [];
        return;
    end

    % 向量化计算
    I = candidatePairs(:,1);
    J = candidatePairs(:,2);
    votes = (BPs(I,:) == BPs(J,:)); % K x r 逻辑矩阵
    p_yes = mean(votes, 2);
    p_no = 1 - p_yes;
    U = zeros(size(candidatePairs,1), 1);
    mask = (p_yes > 0) & (p_yes < 1);
    U(mask) = -p_yes(mask) .* log2(p_yes(mask)) - p_no(mask) .* log2(p_no(mask));
    
    % 标准化到[0,1]范围
    mu = mean(U);
    sigma = std(U);
    if sigma > 0
        U = (U - mu) / sigma;  % 归一到z-score，鲁棒于规模变化
    end
end
