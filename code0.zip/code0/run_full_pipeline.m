% RUN FULL PIPELINE: 数据→无监督共识→主动半监督共识→绘制目标曲线

%% 0) 路径与数据
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

% 固定随机种子，保证一次性BKCC可复现
rng(42);

% 数据文件（首列标签、其余为特征/时间序列）
dataFile = fullfile('..','data','II_Ia_Ib_data.mat');
[Data, labels] = load_timeseries_mat(dataFile); %#ok<NASGU>

%% 1) 可选：编译代表性MEX（若使用候选对加速选择）
% try, mex -O compute_pair_rep_mex.cpp; catch, end

%% 2) 无监督多轮共识
% 改为一次性BKCC：仅一轮，其他参数保持
unsupParams = struct('r',50,'K',4,'c',4,'k',5,'T',5,'maxRounds',1);
out0 = unsupervised_consensus_driver(Data, unsupParams);
figure('Name','Unsupervised Objectives');
plot_objectives(out0.ObjHist, 'Unsupervised');
% 若有标签可评估：
try
    fprintf('=== 无监督评估调试 ===\n');
    fprintf('labels大小: %s\n', mat2str(size(labels)));
    fprintf('out0.final.Y大小: %s\n', mat2str(size(out0.final.Y)));
    fprintf('labels范围: [%d, %d]\n', min(labels), max(labels));
    fprintf('Y范围: [%d, %d]\n', min(out0.final.Y), max(out0.final.Y));
    fprintf('labels唯一值: %s\n', mat2str(unique(labels)));
    fprintf('Y唯一值: %s\n', mat2str(unique(out0.final.Y)));
    
    % 检查维度匹配
    if numel(labels) ~= numel(out0.final.Y)
        fprintf('警告：维度不匹配，labels=%d, Y=%d\n', numel(labels), numel(out0.final.Y));
        fprintf('这可能是由于数据预处理（异常值移除）导致的\n');
        
        % 尝试标签对齐：假设前401个样本对应预处理后的数据
        if numel(labels) > numel(out0.final.Y)
            fprintf('尝试标签对齐：使用前%d个标签进行评估\n', numel(out0.final.Y));
            labels_aligned = labels(1:numel(out0.final.Y));
            try
                M0 = metrics_eval(labels_aligned, out0.final.Y);
                fprintf('标签对齐后评估：ACC=%.4f NMI=%.4f ARI=%.4f\n', M0.ACC, M0.NMI, M0.ARI);
            catch ME
                fprintf('标签对齐后评估失败: %s\n', ME.message);
            end
        else
            fprintf('跳过无监督评估\n');
        end
        
        % 显示无监督约束违反情况（如果有外部约束）
        fprintf('=== 无监督约束违反统计 ===\n');
        fprintf('注意：无监督阶段没有外部约束，聚类结果完全基于数据\n');
        fprintf('无监督聚类结果：%d个簇，标签分布: %s\n', ...
            length(unique(out0.final.Y)), mat2str(histcounts(out0.final.Y, 1:max(out0.final.Y)+1)));
    else
        M0 = metrics_eval(labels, out0.final.Y);
        fprintf('Unsupervised ACC=%.4f NMI=%.4f ARI=%.4f\n', M0.ACC, M0.NMI, M0.ARI);
    end
catch ME
    fprintf('无监督评估失败: %s\n', ME.message);
end

%% 3) 主动半监督多轮共识
% 可选：若已有候选对（K×2，1-based），可设置 params.candidatePairs = candidatePairs;
sslParams = struct('unsupRounds',0,'activeRounds',25,'pairBudget',50, ...
                   'r',50,'K',4,'c',4,'k',5,'T',5,'lambda1',10,'lambda2',10,'lambda3',0.5, ...
                   'enableRepair', false, 'repairOnlyFirst', false, ...  % 关闭约束修复
                   'useSelectedAsConstraints', true, 'gt', labels, 'Tstar', 5);
out = active_semisupervised_consensus_driver(Data, sslParams);
figure('Name','Active-SSL Objectives');
plot_objectives([out.history.obj], 'Active-SSL');

%% 4) 约束比例统计（最后一轮）
if ~isempty(out.history) && isfield(out.history(end), 'pairs_ml')
    n = size(Data,1);
    st = constraint_stats(n, out.history(end).pairs_ml, out.history(end).pairs_cl);
    fprintf('Final constraints: ML=%d (%.4f), CL=%d (%.4f) of all pairs\n', ...
        st.num_ml, st.ratio_ml, st.num_cl, st.ratio_cl);
end

% 评估最终聚类（若有标签）
try
    M = metrics_eval(labels, out.final.Y);
    fprintf('Active-SSL ACC=%.4f NMI=%.4f ARI=%.4f\n', M.ACC, M.NMI, M.ARI);
catch
end


