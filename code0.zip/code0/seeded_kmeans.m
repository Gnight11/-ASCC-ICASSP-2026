function labels = seeded_kmeans(X, k, seeds, gt)
%SEEDED_KMEANS Run k-means with optional seeds or kmeans++ init
%   X: d x N embedding (columns are samples)
%   k: number of clusters
%   seeds: optional 1 x k indices for initial centers in columns of X
%   gt: optional ground truth to bias initial centers via stratified picks

    if nargin < 3, seeds = []; end
    if nargin < 4, gt = []; end

    X = double(X);
    N = size(X,2);

    if isempty(seeds)
        % simple kmeans++ style init
        centers = X(:, randi(N));
        for t = 2:k
            D = pdist2(X', centers');
            d2 = min(D, [], 2) .^ 2;
            probs = d2 / sum(d2);
            cum = cumsum(probs);
            r = rand();
            idx = find(cum >= r, 1, 'first');
            centers(:, end+1) = X(:, idx); %#ok<AGROW>
        end
    else
        centers = X(:, seeds(:)');
    end

    % Lloyd iterations
    max_iter = 100;
    labels = ones(N,1);
    for it = 1:max_iter
        D = pdist2(X', centers');
        [~, labels_new] = min(D, [], 2);
        if all(labels_new == labels), break; end
        labels = labels_new;
        for c = 1:k
            idx = find(labels == c);
            if isempty(idx)
                centers(:, c) = X(:, randi(N));
            else
                centers(:, c) = mean(X(:, idx), 2);
            end
        end
    end
end

















