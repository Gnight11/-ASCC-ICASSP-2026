function plot_convergence_analysis(res_unsup, res_sup10, dataset_name, result_dir)
% PLOT_CONVERGENCE_ANALYSIS: 绘制收敛性分析图
% 
% 输入:
%   res_unsup - 无监督聚类结果
%   res_sup10 - 10%半监督聚类结果  
%   dataset_name - 数据集名称
%   result_dir - 结果保存目录
%
% 输出:
%   保存收敛性分析图到指定目录

try
    % 提取收敛数据
    rayleigh_unsup = [];
    rayleigh_sup10 = [];
    
    % 提取无监督收敛数据
    if isfield(res_unsup, 'ObjHist') && ~isempty(res_unsup.ObjHist)
        rayleigh_unsup = arrayfun(@(o) real(o.rayleigh), res_unsup.ObjHist);
        fprintf('无监督收敛数据: %d个点\n', length(rayleigh_unsup));
    else
        fprintf('警告: 无监督结果中没有找到ObjHist字段\n');
        if isfield(res_unsup, 'final') && isfield(res_unsup.final, 'obj')
            rayleigh_unsup = real(res_unsup.final.obj.rayleigh);
            fprintf('使用最终目标值作为收敛点\n');
        end
    end
    
    % 提取半监督收敛数据
    if exist('res_sup10','var') && ~isempty(res_sup10) && isfield(res_sup10, 'history') && ~isempty(res_sup10.history)
        for i = 1:length(res_sup10.history)
            if isfield(res_sup10.history(i), 'obj') && ~isempty(res_sup10.history(i).obj) && isfield(res_sup10.history(i).obj, 'rayleigh')
                rayleigh_sup10 = [rayleigh_sup10, real(res_sup10.history(i).obj.rayleigh)];
            end
        end
        fprintf('半监督收敛数据: %d个点\n', length(rayleigh_sup10));
    else
        fprintf('警告: 半监督结果中没有找到history字段\n');
        if isfield(res_sup10, 'final') && isfield(res_sup10.final, 'obj')
            rayleigh_sup10 = real(res_sup10.final.obj.rayleigh);
            fprintf('使用最终目标值作为收敛点\n');
        end
    end
    
    % 如果没有收敛数据，跳过绘图
    if isempty(rayleigh_unsup) && isempty(rayleigh_sup10)
        fprintf('警告: 数据集 %s 没有收敛数据，跳过绘图\n', dataset_name);
        return;
    end
    
    % 创建图形
    fig = figure('Position', [100, 100, 1000, 600], 'Visible', 'off');
    
    % 设置子图布局
    subplot(1, 2, 1);
    
    % 绘制无监督收敛曲线
    if ~isempty(rayleigh_unsup)
        plot(1:length(rayleigh_unsup), rayleigh_unsup, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
        hold on;
    end
    
    % 绘制半监督收敛曲线
    if ~isempty(rayleigh_sup10)
        plot(1:length(rayleigh_sup10), rayleigh_sup10, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
        hold on;
    end
    
    % 设置图形属性
    xlabel('Consensus Clustering Iterations', 'FontSize', 12);
    ylabel('Rayleigh Quotient', 'FontSize', 12);
    title(sprintf('Convergence Analysis: %s', strrep(dataset_name, '_', '\_')), 'FontSize', 14);
    grid on;
    
    % 添加图例
    legend_entries = {};
    if ~isempty(rayleigh_unsup)
        legend_entries{end+1} = 'Unsupervised';
    end
    if ~isempty(rayleigh_sup10)
        legend_entries{end+1} = '10% Semi-supervised';
    end
    if ~isempty(legend_entries)
        legend(legend_entries, 'Location', 'best', 'FontSize', 10);
    end
    
    % 设置坐标轴
    xlim([1, max(length(rayleigh_unsup), length(rayleigh_sup10))]);
    
    % 第二个子图：收敛速度对比
    subplot(1, 2, 2);
    
    % 计算收敛改进量
    if ~isempty(rayleigh_unsup) && length(rayleigh_unsup) > 1
        unsup_improvement = diff(rayleigh_unsup);
        plot(2:length(rayleigh_unsup), unsup_improvement, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
        hold on;
    end
    
    if ~isempty(rayleigh_sup10) && length(rayleigh_sup10) > 1
        sup10_improvement = diff(rayleigh_sup10);
        plot(2:length(rayleigh_sup10), sup10_improvement, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
        hold on;
    end
    
    xlabel('Consensus Clustering Iterations', 'FontSize', 12);
    ylabel('Objective Improvement', 'FontSize', 12);
    title('Convergence Speed Analysis', 'FontSize', 14);
    grid on;
    
    % 添加零线
    if ~isempty(rayleigh_unsup) || ~isempty(rayleigh_sup10)
        max_iter = max(length(rayleigh_unsup), length(rayleigh_sup10));
        plot([1, max_iter], [0, 0], 'k--', 'LineWidth', 1);
    end
    
    % 添加图例
    improvement_legend = {};
    if ~isempty(rayleigh_unsup) && length(rayleigh_unsup) > 1
        improvement_legend{end+1} = 'Unsupervised Improvement';
    end
    if ~isempty(rayleigh_sup10) && length(rayleigh_sup10) > 1
        improvement_legend{end+1} = '10% Semi-supervised Improvement';
    end
    if ~isempty(improvement_legend)
        legend(improvement_legend, 'Location', 'best', 'FontSize', 10);
    end
    
    % 调整布局
    sgtitle(sprintf('Dataset: %s - Convergence Analysis', strrep(dataset_name, '_', '\_')), 'FontSize', 16, 'FontWeight', 'bold');
    
    % 保存图形
    fig_file = fullfile(result_dir, sprintf('%s_convergence_analysis.png', dataset_name));
    saveas(fig, fig_file, 'png');
    
    % 保存高分辨率版本
    fig_file_hires = fullfile(result_dir, sprintf('%s_convergence_analysis_hires.png', dataset_name));
    print(fig, fig_file_hires, '-dpng', '-r300');
    
    % 关闭图形
    close(fig);
    
    fprintf('收敛性分析图已保存: %s\n', fig_file);
    
    % 输出收敛性统计信息
    fprintf('收敛性统计:\n');
    if ~isempty(rayleigh_unsup)
        fprintf('  无监督: %d轮, 最终值: %.6f', length(rayleigh_unsup), rayleigh_unsup(end));
        if length(rayleigh_unsup) > 1
            monotonic = all(diff(rayleigh_unsup) >= -1e-10);  % 允许小的数值误差
            if monotonic
                fprintf(', 单调性: ✓');
            else
                fprintf(', 单调性: ✗');
            end
        end
        fprintf('\n');
    end
    
    if ~isempty(rayleigh_sup10)
        fprintf('  10%%半监督: %d轮, 最终值: %.6f', length(rayleigh_sup10), rayleigh_sup10(end));
        if length(rayleigh_sup10) > 1
            monotonic = all(diff(rayleigh_sup10) >= -1e-10);  % 允许小的数值误差
            if monotonic
                fprintf(', 单调性: ✓');
            else
                fprintf(', 单调性: ✗');
            end
        end
        fprintf('\n');
    end
    
catch ME
    fprintf('绘制收敛性分析图时出错: %s\n', ME.message);
    if exist('fig', 'var')
        close(fig);
    end
end

end
