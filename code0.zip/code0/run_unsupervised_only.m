% RUN UNSUPERVISED ONLY: 数据→表示增强→构图→谱聚类→kmeanspp
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));
% 设置固定种子以复现最佳结果
rng(298);  % 使用网格搜索找到的最佳种子

% 读取数据（首列标签，其余为特征）
dataFile = fullfile('..','data','II_Ia_Ib_data.mat');
[Data, labels] = load_timeseries_mat(dataFile);

% 使用网格搜索找到的最佳参数：k=60, T=12, snnWeight=0.50, gamma=1.2
params = struct('r',200,'K',4,'c',4,'k',60,'T',12,'maxRounds',1, ...
                'distance','cosine','mutual',true,'pcaDim',150, ...
                'snnWeight',0.50,'gamma',1.2,'KiMode',0, ...
                'externalSeed',298);  % 传递外部种子

fprintf('=== 仅无监督链路验证开始 ===\n');
res = unsupervised_consensus_driver(Data, params);

% 基本输出
Y = res.final.Y(:);
Kc = max(Y);
counts = histcounts(Y, 1:Kc+1);
fprintf('无监督聚类结果：%d个簇，标签分布: %s\n', Kc, mat2str(counts));

% 评估
try
    M = metrics_eval(labels, Y);
    fprintf('Unsupervised ACC=%.4f NMI=%.4f ARI=%.4f\n', M.ACC, M.NMI, M.ARI);
catch ME
    fprintf('评估失败：%s\n', ME.message);
end

% 关键中间量尺寸
if isfield(res,'Xe')
    fprintf('Xe大小: %s\n', mat2str(size(res.Xe)));
end
if isfield(res,'final') && isfield(res.final,'A')
    fprintf('A大小: %s\n', mat2str(size(res.final.A)));
end
if isfield(res,'final') && isfield(res.final,'G')
    fprintf('G大小: %s\n', mat2str(size(res.final.G)));
end

% 目标曲线
if isfield(res,'ObjHist') && ~isempty(res.ObjHist)
    figure('Name','Unsupervised Objectives (Only)');
    plot_objectives(res.ObjHist, 'Unsupervised-Only');
end

fprintf('=== 仅无监督链路验证结束 ===\n');
