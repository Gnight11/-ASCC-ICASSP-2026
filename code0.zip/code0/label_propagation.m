function labels = label_propagation(A, labeled_idx, labeled_y, alpha)
%LABEL_PROPAGATION Simple graph-based label propagation
%   A: N x N affinity (symmetric)
%   labeled_idx: L x 1 indices of labeled nodes
%   labeled_y: L x 1 labels (1..K) for labeled nodes
%   alpha: propagation parameter in (0,1)

    if nargin < 4 || isempty(alpha), alpha = 0.99; end
    N = size(A,1);
    labeled_idx = labeled_idx(:);
    labeled_y = labeled_y(:);
    classes = unique(labeled_y);
    K = numel(classes);

    % Normalize A into transition matrix S = D^-1/2 * A * D^-1/2
    d = sum(A,2) + 1e-8;
    Dm = spdiags(1./sqrt(d), 0, N, N);
    S = Dm * A * Dm;

    % Initial label matrix Y (one-hot for labeled)
    Y = zeros(N, K);
    for i = 1:numel(labeled_idx)
        li = labeled_idx(i);
        c  = find(classes == labeled_y(i), 1, 'first');
        if ~isempty(c)
            Y(li, c) = 1;
        end
    end

    % Closed-form solution: F = (I - alpha*S)^{-1} * Y
    I = speye(N);
    F = (I - alpha*S) \ Y;

    % Predict labels by argmax
    [~, idx] = max(F, [], 2);
    labels = classes(idx);
end

















