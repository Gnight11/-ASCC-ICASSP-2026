% Run USPEC and USENC (unsupervised) on II_Ia_Ib_data.mat with fixed settings
% - seed = 44
% - Knn = 5
% - k = number of unique ground-truth labels
% Outputs ACC/NMI/ARI for both methods

clear; clc;

% Paths (robust): build explicit relative paths from this script folder
this_file = mfilename('fullpath');
[this_dir,~,~] = fileparts(this_file);
base_dir = fullfile(this_dir, '..'); % .. => Active clustering
uspec_repo = fullfile(this_dir, '..', 'USPEC-USENC-TKDE-2020-Huang','USPEC_USENC-master');
data_path  = fullfile(this_dir, '..', 'data','II_Ia_Ib_data.mat');
consee_gc_dir = fullfile(this_dir, '..', 'ConsEEGc_CODE');

% Debug prints for paths
fprintf('this_dir = %s\n', this_dir);
fprintf('base_dir = %s\n', base_dir);
fprintf('uspec_repo = %s\n', uspec_repo);
fprintf('data_path  = %s\n', data_path);

% Existence checks
if ~exist(uspec_repo, 'dir')
    error('USPEC/USENC repo not found: %s', uspec_repo);
end
if ~exist(data_path, 'file')
    error('Data file not found: %s', data_path);
end

% Add paths for USPEC/USENC helpers (litekmeans, etc.)
addpath(genpath(uspec_repo));
fprintf('USPEC path: %s\n', which('USPEC'));
fprintf('USENC  path: %s\n', which('USENC'));

% Seed
rng(44,'twister');

% Load data (robust field mapping)
S = load(data_path);

% Candidate feature/label fields
feaFields = {'fea','data','X','features'};
gtFields  = {'gt','label','labels','y','Y','gnd'};
fea = [];
gt  = [];

% Try to get features
for ii = 1:numel(feaFields)
    f = feaFields{ii};
    if isfield(S, f)
        fea = S.(f);
        break;
    end
end

% If 'data' includes labels in first column, split automatically
if isempty(gt) && ~isempty(fea) && isfield(S,'data')
    Xcand = S.data;
    if size(Xcand,2) > 1
        firstCol = Xcand(:,1);
        isLabelish = isreal(firstCol) && all(~isnan(firstCol)) && numel(unique(firstCol)) < size(Xcand,1);
        if isLabelish
            gt = firstCol;
            fea = Xcand(:,2:end);
        end
    end
end

% If labels not found yet, search gt-like fields
if isempty(gt)
    for jj = 1:numel(gtFields)
        g = gtFields{jj};
        if isfield(S, g)
            gt = S.(g);
            break;
        end
    end
end

if isempty(fea) || isempty(gt)
    % Heuristic fallback: auto-detect from numeric variables
    fns = fieldnames(S);
    numVars = {};
    for kk = 1:numel(fns)
        v = S.(fns{kk});
        if isnumeric(v) && isreal(v) && ~isscalar(v)
            numVars{end+1} = fns{kk}; %#ok<AGROW>
        end
    end
    % Pick candidate feature matrix: prefer 2D with cols>1 and rows>=10
    bestName = '';
    bestScore = -inf;
    for kk = 1:numel(numVars)
        vn = numVars{kk}; v = S.(vn);
        if ndims(v) == 2 && size(v,2) > 1 && size(v,1) >= 10
            score = size(v,1) * size(v,2);
            if score > bestScore
                bestScore = score; bestName = vn;
            end
        end
    end
    if ~isempty(bestName)
        fea = S.(bestName);
        % try find label vector
        gtName = '';
        for kk = 1:numel(numVars)
            vn = numVars{kk}; v = S.(vn);
            if isvector(v) && numel(v) == size(fea,1)
                gtName = vn; gt = v; break;
            end
        end
        % if first col looks like labels, split
        if isempty(gt) && size(fea,2) > 1
            firstCol = fea(:,1);
            if isreal(firstCol) && all(~isnan(firstCol)) && numel(unique(firstCol)) < size(fea,1)
                gt = firstCol; fea = fea(:,2:end);
            end
        end
        if isempty(gt)
            error('Unrecognized data fields in mat file (no label vector found).');
        else
            fprintf('Auto-detected features: %s, labels: %s\n', bestName, gtName);
        end
    else
        error('Unrecognized data fields in mat file.');
    end
end

% Sanitize types and shapes
fea = double(real(fea));
fea(~isfinite(fea)) = 0;
gt = double(gt(:));

% Remap labels to 1..k if necessary
[~,~,gt] = unique(gt, 'stable');

% Normalize features similarly to code0 utilities if available
if exist('NormalizeFea','file') == 2
    fea = NormalizeFea(fea);
else
    % simple z-score
    mu = mean(fea,1);
    sigma = std(fea,[],1) + 1e-8;
    fea = bsxfun(@rdivide, bsxfun(@minus, fea, mu), sigma);
end

k = numel(unique(gt));
Knn = 5;

fprintf('Dataset loaded: N=%d, d=%d, k=%d\n', size(fea,1), size(fea,2), k);

% USPEC
fprintf('\nRunning USPEC (unsupervised) ...\n');
tic;
Label_uspec = USPEC(fea, k, 'euclidean', 1000, Knn);
t_uspec = toc;

% USENC
fprintf('\nRunning USENC (unsupervised) ...\n');
tic;
Label_usenc = USENC(fea, k, 20, 'euclidean', 1000, Knn, 20, 60);
t_usenc = toc;

% Metrics: use code0/metrics_eval if available, else fall back to ConsEEGc_CODE helpers
addpath(this_dir);
metrics_fun = [];
if exist('metrics_eval','file') == 2
    metrics_fun = @metrics_eval;
end
if isempty(metrics_fun)
    addpath(genpath(consee_gc_dir));
end

% Compute metrics
if exist('metrics_eval','file') == 2
    M_uspec = metrics_eval(gt, Label_uspec);
    M_usenc = metrics_eval(gt, Label_usenc);
else
    acc_fn = @compute_acc; nmi_fn = @compute_nmi;
    M_uspec = struct('ACC',acc_fn(gt,Label_uspec),'NMI',nmi_fn(gt,Label_uspec),'ARI',NaN);
    M_usenc = struct('ACC',acc_fn(gt,Label_usenc),'NMI',nmi_fn(gt,Label_usenc),'ARI',NaN);
end

% Print results
fprintf('\nUSPEC:  ACC=%.4f  NMI=%.4f  ARI=%.4f  (time %.2fs)\n', M_uspec.ACC, M_uspec.NMI, M_uspec.ARI, t_uspec);
fprintf('USENC:  ACC=%.4f  NMI=%.4f  ARI=%.4f  (time %.2fs)\n', M_usenc.ACC, M_usenc.NMI, M_usenc.ARI, t_usenc);

% Save results
outdir = fullfile(this_dir,'baseline_results');
if ~exist(outdir,'dir'); mkdir(outdir); end
save(fullfile(outdir,'USPEC_USENC_II_Ia_Ib_results.mat'), 'M_uspec','M_usenc','Label_uspec','Label_usenc','t_uspec','t_usenc','k','Knn');
fid = fopen(fullfile(outdir,'USPEC_USENC_II_Ia_Ib_report.txt'),'w');
fprintf(fid,'USPEC:  ACC=%.6f  NMI=%.6f  ARI=%.6f  (time %.4fs)\n', M_uspec.ACC, M_uspec.NMI, M_uspec.ARI, t_uspec);
fprintf(fid,'USENC:  ACC=%.6f  NMI=%.6f  ARI=%.6f  (time %.4fs)\n', M_usenc.ACC, M_usenc.NMI, M_usenc.ARI, t_usenc);
fclose(fid);

fprintf('\nResults saved to %s\n', outdir);
