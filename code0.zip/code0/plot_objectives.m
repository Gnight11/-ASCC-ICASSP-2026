function plot_objectives(objArray, titleStr)
% objArray: struct array with fields .rayleigh and .sse
    R = arrayfun(@(o) real(o.rayleigh), objArray);  % 只取实部
    S = arrayfun(@(o) real(o.sse), objArray);        % 只取实部
    rounds = 1:numel(R);
    subplot(1,2,1);
    plot(rounds, R, '-o'); grid on; xlabel('Round'); ylabel('Rayleigh');
    title([titleStr ' - Rayleigh']);
    subplot(1,2,2);
    plot(rounds, S, '-o'); grid on; xlabel('Round'); ylabel('SSE (lower better)');
    title([titleStr ' - SSE']);
end


