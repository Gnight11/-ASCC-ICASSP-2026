function [numViolMust, numViolCannot] = check_constraint_violations_local(labels, mustPairs, cannotPairs)
% 检查标签对约束的违例情况
% INPUTS:
%   labels: 聚类标签向量
%   mustPairs: must-link约束对 [n x 2]
%   cannotPairs: cannot-link约束对 [n x 2]
% OUTPUTS:
%   numViolMust: must-link违例数量
%   numViolCannot: cannot-link违例数量

    numViolMust = 0; 
    numViolCannot = 0;
    
    % 检查must-link违例
    for t = 1:size(mustPairs,1)
        if labels(mustPairs(t,1)) ~= labels(mustPairs(t,2))
            numViolMust = numViolMust + 1;
        end
    end
    
    % 检查cannot-link违例
    for t = 1:size(cannotPairs,1)
        if labels(cannotPairs(t,1)) == labels(cannotPairs(t,2))
            numViolCannot = numViolCannot + 1;
        end
    end
end
