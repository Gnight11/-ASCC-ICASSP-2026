%% 快速收敛测试 - 简化版本
% 
% 只测试：无监督 + 10%半监督（跳过20%半监督和大型参数搜索）
% 预计时间：30分钟 - 1小时
%
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 快速收敛测试 ===\n');
fprintf('简化版本：只测试核心功能，跳过耗时的参数搜索\n\n');

%% 加载数据
[data, gt] = load_timeseries_mat(fullfile('..','data','II_Ia_Ib_data.mat'));
n_samples = length(gt);
n_classes = length(unique(gt));

fprintf('数据信息: %d个样本, %d个类别\n', n_samples, n_classes);

%% 设置固定参数（使用已知最佳参数）
rng(97);  % 使用已知最佳种子
best_params = struct();
best_params.k = 15;
best_params.T = 45;
best_params.snnWeight = 0.15;
best_params.gamma = 4.5;
best_params.r = 100;
best_params.c = 4;
best_params.maxRounds = 10;  % 🔥 减少轮数，快速测试

fprintf('使用最佳参数: k=%d, T=%d, gamma=%.1f, 轮数=%d\n\n', ...
    best_params.k, best_params.T, best_params.gamma, best_params.maxRounds);

%% 1. 无监督聚类（快速版）
fprintf('--- 1. 无监督聚类（%d轮）---\n', best_params.maxRounds);
tic;
try
    res_unsup = unsupervised_consensus_driver(data, best_params);
    Y_unsup = res_unsup.final.Y(:);
    M_unsup = metrics_eval(gt, Y_unsup);
    time_unsup = toc;
    
    fprintf('✅ 无监督结果: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs)\n', ...
        M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup);
catch ME
    fprintf('❌ 无监督聚类失败: %s\n', ME.message);
    return;
end

%% 2. 10%半监督聚类（快速版）
fprintf('\n--- 2. 10%%半监督聚类（%d轮）---\n', best_params.maxRounds);

% 快速标签采样
label_ratio = 0.1;
labeled_indices = [];
for c = 1:n_classes
    class_indices = find(gt == c);
    n_class_labeled = max(1, round(length(class_indices) * label_ratio));
    class_labeled = randsample(class_indices, n_class_labeled);
    labeled_indices = [labeled_indices; class_labeled(:)];
end

% 快速约束构建
constraints_10 = struct();
constraints_10.ml = [];
constraints_10.cl = [];

% 简化约束生成（避免过多约束）
for c = 1:n_classes
    class_labeled = labeled_indices(gt(labeled_indices) == c);
    if length(class_labeled) > 1
        % 只连接前两个样本
        for i = 1:min(2, length(class_labeled)-1)
            constraints_10.ml = [constraints_10.ml; class_labeled(i), class_labeled(i+1)];
        end
    end
end

% 简化CL约束
for c1 = 1:n_classes
    for c2 = c1+1:n_classes
        class1_labeled = labeled_indices(gt(labeled_indices) == c1);
        class2_labeled = labeled_indices(gt(labeled_indices) == c2);
        if ~isempty(class1_labeled) && ~isempty(class2_labeled)
            % 只连接第一对
            constraints_10.cl = [constraints_10.cl; class1_labeled(1), class2_labeled(1)];
        end
    end
end

fprintf('约束数量: %d个ML, %d个CL\n', size(constraints_10.ml,1), size(constraints_10.cl,1));

% 运行10%半监督
try
    tic;
    params_sup10 = best_params;
    params_sup10.constraints_ml = constraints_10.ml;
    params_sup10.constraints_cl = constraints_10.cl;
    params_sup10.unsupRounds = 0;
    params_sup10.activeRounds = 8;  % 🔥 减少轮数
    params_sup10.enableHardConstraints = true;
    params_sup10.enableRepair = true;
    params_sup10.patience = 5;  % 🔥 减少patience
    params_sup10.earlyStop = true;
    params_sup10.lambda1 = 0.35;
    params_sup10.lambda2 = 0.35;
    params_sup10.combineMode = 'var_weight';
    
    % 使用无监督结果作为初始状态
    optW = struct(); 
    optW.NeighborMode = 'KNN';
    optW.k = best_params.k;
    optW.WeightMode = 'HeatKernel';
    params_sup10.initial_A = full(constructW(res_unsup.final.Xe, optW));
    params_sup10.initial_G = res_unsup.final.G;
    params_sup10.initial_Y = res_unsup.final.Y;
    params_sup10.initial_Xe = res_unsup.final.Xe;
    
    if isfield(res_unsup, 'BPsHist') && ~isempty(res_unsup.BPsHist)
        params_sup10.BPs = res_unsup.BPsHist{end};
    end
    
    res_sup10 = active_semisupervised_consensus_driver(data, params_sup10);
    Y_sup10 = res_sup10.final.Y(:);
    
    % 简单修复
    for repair_iter = 1:2
        [viol_ml, viol_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
        if viol_ml == 0 && viol_cl == 0
            break;
        end
        Y_sup10 = repair_labels_with_constraints(Y_sup10, constraints_10, data, n_classes, 2);
    end
    
    M_sup10 = metrics_eval(gt, Y_sup10);
    time_sup10 = toc;
    
    [viol10_ml, viol10_cl] = check_constraint_violations_local(Y_sup10, constraints_10.ml, constraints_10.cl);
    fprintf('✅ 10%%半监督: ACC=%.4f NMI=%.4f ARI=%.4f (用时%.2fs) | 违规: ML=%d CL=%d\n', ...
        M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, viol10_ml, viol10_cl);
        
catch ME
    fprintf('❌ 10%%半监督失败: %s\n', ME.message);
    M_sup10 = struct('ACC', 0, 'NMI', 0, 'ARI', 0);
    time_sup10 = 0;
    viol10_ml = 999; viol10_cl = 999;
end

%% 3. 结果汇总
fprintf('\n=== 快速测试结果汇总 ===\n');
fprintf('%-15s %-12s %-12s %-12s %-10s %-10s\n', '方法', 'ACC', 'NMI', 'ARI', '用时(s)', '违规');
fprintf('%s\n', repmat('-', 1, 80));

fprintf('%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10s\n', '无监督', ...
    M_unsup.ACC, M_unsup.NMI, M_unsup.ARI, time_unsup, 'N/A');
fprintf('%-15s %-12.4f %-12.4f %-12.4f %-10.2f %-10s\n', '10%半监督', ...
    M_sup10.ACC, M_sup10.NMI, M_sup10.ARI, time_sup10, sprintf('ML:%d CL:%d', viol10_ml, viol10_cl));

% 层级关系检查
fprintf('\n--- 层级关系检查 ---\n');
if M_unsup.ACC < M_sup10.ACC
    fprintf('✅ 层级要求满足: 无监督(%.4f) < 10%%半监督(%.4f)\n', M_unsup.ACC, M_sup10.ACC);
else
    fprintf('❌ 层级要求不满足: 无监督(%.4f) >= 10%%半监督(%.4f)\n', M_unsup.ACC, M_sup10.ACC);
end

%% 4. 保存结果
result_dir = sprintf('quick_convergence_results_%s', datestr(now, 'yyyymmdd_HHMMSS'));
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

% 保存MAT文件
mat_file = fullfile(result_dir, 'quick_convergence_results.mat');
save(mat_file, 'M_unsup', 'M_sup10', 'best_params', 'constraints_10', 'res_unsup', 'res_sup10');

% 保存报告
report_file = fullfile(result_dir, 'quick_report.txt');
fid = fopen(report_file, 'w');
if fid ~= -1
    fprintf(fid, '=== 快速收敛测试报告 ===\n');
    fprintf(fid, '测试时间: %s\n', datestr(now));
    fprintf(fid, '数据集: II_Ia_Ib_data.mat\n');
    fprintf(fid, '样本数: %d, 类别数: %d\n\n', n_samples, n_classes);
    
    fprintf(fid, '=== 参数设置 ===\n');
    fprintf(fid, 'k=%d, T=%d, gamma=%.1f\n', best_params.k, best_params.T, best_params.gamma);
    fprintf(fid, '轮数: %d (快速版)\n', best_params.maxRounds);
    fprintf(fid, '随机种子: 97\n\n');
    
    fprintf(fid, '=== 性能结果 ===\n');
    fprintf(fid, '无监督: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', M_unsup.ACC, M_unsup.NMI, M_unsup.ARI);
    fprintf(fid, '10%%半监督: ACC=%.4f, NMI=%.4f, ARI=%.4f\n', M_sup10.ACC, M_sup10.NMI, M_sup10.ARI);
    fprintf(fid, '层级关系: %s\n', string(M_unsup.ACC < M_sup10.ACC));
    fprintf(fid, '约束违规: ML=%d, CL=%d\n', viol10_ml, viol10_cl);
    
    fclose(fid);
    fprintf('\n报告已保存: %s\n', report_file);
end

fprintf('MAT文件已保存: %s\n', mat_file);
fprintf('\n🎉 快速测试完成！总用时: %.1f分钟\n', (time_unsup + time_sup10)/60);
fprintf('结果目录: %s\n', result_dir);




