function [comp_ids, num_comps] = simple_connected_components(G)
% SIMPLE_CONNECTED_COMPONENTS - 简单的连通分量算法
% 用于替代MATLAB中被移除的graphconncomp函数
%
% 输入:
%   G - 稀疏邻接矩阵 (n x n)
% 输出:
%   comp_ids - 每个节点所属的连通分量ID (1 x n)
%   num_comps - 连通分量总数

N = size(G, 1);
comp_ids = zeros(1, N);
num_comps = 0;
visited = false(1, N);

for i = 1:N
    if ~visited(i)
        num_comps = num_comps + 1;
        % BFS遍历连通分量
        queue = i;
        visited(i) = true;
        comp_ids(i) = num_comps;
        
        while ~isempty(queue)
            current = queue(1);
            queue(1) = [];
            
            % 找到所有邻居
            neighbors = find(G(current, :));
            for j = neighbors
                if ~visited(j)
                    visited(j) = true;
                    comp_ids(j) = num_comps;
                    queue(end+1) = j;
                end
            end
        end
    end
end

end
