function A = build_knn_affinity_local(X, k)
%BUILD_KNN_AFFINITY_LOCAL Mutual kNN graph with local-sigma Gaussian weights
%   X: N x D
%   k: neighbors per node

    if nargin < 2 || isempty(k), k = 5; end
    X = double(X);
    X(~isfinite(X)) = 0;
    N = size(X,1);

    % pairwise distances (squared euclidean)
    D2 = pdist2(X, X, 'squaredeuclidean');
    for i = 1:N
        D2(i,i) = inf;
    end

    % kNN indices and local sigma as median distance to kNN
    [~, idx] = sort(D2, 2, 'ascend');
    k = min(k, max(1, N-1));
    knn_idx = idx(:, 1:k);

    % compute local sigma using sqrt distances to kNN
    sigma_local = zeros(N,1);
    for i = 1:N
        di = sqrt(max(D2(i, knn_idx(i,:)), 0));
        if isempty(di)
            sigma_local(i) = 1;
        else
            sigma_local(i) = median(di) + 1e-8;
        end
    end

    % initial directed weights using local sigma
    A = sparse(N, N);
    for i = 1:N
        nbrs = unique(knn_idx(i, :));
        for t = 1:numel(nbrs)
            j = nbrs(t);
            dij = sqrt(max(D2(i,j), 0));
            sig_ij = sqrt(sigma_local(i) * sigma_local(j));
            if sig_ij <= 0 || ~isfinite(sig_ij)
                w = 0;
            else
                w = exp(-dij / sig_ij);
            end
            if isfinite(w) && w > 0
                A(i, j) = w;
            end
        end
    end

    % keep only mutual edges and symmetrize by max
    A_bin = A > 0;
    mutual = A_bin & A_bin';
    A = A .* mutual;
    A = max(A, A');

    % ensure numerical stability
    A = A - diag(diag(A));
end
