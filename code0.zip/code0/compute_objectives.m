function obj = compute_objectives(A, G, Y)
%==========================================================================
% 稳定的收敛监控目标
% - rayleigh: Tr(G' L G) / Tr(G' D G)，其中 L=D-A（对称化+正则）
% - sse: k-means within-cluster SSE in embedding space
% 说明：避免使用 Y*(Y'Y)^(-1/2) 与 sqrtm/inv 引发的奇异与非方阵 trace 问题
%==========================================================================
    n = size(G,1); %#ok<NASGU>

    % 对称化相似度并构造拉普拉斯
    A = full(A);
    A = (A + A') / 2;
    A(A < 0) = 0;
    d = sum(A, 2);
    D = diag(d + eps);
    L = D - A;

    % Rayleigh（取负号后可作为“越大越好”的指标）
    num = trace(G' * L * G);
    den = trace(G' * D * G) + eps;
    rayleigh_val = - num / den;  % 负号：切割越小越好 → 数值越大越好
    if ~isfinite(rayleigh_val)
        rayleigh_val = -real(num) / (abs(real(den)) + eps);
    end
    obj.rayleigh = real(rayleigh_val);

    % SSE（嵌入空间的类内平方和，作为辅助）
    Gn = NormalizeFea(G, 1);
    c = size(G,2);
    try
        [labels, centers] = kmeanspp(Gn, c);
        labels = labels(:);
    catch ME
        fprintf('    · kmeanspp调用失败: %s，使用均值中心备用\n', ME.message);
        % 若 kmeans 失败，则根据最大分量划分成 c 簇的粗略标签
        [~, labels] = max(Gn, [], 2);
        centers = zeros(c, size(Gn,2));
        for r = 1:c
            idx = find(labels==r);
            if ~isempty(idx)
                centers(r,:) = mean(Gn(idx,:), 1);
            end
        end
    end
    sse = 0;
    for r = 1:c
        idx = find(labels==r);
        if isempty(idx), continue; end
        diff = Gn(idx,:) - centers(r,:);
        sse = sse + sum(sum(diff.^2));
    end
    obj.sse = real(sse);
    obj.n = size(G,1);
end


