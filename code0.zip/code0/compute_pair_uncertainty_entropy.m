function [U, U_norm, stats] = compute_pair_uncertainty_entropy(BPs, weights)
%==========================================================================
% FUNCTION:
%   [U, U_norm, stats] = compute_pair_uncertainty_entropy(BPs, weights)
% DESCRIPTION:
%   Compute pair-level uncertainty based on consensus entropy across base
%   partitions. For each pair (i,j), let p_k be the probability that i and
%   j fall into the same cluster in partition k (here 0/1 for single run),
%   then H_ij = - sum_k w_k * p_k * log(max(p_k,eps)).
%
% INPUTS:
%   BPs     : n x m matrix of base partition labels (integers, 1..K_k)
%   weights : optional m x 1 weights w_k (default uniform)
%
% OUTPUTS:
%   U       : n x n symmetric uncertainty scores H_ij (zero diagonal)
%   U_norm  : z-score normalized U over upper-triangle entries
%   stats   : struct with fields {mean, std}
%==========================================================================

    [n, m] = size(BPs);
    if nargin < 2 || isempty(weights)
        weights = ones(m,1) / m;
    else
        weights = weights(:);
        weights = weights / sum(weights);
    end

    % For each partition k, build same-cluster indicator matrix Sk
    U = zeros(n,n);
    for k = 1:m
        labels = BPs(:,k);
        % Build block-diagonal 0/1 co-association matrix
        [~,~,lab] = unique(labels(:));
        Sk = sparse(n,n);
        for c = unique(lab)'
            idx = find(lab==c);
            Sk = Sk + sparse(idx, idx, 1, n, n);
        end
        Sk = Sk > 0;  % logical

        % Convert to probabilities p_k in {0,1} and entropy term
        Pk = double(Sk);
        Hk = -Pk .* log(max(Pk, eps)); % 0*log0 viewed as 0
        U = U + weights(k) * Hk;
    end

    % Symmetrize and zero diagonal
    U = max(U, U');
    U(1:n+1:end) = 0;

    % z-score over upper triangle
    mask = triu(true(n), 1);
    vals = U(mask);
    mu = mean(vals);
    sd = std(vals);
    if sd < 1e-12, sd = 1; end
    Z = (U - mu) / sd;
    Z(1:n+1:end) = 0;

    U_norm = Z;
    stats = struct('mean', mu, 'std', sd);

end


