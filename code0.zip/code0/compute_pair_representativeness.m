function [Astar, A_pair, A_pair_norm, stats] = compute_pair_representativeness(S, alpha, T)
%==========================================================================
% FUNCTION:
%   [Astar, A_pair, A_pair_norm, stats] = compute_pair_representativeness(S, alpha, T)
% DESCRIPTION:
%   Compute pair-level representativeness scores from a sample similarity
%   matrix S using high-order diffusion. We implement the truncated series
%   of A* = sum_{t=0..T} (1-alpha) * alpha^t * S^(2t+1).
%   Then obtain pair scores as A_pair = Astar * Astar'. If Astar is
%   symmetric, this equals Astar^2. Finally, perform diagonal normalization
%   to get A_pair_norm(i,j) = A_pair(i,j) / sqrt(A_pair(i,i) * A_pair(j,j)).
%
% INPUTS:
%   S     : n x n symmetric similarity matrix (sparse allowed)
%   alpha : diffusion factor in (0,1). Default 0.9
%   T     : truncation order (non-negative integer). Default 5
%
% OUTPUTS:
%   Astar      : n x n diffused similarity matrix (approx. high-order)
%   A_pair     : n x n pair-level scores before normalization
%   A_pair_norm: n x n pair-level scores after diagonal normalization
%   stats      : struct with fields {alpha, T}
%==========================================================================

    if nargin < 2 || isempty(alpha)
        alpha = 0.9;
    end
    if nargin < 3 || isempty(T)
        T = 5;
    end

    n = size(S,1);
    S = max(S, S');

    % Optional spectral scaling to improve numerical stability
    d = full(sum(S,2));
    d(d==0) = 1;
    Dm12 = spdiags(d.^-0.5, 0, n, n);
    S = Dm12 * S * Dm12;

    % Truncated series for A*
    Astar = sparse(n,n);
    P = S; % S^(2t+1) at t=0
    for t = 0:T
        coef = (1 - alpha) * (alpha ^ t);
        Astar = Astar + coef * P;
        % Update P to S^(2(t+1)+1) = S^(2t+3) = (S^(2t+1)) * S^2
        P = P * (S * S);
    end

    % Pair-level representativeness
    A_pair = Astar * Astar';

    % Diagonal normalization
    diagv = sqrt(max(1e-12, full(diag(A_pair))));
    A_pair_norm = bsxfun(@rdivide, bsxfun(@rdivide, A_pair, diagv), diagv');

    stats = struct('alpha', alpha, 'T', T);

end


