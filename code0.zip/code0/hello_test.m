% 最简单的MATLAB测试
fprintf('Hello from MATLAB!\n');
fprintf('当前时间: %s\n', datestr(now));
fprintf('测试完成\n');
pause(1);




