function out = unsupervised_consensus_driver(Data, params)
%==========================================================================
% FUNCTION:
%   out = unsupervised_consensus_driver(Data, params)
% DESCRIPTION:
%   Multi-round unsupervised consensus procedure.
%   Round t uses current representation (Data for t=1; X_e from previous
%   round for t>1) to generate r base partitions via RPS-kmeans, builds the
%   BKCC enhanced representation X_e, constructs S/A, computes spectral
%   embedding G and k-means labels Y, and iterates until convergence or
%   reaching max rounds.
%
% INPUTS:
%   Data   : n x d raw features (without labels)
%   params : struct with fields (all optional, defaults in brackets)
%       .r        number of base partitions per round [20]
%       .K        nominal clusters for base kmeans [size unique(Y) or c]
%       .dist     distance for kmeans in BasicCluster_RPS ['sqeuclidean']
%       .KiMode   1 to randomize Ki in RPS, else fixed K [1]
%       .T        diffusion steps for computePTS_II [5]
%       .alpha    diffusion factor for compute_pair_representativeness (if used) [0.9]
%       .k        knn neighbors for build_S_and_A_from_Xe [10]
%       .c        target number of clusters for final Y [K]
%       .maxRounds max consensus rounds [5]
%       .tolStop  stop if NMI(Y_t, Y_{t-1}) >= 0.999 (or equality) [true]
%
% OUTPUT:
%   out : struct with fields
%       .XeHistory  cell{t} enhanced representations
%       .AHist      cell{t} affinity matrices A
%       .GHist      cell{t} embeddings G
%       .YHist      cell{t} labels Y (1..c)
%       .BPsHist    cell{t} base partitions matrix (n x r)
%       .final      struct with fields Xe, A, G, Y, rounds
%==========================================================================

    if nargin < 2, params = struct(); end
    [n, ~] = size(Data);

    r        = getfielddef(params, 'r', 20); %#ok<GFLDDEF>
    K        = getfielddef(params, 'K', []);
    % 兼容字段：优先使用 .dist；否则回退到 .distance；再默认 'sqeuclidean'
    if isfield(params, 'dist')
        dist = params.dist;
    else
        dist = getfielddef(params, 'distance', 'sqeuclidean');
    end
    KiMode   = getfielddef(params, 'KiMode', 1);
    T        = getfielddef(params, 'T', 15);  % 最佳参数：T=15
    k        = getfielddef(params, 'k', 50);  % 最佳参数：k=50
    c        = getfielddef(params, 'c', K);
    maxRounds= getfielddef(params, 'maxRounds', 5);

    if isempty(K)
        if ~isempty(c)
            K = c;
        else
            K = max(2, round(sqrt(n))); % fallback heuristic
        end
    end
    if isempty(c), c = K; end

    XeHistory = cell(0); AHist = cell(0); GHist = cell(0); YHist = cell(0); BPsHist = cell(0);
    ObjHist = struct('rayleigh', {}, 'sse', {}, 'n', {});
    prevY = [];
    Xe = [];
    rand_idx = [];

    % 接受-拒绝控制参数（与半监督一致的目标组合）
    acceptAlpha  = getfielddef(params,'acceptAlpha', 1.0);   % Rayleigh 与 SSE 的权衡
    acceptEps    = getfielddef(params,'acceptEps',   1e-4);  % 最小提升
    bestJ        = -inf;                                     % 当前最优目标
    % 保存“被接受”的最近一次状态，便于回退
    Xe_acc = []; A_acc = []; G_acc = []; Y_acc = [];

    for t = 1:maxRounds
        tRound = tic; fprintf('【无监督】第 %d/%d 轮 开始...\n', t, maxRounds);
        
        % 0) 数据预处理（第一轮）
        if t == 1
            t0 = tic;
            % 特征标准化
            baseData = NormalizeFea(Data);
            
            % 检查是否需要进行异常值移除
            if getfielddef(params, 'removeOutliers', false)  % 默认不移除异常值
                % 异常值处理：使用更温和的参数，避免过度移除
                baseData = rmoutliers(baseData, 'mean', 'ThresholdFactor', 5);  % 从3改为5，更温和
                fprintf('  · 异常值移除：移除%d个样本\n', size(Data,1) - size(baseData,1));
            else
                fprintf('  · 跳过异常值移除，保持原始数据完整性\n');
            end
            
            % 使用外部设置的随机种子或MATLAB默认随机行为
            if isfield(params, 'externalSeed') && ~isempty(params.externalSeed)
                % 外部种子已设置，不需要额外操作
                rand_idx = randperm(size(baseData, 1));
            else
                % 使用MATLAB默认随机行为
                rand_idx = randperm(size(baseData, 1));
            end
            baseData = baseData(rand_idx, :);
            % 可选：PCA降维以去噪
            pcaDim = getfielddef(params, 'pcaDim', []);
            if ~isempty(pcaDim) && pcaDim > 0
                try
                    [coeff, score, ~, ~, explained] = pca(baseData, 'NumComponents', min(pcaDim, size(baseData,2)));
                    baseData = score;
                    fprintf('  · PCA降维到%d维，累计方差=%.2f%%\n', size(baseData,2), sum(explained(1:size(baseData,2))));
                catch ME
                    fprintf('  · PCA失败: %s，跳过PCA\n', ME.message);
                end
            end
            % 保存随机化索引，用于后续轮次保持一致性
            global_rand_idx = rand_idx;
            fprintf('  · 数据预处理完成，用时 %.2fs\n', toc(t0));
            fprintf('  · 预处理后样本数: %d (原始: %d, 移除: %d)\n', ...
                size(baseData,1), size(Data,1), size(Data,1)-size(baseData,1));
        else
            % 后续轮次：使用增强表示Xe，不进行额外预处理
            baseData = Xe;
        end
        
        % 1) Base partitions on current representation
        t1 = tic;
        BPs = BasicCluster_RPS(baseData, r, K, dist, KiMode);
        fprintf('  · 基聚类完成，用时 %.2fs\n', toc(t1));

        % 2) BKCC: Hc -> S_c -> Z -> X_e
        t2 = tic;
        [Hc, ~] = compute_Hc(BPs);
        Sc = simxjac(Hc', Hc');
        Z = computePTS_II(Sc, T);
        Xe = sample_representation_propagation(Hc, Z);
        fprintf('  · 表示增强完成，用时 %.2fs\n', toc(t2));

        % 3) Build S/A and compute spectral embedding + labels
        t3 = tic;
        % 相似度构造选项（距离与互为近邻）
        optsSim = struct('distance', getfielddef(params,'distance','euclidean'), ...
                         'mutual', getfielddef(params,'mutual',false), ...
                         'snnWeight', getfielddef(params,'snnWeight',0.00), ...  % 最佳参数：snnWeight=0.00
                         'gamma', getfielddef(params,'gamma',1.0));  % 最佳参数：gamma=1.0
        [S, A] = build_S_and_A_from_Xe(Xe, k, [], optsSim);
        
        % 谱聚类
        fprintf('    · 谱聚类参数：c=%d, 相似矩阵S大小=%s\n', c, mat2str(size(S)));
        
        % 检查相似矩阵的连通性（先转换为稀疏矩阵）
        A_sparse = sparse(S);
        try
            % 尝试使用新版本的graph/conncomp
            [num_components, ~] = graph.conncomp(A_sparse);
        catch
            try
                % 备用方案：使用简单的连通分量算法
                [~, num_components] = simple_connected_components(A_sparse);
            catch
                % 如果都失败，假设连通
                num_components = 1;
                fprintf('    · 警告：无法检查连通性，假设连通\n');
            end
        end
        fprintf('    · 相似矩阵连通性：%d个连通分量\n', num_components);
        
        if num_components > 1
            fprintf('    · 警告：相似矩阵不连通，可能影响谱聚类质量\n');
        end
        
        % 计算相似矩阵统计量（转换为全矩阵）
        A_full = full(S);
        fprintf('    · 相似矩阵S统计：最小值=%.4f, 最大值=%.4f, 均值=%.4f\n', ...
            min(A_full(:)), max(A_full(:)), mean(A_full(:)));
        
        DU = fast_spectral_clustering(S, c);
        
        % 调试：检查谱聚类输出
        fprintf('    · 谱聚类输出检查：G大小=%s, G范围=[%.4f, %.4f]\n', ...
            mat2str(size(DU)), min(DU(:)), max(DU(:)));
        fprintf('    · G是否包含NaN: %s, G是否包含Inf: %s\n', ...
            mat2str(any(isnan(DU(:)))), mat2str(any(isinf(DU(:)))));
        
        % 对谱嵌入进行逐行单位化，有助于kmeans稳定
        row_norm = sqrt(sum(DU.^2, 2)) + eps;
        DU = bsxfun(@rdivide, DU, row_norm);
        
        % kmeans on G to get labels - 多次运行取最佳
        bestSSE = inf;
        bestY = [];
        bestCenters = [];
        
        for rep = 1:20  % 增加运行次数到20，提高稳定性
            % kmeanspp期望输入是 d x n 格式，DU是 n x c，需要转置
            try
                % 调试：检查输入格式
                if rep == 1
                    fprintf('    · kmeanspp输入检查：DU大小=%s, 期望格式=d x n\n', mat2str(size(DU)));
                    fprintf('    · 转置后大小=%s, 目标簇数=%d\n', mat2str(size(DU')), c);
                end
                
                [labels, centers] = kmeanspp(DU', c);  % 转置DU以匹配期望格式
                
                % 验证标签的有效性
                if isempty(labels) || length(unique(labels)) ~= c
                    fprintf('    · 警告：kmeanspp第%d次运行失败，标签无效\n', rep);
                    continue;
                end
                
                % 调试信息
                if rep == 1
                    fprintf('    · kmeanspp输出：labels范围[%d,%d], 唯一值: %s\n', ...
                        min(labels), max(labels), mat2str(unique(labels)));
                    fprintf('    · DU维度: %s\n', mat2str(size(DU)));
                end
                
                % 保持标签原始值，不进行重新映射
                labels = labels(:);
                
                if rep == 1
                    fprintf('    · 保持原始标签：labels范围[%d,%d], 唯一值: %s\n', ...
                        min(labels), max(labels), mat2str(unique(labels)));
                end
                
                % 手动计算SSE
                SSE = 0;
                for i = 1:c
                    cluster_idx = find(labels == i);
                    if ~isempty(cluster_idx)
                        cluster_points = DU(cluster_idx, :);
                        cluster_center = mean(cluster_points, 1);
                        SSE = SSE + sum(sum((cluster_points - cluster_center).^2));
                    end
                end
                
                % 仅以SSE为准（移除测试期的平衡性惩罚与拒绝逻辑）
                if SSE < bestSSE
                    bestSSE = SSE;
                    bestY = labels;
                    bestCenters = centers;
                end
            catch ME
                fprintf('    · 警告：kmeanspp第%d次运行异常: %s\n', rep, ME.message);
                fprintf('    · 异常详情: %s\n', ME.getReport());
                continue;
            end
        end
        
        % 检查是否找到了有效的聚类结果
        if isempty(bestY)
            fprintf('    · 错误：所有kmeanspp运行都失败，使用随机初始化\n');
            bestY = randi(c, size(DU,1), 1);  % 随机初始化标签
        end
        Y = bestY;
        fprintf('  · 构图+谱聚类+KMeans 完成，用时 %.2fs\n', toc(t3));
        
        % 显示聚类质量信息
        cluster_sizes = histcounts(Y, 1:c+1);
        fprintf('  · 聚类质量：簇大小分布=%s\n', mat2str(cluster_sizes));
        fprintf('  · 聚类平衡性：最小簇=%d, 最大簇=%d, 变异系数=%.3f\n', ...
            min(cluster_sizes), max(cluster_sizes), std(cluster_sizes)/mean(cluster_sizes));

        % 计算本轮目标函数
        objNow = compute_objectives(A, DU, Y);
        
        % 改进的目标函数：使用滚动基准，更合理的权重
        if t == 1
            % 第一轮：初始化基准和最优值
            bestRay = objNow.rayleigh;
            bestSSE = objNow.sse;
            bestJ = 0;  % 第一轮目标为0
            Xe_acc = Xe; A_acc = A; G_acc = DU; Y_acc = Y;
            fprintf('  · [接受] 初始化轮：Rayleigh=%.6f, SSE=%.6f\n', objNow.rayleigh, objNow.sse);
        else
            % 后续轮次：使用改进的目标函数
            % 方案1：纯Rayleigh优化（推荐）
            Jcand = objNow.rayleigh;
            if Jcand > bestRay + acceptEps
                bestRay = Jcand;
                bestJ = Jcand;
                Xe_acc = Xe; A_acc = A; G_acc = DU; Y_acc = Y;
                fprintf('  · [接受] Rayleigh提升：%.6f -> %.6f\n', bestRay-acceptEps, bestRay);
            else
                % 回退到上一次被接受的状态
                Xe = Xe_acc; A = A_acc; DU = G_acc; Y = Y_acc;
                objNow = compute_objectives(A, DU, Y);
                fprintf('  · [拒绝] Rayleigh未提升：%.6f <= %.6f\n', Jcand, bestRay + acceptEps);
            end
        end

        % Save history and objectives（记录“被接受/回退后的”状态）
        XeHistory{t} = Xe; %#ok<AGROW>
        AHist{t} = A; %#ok<AGROW>
        GHist{t} = DU; %#ok<AGROW>
        YHist{t} = Y; %#ok<AGROW>
        BPsHist{t} = BPs; %#ok<AGROW>
        ObjHist(t) = objNow; %#ok<AGROW>

        % Stop if labels unchanged（可配置早停）
        if ~isempty(prevY) && numel(prevY)==numel(Y)
            earlyStop = getfielddef(params, 'earlyStop', true);
            try
                nmi = compute_nmi(prevY, Y);
                fprintf('  · 与上一轮NMI=%.4f\n', nmi);
                % 仅当允许早停且达到阈值才停止
                if earlyStop
                    nmiThresh = getfielddef(params, 'nmiStop', 0.8);
                    % 显示标签分布信息
                    fprintf('  · 上一轮标签分布: %s\n', mat2str(histcounts(prevY, 1:c+1)));
                    fprintf('  · 当前轮标签分布: %s\n', mat2str(histcounts(Y, 1:c+1)));
                    % 显示标签的唯一值
                    fprintf('  · 上一轮标签唯一值: %s\n', mat2str(unique(prevY)));
                    fprintf('  · 当前轮标签唯一值: %s\n', mat2str(unique(Y)));
                    % 显示标签的对应关系
                    fprintf('  · 标签对应关系检查:\n');
                    unique_prevY = unique(prevY);
                    unique_Y = unique(Y);
                    for i = 1:min(length(unique_prevY), length(unique_Y))
                        fprintf('    - 上一轮标签%d -> 当前轮标签%d: 样本数=%d\n', ...
                            unique_prevY(i), unique_Y(i), ...
                            sum(prevY == unique_prevY(i) & Y == unique_Y(i)));
                    end
                    % 显示标签变化统计
                    fprintf('  · 标签变化统计: 保持相同=%d, 发生变化=%d, 总样本=%d\n', ...
                        sum(prevY == Y), sum(prevY ~= Y), length(prevY));
                    if nmi >= nmiThresh
                        fprintf('  · NMI=%.4f≥阈值%.2f，提前停止。\n', nmi, nmiThresh);
                        % 在提前退出前，确保保存当前轮的结果
                        XeHistory{t} = Xe;
                        AHist{t} = A;
                        GHist{t} = DU;
                        YHist{t} = Y;
                        BPsHist{t} = BPs;
                        ObjHist(t) = compute_objectives(A, DU, Y);
                        fprintf('【无监督】第 %d 轮 完成，总用时 %.2fs\n', t, toc(tRound));
                        break;
                    end
                end
            catch ME
                fprintf('  · NMI计算失败: %s\n', ME.message);
                if earlyStop && all(prevY==Y)
                    fprintf('  · 标签未变化，提前停止。\n');
                    fprintf('【无监督】第 %d 轮 完成，总用时 %.2fs\n', t, toc(tRound));
                    break;
                end
            end
        end
        prevY = Y;
        fprintf('【无监督】第 %d 轮 完成，总用时 %.2fs\n', t, toc(tRound));
    end

    % 调试：检查输出前的变量状态
    fprintf('=== 无监督输出调试 ===\n');
    fprintf('XeHistory长度: %d\n', length(XeHistory));
    fprintf('AHist长度: %d\n', length(AHist));
    fprintf('GHist长度: %d\n', length(GHist));
    fprintf('YHist长度: %d\n', length(YHist));
    if ~isempty(XeHistory)
        fprintf('XeHistory{end}大小: %s\n', mat2str(size(XeHistory{end})));
    end
    if ~isempty(AHist)
        fprintf('AHist{end}大小: %s\n', mat2str(size(AHist{end})));
    end
    if ~isempty(GHist)
        fprintf('GHist{end}大小: %s\n', mat2str(size(GHist{end})));
    end
    if ~isempty(YHist)
        fprintf('YHist{end}大小: %s\n', mat2str(size(YHist{end})));
    end
    fprintf('Xe大小: %s\n', mat2str(size(Xe)));

    out = struct();
    out.XeHistory = XeHistory;
    out.AHist = AHist;
    out.GHist = GHist;
    out.YHist = YHist;
    out.BPsHist = BPsHist;
    out.ObjHist = ObjHist;
    % 确保A变量存在，如果不存在则使用最后一轮的A
    if ~isempty(AHist) && ~isempty(AHist{end})
        finalA = AHist{end};
    else
        finalA = [];
    end
    % 确保G变量存在，如果不存在则使用最后一轮的G
    if ~isempty(GHist) && ~isempty(GHist{end})
        finalG = GHist{end};
    else
        finalG = [];
    end
    % 确保Y变量存在，如果不存在则使用最后一轮的Y
    if ~isempty(YHist) && ~isempty(YHist{end})
        finalY = YHist{end};
    else
        finalY = [];
    end
    % 如果首轮打乱过，则在输出时恢复到原始顺序
    if ~isempty(rand_idx) && numel(rand_idx) == n
        inv_idx = zeros(n,1); inv_idx(rand_idx) = 1:n;
        if ~isempty(finalY), finalY = finalY(inv_idx); end
        if ~isempty(finalG), finalG = finalG(inv_idx, :); end
        if ~isempty(finalA), finalA = finalA(inv_idx, inv_idx); end
        if ~isempty(Xe),     Xe     = Xe(inv_idx, :); end
    end
    out.final = struct('Xe', Xe, 'A', finalA, 'G', finalG, 'Y', finalY, 'rounds', numel(YHist));
    out.perm = rand_idx;  % 输出首轮置换，便于对齐标签与调试

end

function v = getfielddef(s, name, def)
    if isfield(s, name)
        v = s.(name);
    else
        v = def;
    end
end

function nmi = compute_nmi(y1, y2)
% 计算两个标签向量的NMI
    if length(y1) ~= length(y2)
        nmi = 0;
        return;
    end
    
    % 获取唯一标签
    u1 = unique(y1);
    u2 = unique(y2);
    
    % 计算联合分布
    n = length(y1);
    joint = zeros(length(u1), length(u2));
    for i = 1:length(u1)
        for j = 1:length(u2)
            joint(i,j) = sum(y1 == u1(i) & y2 == u2(j));
        end
    end
    
    % 可选：调试时显示联合分布（默认关闭）
    if false
        fprintf('      · 联合分布矩阵:\n');
        for i = 1:length(u1)
            fprintf('        ');
            for j = 1:length(u2)
                fprintf('%6d ', joint(i,j));
            end
            fprintf('\n');
        end
    end
    
    % 计算边缘分布
    p1 = sum(joint, 2) / n;
    p2 = sum(joint, 1) / n;
    
    % 计算互信息
    mi = 0;
    for i = 1:length(u1)
        for j = 1:length(u2)
            if joint(i,j) > 0
                mi = mi + joint(i,j)/n * log2(n * joint(i,j) / (p1(i) * p2(j)));
            end
        end
    end
    
    % 计算熵
    h1 = -sum(p1 .* log2(p1 + eps));
    h2 = -sum(p2 .* log2(p2 + eps));
    
    % NMI - 修复计算逻辑
    if h1 + h2 == 0
        nmi = 1;
    else
        % 使用正确的NMI公式
        nmi = 2 * mi / (h1 + h2);
        % 确保NMI在[0,1]范围内
        nmi = max(0, min(1, nmi));
    end
    
    % 可选：调试打印（默认关闭）
    if false
        fprintf('      · NMI调试: MI=%.4f, H1=%.4f, H2=%.4f, 原始NMI=%.4f, 最终NMI=%.4f\n', ...
            mi, h1, h2, 2*mi/(h1+h2), nmi);
        fprintf('      · 验证: 样本总数=%d, 保持相同=%d, 变化率=%.2f%%, NMI=%.4f\n', ...
            n, sum(y1 == y2), 100*sum(y1 ~= y2)/n, nmi);
    end
end


