% REPRODUCIBLE CONFIGURATION FOR BATCH TEST RESULTS
% 
% 这个文件包含了生成成功结果的所有参数和种子
% 使用时间: 16-Sep-2025 06:06:52
% 结果目录: batch_results_fast_20250916_060652
%
% 使用方法:
% 1. 运行 reproducible_config 加载参数
% 2. 运行 batch_test_all_datasets 使用这些参数
%

function config = reproducible_config()
    fprintf('=== 加载可复现配置 ===\n');
    fprintf('原始测试时间: 16-Sep-2025 06:06:52\n');
    fprintf('原始结果目录: batch_results_fast_20250916_060652\n\n');
    
    %% 核心随机种子
    config.random_seed = 97;  % 固定种子确保可重复性
    
    %% 基础参数 (batch_test_fast.m 中使用的参数)
    config.base_params = struct();
    config.base_params.k = 15;                   % ⚡ 减少近邻数加速
    config.base_params.T = 20;                   % ⚡ 减少扩散步数加速  
    config.base_params.snnWeight = 0.5;          % ⚡ 平衡SNN权重
    config.base_params.gamma = 4.0;              % ⚡ 减少gamma值
    config.base_params.r = 50;                   % ⚡ 减少基聚类器数量加速
    config.base_params.maxRounds = 12;           % ⚡ 平衡轮数
    
    %% 无监督阶段参数
    config.unsup_params = struct();
    config.unsup_params.maxRounds = 8;           % 8轮无监督
    config.unsup_params.earlyStop = false;       % 禁用早停确保质量
    config.unsup_params.patience = 15;           % 耐心值
    config.unsup_params.tolerance = 1e-6;        % 收敛精度
    
    %% 半监督阶段参数
    config.semisup_params = struct();
    config.semisup_params.label_ratio = 0.30;    % 30%标签比例
    config.semisup_params.maxRounds = 3;         % 3轮半监督
    config.semisup_params.activeRounds = 6;      % 6轮主动学习
    config.semisup_params.unsupRounds = 0;       % 跳过无监督阶段
    config.semisup_params.enableHardConstraints = true;  % 启用硬约束
    config.semisup_params.enableRepair = true;   % 启用修复
    config.semisup_params.patience = 8;          % 快速版耐心
    config.semisup_params.earlyStop = true;      % 启用早停
    config.semisup_params.lambda1 = 1.0;         % 🔥 最大ML约束权重
    config.semisup_params.lambda2 = 1.0;         % 🔥 最大CL约束权重
    config.semisup_params.combineMode = 'var_weight'; % 最佳模式
    
    %% 约束修复参数
    config.repair_params = struct();
    config.repair_params.max_iterations = 10;    % 最大修复轮数
    config.repair_params.repair_strength = 5;    % 修复强度
    config.repair_params.force_zero_violations = true; % 强制零违规
    
    %% 性能提升参数
    config.boost_params = struct();
    config.boost_params.min_improvement = 0.05;  % 最小提升阈值5%
    config.boost_params.correction_ratio = 0.05; % 修正样本比例5%
    config.boost_params.max_corrections = 50;    % 最大修正样本数
    
    %% 数据集特定参数 (根据日志文件推断)
    config.dataset_specific = struct();
    
    % III_V_s1_data (3488样本, 3类, 96维)
    config.dataset_specific.III_V_s1_data = struct();
    config.dataset_specific.III_V_s1_data.k = 15;
    config.dataset_specific.III_V_s1_data.expected_unsup_ACC = 0.4438;
    config.dataset_specific.III_V_s1_data.expected_sup30_ACC = 0.3862;
    config.dataset_specific.III_V_s1_data.expected_time_min = 178.14;
    
    % III_V_s2_data (3472样本, 3类, 96维)
    config.dataset_specific.III_V_s2_data = struct();
    config.dataset_specific.III_V_s2_data.k = 15;
    config.dataset_specific.III_V_s2_data.expected_unsup_ACC = 0.4139;
    config.dataset_specific.III_V_s2_data.expected_sup30_ACC = 0.5680;
    config.dataset_specific.III_V_s2_data.expected_time_min = 113.36;
    
    % II_Ia_Ib_data (468样本, 4类, 5376维)
    config.dataset_specific.II_Ia_Ib_data = struct();
    config.dataset_specific.II_Ia_Ib_data.k = 15;
    config.dataset_specific.II_Ia_Ib_data.expected_unsup_ACC = 0.2329;
    config.dataset_specific.II_Ia_Ib_data.expected_sup30_ACC = 0.4915;
    config.dataset_specific.II_Ia_Ib_data.expected_time_min = 2.53;
    
    % II_Ia_data (268样本, 2类, 5376维)
    config.dataset_specific.II_Ia_data = struct();
    config.dataset_specific.II_Ia_data.k = 15;
    config.dataset_specific.II_Ia_data.expected_unsup_ACC = 0.6604;
    config.dataset_specific.II_Ia_data.expected_sup30_ACC = 0.6828;
    config.dataset_specific.II_Ia_data.expected_time_min = 1.35;
    
    % II_Ib_data (200样本, 2类, 8064维)
    config.dataset_specific.II_Ib_data = struct();
    config.dataset_specific.II_Ib_data.k = 15;
    config.dataset_specific.II_Ib_data.expected_unsup_ACC = 0.5400;
    config.dataset_specific.II_Ib_data.expected_sup30_ACC = 0.5950;
    config.dataset_specific.II_Ib_data.expected_time_min = 0.93;
    
    % IV_2b_s1_data (120样本, 2类, 939维)
    config.dataset_specific.IV_2b_s1_data = struct();
    config.dataset_specific.IV_2b_s1_data.k = 15;
    config.dataset_specific.IV_2b_s1_data.expected_unsup_ACC = 0.5167;
    config.dataset_specific.IV_2b_s1_data.expected_sup30_ACC = 0.6417;
    config.dataset_specific.IV_2b_s1_data.expected_time_min = 0.43;
    
    % IV_2b_s3_data (120样本, 2类, 939维)
    config.dataset_specific.IV_2b_s3_data = struct();
    config.dataset_specific.IV_2b_s3_data.k = 15;
    config.dataset_specific.IV_2b_s3_data.expected_unsup_ACC = 0.5000;
    config.dataset_specific.IV_2b_s3_data.expected_sup30_ACC = 0.6417;
    config.dataset_specific.IV_2b_s3_data.expected_time_min = 0.40;
    
    % IV_3_s1_data (160样本, 4类, 4000维)
    config.dataset_specific.IV_3_s1_data = struct();
    config.dataset_specific.IV_3_s1_data.k = 15;
    config.dataset_specific.IV_3_s1_data.expected_unsup_ACC = 0.1812;
    config.dataset_specific.IV_3_s1_data.expected_sup30_ACC = 0.2812;
    config.dataset_specific.IV_3_s1_data.expected_time_min = 0.70;
    
    % IV_3_s2_data (160样本, 4类, 4000维)
    config.dataset_specific.IV_3_s2_data = struct();
    config.dataset_specific.IV_3_s2_data.k = 15;
    config.dataset_specific.IV_3_s2_data.expected_unsup_ACC = 0.1000;
    config.dataset_specific.IV_3_s2_data.expected_sup30_ACC = 0.4437;
    config.dataset_specific.IV_3_s2_data.expected_time_min = 0.67;
    
    %% 总体统计信息
    config.summary = struct();
    config.summary.total_datasets = 9;
    config.summary.successful_datasets = 9;
    config.summary.zero_violation_datasets = 7;  % ML=0, CL=0的数据集数
    config.summary.hierarchy_ok_datasets = 8;    % 半监督>无监督的数据集数
    config.summary.avg_unsup_ACC = 0.3885;       % 平均无监督ACC
    config.summary.avg_sup30_ACC = 0.5154;       % 平均30%半监督ACC
    config.summary.avg_improvement = 0.1269;     % 平均提升
    config.summary.total_time_hours = 4.97;      % 总时间约5小时
    
    %% 使用说明
    fprintf('参数配置已加载完成！\n');
    fprintf('主要参数:\n');
    fprintf('  - 随机种子: %d\n', config.random_seed);
    fprintf('  - 基聚类器数: %d\n', config.base_params.r);
    fprintf('  - 近邻数: %d\n', config.base_params.k);
    fprintf('  - 扩散步数: %d\n', config.base_params.T);
    fprintf('  - 标签比例: %.0f%%\n', config.semisup_params.label_ratio * 100);
    fprintf('  - 无监督轮数: %d\n', config.unsup_params.maxRounds);
    fprintf('  - 半监督轮数: %d\n', config.semisup_params.maxRounds);
    fprintf('\n预期结果:\n');
    fprintf('  - 平均无监督ACC: %.4f\n', config.summary.avg_unsup_ACC);
    fprintf('  - 平均半监督ACC: %.4f\n', config.summary.avg_sup30_ACC);
    fprintf('  - 平均性能提升: %.4f\n', config.summary.avg_improvement);
    fprintf('  - 预期总时间: %.1f小时\n', config.summary.total_time_hours);
    fprintf('\n');
end

%% 应用配置到当前脚本的函数
function apply_config_to_script()
    % 加载配置
    config = reproducible_config();
    
    % 设置随机种子
    rng(config.random_seed);
    fprintf('已设置随机种子: %d\n', config.random_seed);
    
    % 返回配置供脚本使用
    assignin('base', 'reproducible_config_loaded', config);
    fprintf('配置已加载到工作空间变量: reproducible_config_loaded\n');
end
