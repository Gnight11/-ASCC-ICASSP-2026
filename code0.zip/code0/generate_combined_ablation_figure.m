% GENERATE_COMBINED_ABLATION_FIGURE: 分别处理5个数据集，合并消融实验图
%
% 每个数据集单独运行消融实验，最后合并成一张综合图表
%
clear; clc;
addpath(genpath(fileparts(mfilename('fullpath'))));

fprintf('=== 生成合并消融实验图 ===\n');

% 数据集列表
datasets = {'II_Ia_data', 'II_Ib_data', 'III_V_s2_data', 'IV_2b_s1_data', 'IV_2b_s3_data'};
data_dir = fullfile('..', 'data');

% 存储每个数据集的结果
dataset_results = struct();

% 简化参数（避免内存问题）
params = struct();
params.max_features = 100;  % 最大特征数
params.k_neighbors = 8;     % kNN邻居数
params.num_base_clusterers = 15;  % 基聚类器数量
params.consensus_runs = 8;  % 共识聚类运行次数

%% 逐个数据集处理
for i = 1:length(datasets)
    dataset_name = datasets{i};
    dataset_path = fullfile(data_dir, [dataset_name '.mat']);
    
    fprintf('\n=== 处理数据集 %d/5: %s ===\n', i, dataset_name);
    
    try
        % 加载数据
        [data, gt] = load_timeseries_mat(dataset_path);
        n_samples = length(gt);
        n_classes = length(unique(gt));
        n_features = size(data, 2);
        
        fprintf('原始数据: %d样本, %d类别, %d维特征\n', n_samples, n_classes, n_features);
        
        % 降维处理
        if n_features > params.max_features
            fprintf('PCA降维: %d -> %d 维\n', n_features, params.max_features);
            [~, data_reduced] = pca(data);
            data = data_reduced(:, 1:params.max_features);
        end
        
        % 标准化
        data = zscore(data);
        
        % 设置随机种子
        rng(42 + i);  % 每个数据集不同种子
        
        %% 消融实验
        ablation_acc = zeros(1, 5);
        
        % 1. Baseline K-means++
        fprintf('  1. Baseline K-means++\n');
        Y1 = kmeanspp(data, n_classes, 'Replicates', 5);
        M1 = metrics_eval(gt, Y1);
        ablation_acc(1) = M1.ACC;
        
        % 2. +Graph Diffusion
        fprintf('  2. +Graph Diffusion\n');
        k = min(params.k_neighbors, n_samples-1);
        
        % 构建kNN图
        W = zeros(n_samples, n_samples);
        for j = 1:n_samples
            dists = sum((data - data(j,:)).^2, 2);
            [sorted_dists, idx] = sort(dists);
            neighbors = idx(2:k+1);  % 排除自己
            sigma = median(sorted_dists(2:k+1));
            W(j, neighbors) = exp(-sorted_dists(2:k+1) / (2 * sigma^2));
        end
        W = (W + W') / 2;  % 对称化
        
        % 图扩散
        D = diag(sum(W, 2) + eps);
        P = D \ W;  % 转移矩阵
        P_diffused = P;
        for diffusion_step = 1:3
            P_diffused = P_diffused * P;
        end
        
        % 谱聚类
        D_new = diag(sum(P_diffused, 2) + eps);
        L = eye(n_samples) - D_new \ P_diffused;
        [V, ~] = eigs(L, n_classes, 'smallestabs');
        Y2 = kmeans(real(V), n_classes, 'Replicates', 5);
        M2 = metrics_eval(gt, Y2);
        ablation_acc(2) = M2.ACC;
        
        % 3. +Consensus Clustering
        fprintf('  3. +Consensus Clustering\n');
        consensus_matrix = zeros(n_samples, n_samples);
        
        for run = 1:params.consensus_runs
            % 随机初始化k-means
            Y_temp = kmeans(data, n_classes, 'Replicates', 1, 'Start', 'plus');
            
            % 更新共识矩阵
            for j1 = 1:n_samples
                for j2 = j1+1:n_samples
                    if Y_temp(j1) == Y_temp(j2)
                        consensus_matrix(j1, j2) = consensus_matrix(j1, j2) + 1;
                        consensus_matrix(j2, j1) = consensus_matrix(j2, j1) + 1;
                    end
                end
            end
        end
        
        consensus_matrix = consensus_matrix / params.consensus_runs;
        
        % 在共识矩阵上谱聚类
        D_cons = diag(sum(consensus_matrix, 2) + eps);
        L_cons = eye(n_samples) - D_cons \ consensus_matrix;
        [V_cons, ~] = eigs(L_cons, n_classes, 'smallestabs');
        Y3 = kmeans(real(V_cons), n_classes, 'Replicates', 5);
        M3 = metrics_eval(gt, Y3);
        ablation_acc(3) = M3.ACC;
        
        % 4. +Active Learning (模拟)
        fprintf('  4. +Active Learning\n');
        % 模拟主动学习：选择10%样本
        label_ratio = 0.1;
        n_labeled = round(n_samples * label_ratio);
        
        % 分层采样
        labeled_idx = [];
        for c = 1:n_classes
            class_idx = find(gt == c);
            n_class_labeled = max(1, round(length(class_idx) * label_ratio));
            if length(class_idx) >= n_class_labeled
                class_labeled = randsample(class_idx, n_class_labeled);
                labeled_idx = [labeled_idx; class_labeled];
            end
        end
        
        % 半监督聚类：用标签信息调整相似矩阵
        W_semi = consensus_matrix;
        
        % 增强同类样本相似性
        for j1 = 1:length(labeled_idx)
            for j2 = j1+1:length(labeled_idx)
                idx1 = labeled_idx(j1);
                idx2 = labeled_idx(j2);
                if gt(idx1) == gt(idx2)  % 同类
                    W_semi(idx1, idx2) = W_semi(idx1, idx2) + 0.5;
                    W_semi(idx2, idx1) = W_semi(idx2, idx1) + 0.5;
                else  % 异类
                    W_semi(idx1, idx2) = max(0, W_semi(idx1, idx2) - 0.3);
                    W_semi(idx2, idx1) = max(0, W_semi(idx2, idx1) - 0.3);
                end
            end
        end
        
        % 谱聚类
        D_semi = diag(sum(W_semi, 2) + eps);
        L_semi = eye(n_samples) - D_semi \ W_semi;
        [V_semi, ~] = eigs(L_semi, n_classes, 'smallestabs');
        Y4 = kmeans(real(V_semi), n_classes, 'Replicates', 5);
        M4 = metrics_eval(gt, Y4);
        ablation_acc(4) = M4.ACC;
        
        % 5. +Hard Constraints (ASCC)
        fprintf('  5. +Hard Constraints\n');
        % 构建约束
        constraints_ml = [];
        constraints_cl = [];
        
        % Must-link约束
        for c = 1:n_classes
            class_labeled = labeled_idx(gt(labeled_idx) == c);
            if length(class_labeled) > 1
                % 每类最多10个ML约束
                max_ml = min(10, nchoosek(length(class_labeled), 2));
                ml_count = 0;
                for j1 = 1:length(class_labeled)
                    for j2 = j1+1:length(class_labeled)
                        if ml_count < max_ml
                            constraints_ml = [constraints_ml; class_labeled(j1), class_labeled(j2)];
                            ml_count = ml_count + 1;
                        end
                    end
                end
            end
        end
        
        % Cannot-link约束
        for c1 = 1:n_classes
            for c2 = c1+1:n_classes
                class1_labeled = labeled_idx(gt(labeled_idx) == c1);
                class2_labeled = labeled_idx(gt(labeled_idx) == c2);
                if ~isempty(class1_labeled) && ~isempty(class2_labeled)
                    % 每对类别最多3个CL约束
                    for j1 = 1:min(3, length(class1_labeled))
                        for j2 = 1:min(3, length(class2_labeled))
                            constraints_cl = [constraints_cl; class1_labeled(j1), class2_labeled(j2)];
                        end
                    end
                end
            end
        end
        
        % 硬约束聚类
        Y5 = Y4;  % 从主动学习结果开始
        
        % 修复违规（简化版）
        for repair_iter = 1:5
            violations = 0;
            
            % 修复ML违规
            for j = 1:size(constraints_ml, 1)
                idx1 = constraints_ml(j, 1);
                idx2 = constraints_ml(j, 2);
                if Y5(idx1) ~= Y5(idx2)
                    Y5(idx2) = Y5(idx1);  % 强制同类
                    violations = violations + 1;
                end
            end
            
            % 修复CL违规
            for j = 1:size(constraints_cl, 1)
                idx1 = constraints_cl(j, 1);
                idx2 = constraints_cl(j, 2);
                if Y5(idx1) == Y5(idx2)
                    % 找到最小的可用标签
                    available_labels = setdiff(1:n_classes, Y5(idx1));
                    if ~isempty(available_labels)
                        Y5(idx2) = available_labels(1);
                        violations = violations + 1;
                    end
                end
            end
            
            if violations == 0
                break;
            end
        end
        
        M5 = metrics_eval(gt, Y5);
        ablation_acc(5) = M5.ACC;
        
        % 存储结果
        dataset_results.(dataset_name) = ablation_acc;
        
        fprintf('  结果: %.3f -> %.3f -> %.3f -> %.3f -> %.3f\n', ablation_acc);
        fprintf('  总改进: +%.1f%%\n', (ablation_acc(5) - ablation_acc(1)) / ablation_acc(1) * 100);
        
    catch ME
        fprintf('  数据集 %s 处理失败: %s\n', dataset_name, ME.message);
        dataset_results.(dataset_name) = [NaN, NaN, NaN, NaN, NaN];
    end
end

%% 生成合并图表
fprintf('\n=== 生成合并消融实验图 ===\n');

% 提取所有结果
all_results = [];
valid_datasets = {};

for i = 1:length(datasets)
    dataset_name = datasets{i};
    if isfield(dataset_results, dataset_name)
        result = dataset_results.(dataset_name);
        if ~any(isnan(result))
            all_results = [all_results; result];
            valid_datasets{end+1} = dataset_name;
        end
    end
end

if ~isempty(all_results)
    % 计算平均结果
    avg_results = mean(all_results, 1);
    
    % 计算改进百分比
    baseline = avg_results(1);
    improvements = (avg_results - baseline) / baseline * 100;
    
    fprintf('平均结果:\n');
    fprintf('Baseline: %.3f\n', avg_results(1));
    fprintf('+Graph Diffusion: %.3f (+%.1f%%)\n', avg_results(2), improvements(2));
    fprintf('+Consensus: %.3f (+%.1f%%)\n', avg_results(3), improvements(3));
    fprintf('+Active Learning: %.3f (+%.1f%%)\n', avg_results(4), improvements(4));
    fprintf('+Hard Constraints: %.3f (+%.1f%%)\n', avg_results(5), improvements(5));
    fprintf('总改进: +%.1f%%\n', improvements(5));
    
    %% 绘制图表
    figure('Position', [100, 100, 900, 650]);
    
    % 设置颜色
    colors = [
        0.85, 0.32, 0.32;  % 红色
        0.93, 0.69, 0.13;  % 橙色
        0.47, 0.67, 0.19;  % 绿色
        0.30, 0.75, 0.93;  % 蓝色
        0.49, 0.18, 0.56   % 紫色
    ];
    
    % 绘制柱状图
    accuracies = avg_results * 100;
    bars = bar(accuracies, 'FaceColor', 'flat', 'LineWidth', 1.5);
    bars.CData = colors;
    
    % 标签
    labels = {'Baseline', '+Graph\nDiffusion', '+Consensus\nClustering', '+Active\nLearning', '+Hard\nConstraints'};
    set(gca, 'XTickLabel', labels);
    xtickangle(0);
    
    % 添加数值标签
    for i = 1:length(accuracies)
        if i == 1
            text(i, accuracies(i) + 1.5, sprintf('%.1f%%', accuracies(i)), ...
                'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 12);
        else
            text(i, accuracies(i) + 1.5, sprintf('+%.1f%%', improvements(i)), ...
                'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 11, ...
                'Color', [0, 0.6, 0]);
            text(i, accuracies(i) - 2.5, sprintf('%.1f%%', accuracies(i)), ...
                'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 11);
        end
    end
    
    % 总改进标注
    annotation('textbox', [0.65, 0.8, 0.3, 0.1], ...
        'String', sprintf('Total Improvement: +%.1f%%', improvements(5)), ...
        'FontSize', 14, 'FontWeight', 'bold', ...
        'BackgroundColor', [1, 1, 0.8], 'EdgeColor', 'black', ...
        'HorizontalAlignment', 'center');
    
    % 图表设置
    ylabel('Clustering Accuracy (%)', 'FontSize', 14, 'FontWeight', 'bold');
    xlabel('ASCC Components', 'FontSize', 14, 'FontWeight', 'bold');
    title('Ablation Study: Progressive Component Contributions (5 EEG Datasets)', 'FontSize', 16, 'FontWeight', 'bold');
    
    grid on;
    grid minor;
    ylim([min(accuracies) - 5, max(accuracies) + 6]);
    set(gca, 'FontSize', 12);
    set(gca, 'GridAlpha', 0.3);
    
    % 保存图片
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    fig_name = sprintf('combined_ablation_%s', timestamp);
    
    print(gcf, [fig_name '.png'], '-dpng', '-r300');
    print(gcf, [fig_name '.eps'], '-depsc2', '-r300');
    
    fprintf('合并消融实验图已保存: %s.png 和 %s.eps\n', fig_name, fig_name);
    
    % 保存数据
    save([fig_name '_data.mat'], 'dataset_results', 'all_results', 'avg_results', 'improvements', 'valid_datasets');
    
else
    fprintf('没有成功的数据集结果\n');
end

fprintf('\n=== 合并消融实验完成 ===\n');
