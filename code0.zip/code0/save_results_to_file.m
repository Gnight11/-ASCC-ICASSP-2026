function save_results_to_file(res_unsup, res_sup10, dataset_name, result_dir)
% SAVE_RESULTS_TO_FILE: 保存聚类结果到文件
% 
% 输入:
%   res_unsup - 无监督聚类结果
%   res_sup10 - 10%半监督聚类结果  
%   dataset_name - 数据集名称
%   result_dir - 结果保存目录
%
% 输出:
%   保存结果到指定目录的MAT文件

try
    % 创建结果保存文件名
    result_file = fullfile(result_dir, sprintf('%s_results.mat', dataset_name));
    
    % 准备保存的数据结构
    results = struct();
    results.dataset_name = dataset_name;
    results.timestamp = datestr(now);
    
    % 保存无监督结果
    if exist('res_unsup', 'var') && ~isempty(res_unsup)
        results.unsupervised = res_unsup;
    end
    
    % 保存半监督结果
    if exist('res_sup10', 'var') && ~isempty(res_sup10)
        results.semisupervised = res_sup10;
    end
    
    % 保存到文件
    save(result_file, 'results', '-v7.3');
    
    fprintf('结果已保存到: %s\n', result_file);
    
catch ME
    fprintf('保存结果文件时出错: %s\n', ME.message);
end

end
