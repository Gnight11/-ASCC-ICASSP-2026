function [Data, labels] = load_timeseries_mat(matFilePath)
%==========================================================================
% FUNCTION: [Data, labels] = load_timeseries_mat(matFilePath)
% DESCRIPTION:
%   Load a .mat file containing a numeric matrix where each row is a trial
%   (sample). The first column is the label, and the remaining columns are
%   the time-series features.
%
% INPUTS:
%   matFilePath : path to a .mat file. The file should contain at least one
%                 numeric 2D array with size [n x d], n>=1, d>=2.
%                 If multiple numeric arrays exist, the first one found will
%                 be used. If a variable named 'Data', 'X', or 'data' exists,
%                 it will be preferred.
%
% OUTPUTS:
%   Data   : n x (d-1) matrix of features (columns 2..d), in double type
%   labels : n x 1 vector of labels (column 1), in double type
%
% NOTES:
%   - This function only performs loading and splitting; it does not apply
%     normalization. Use external utilities (e.g., NormalizeFea) if needed.
%==========================================================================

    if nargin ~= 1
        error('load_timeseries_mat: Requires exactly 1 input argument (matFilePath).');
    end

    if ~ischar(matFilePath) && ~isstring(matFilePath)
        error('load_timeseries_mat: matFilePath must be a character vector or string.');
    end

    if ~exist(matFilePath, 'file')
        error('load_timeseries_mat: File not found: %s', char(matFilePath));
    end

    S = load(matFilePath);

    % Preferred variable names (common conventions)
    preferredNames = {'Data','X','data','x','dataset','D'};

    candidate = [];
    % Try preferred names first
    for i = 1:numel(preferredNames)
        name = preferredNames{i};
        if isfield(S, name) && isnumeric(S.(name)) && ndims(S.(name)) == 2
            candidate = S.(name);
            break;
        end
    end

    % Fallback: first numeric 2D matrix in the struct
    if isempty(candidate)
        fns = fieldnames(S);
        for i = 1:numel(fns)
            val = S.(fns{i});
            if isnumeric(val) && ndims(val) == 2 && ~isscalar(val)
                candidate = val;
                break;
            end
        end
    end

    if isempty(candidate)
        error('load_timeseries_mat: No numeric 2D array found in %s', char(matFilePath));
    end

    X = double(candidate);

    if size(X,2) < 2
        error('load_timeseries_mat: Data must have at least 2 columns (label + features).');
    end

    if any(any(~isfinite(X)))
        warning('load_timeseries_mat: Non-finite values detected; replacing with zeros.');
        X(~isfinite(X)) = 0;
    end

    labels = X(:,1);
    Data = X(:,2:end);

    % Ensure column vectors and proper shapes
    if size(labels,2) ~= 1
        labels = labels(:);
    end

end


